/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestRunner;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JProgressBar;

/**
 *
 * @author mayur
 */
class ProgressBarPainter {
    
    public void paintProgressBar()
    {
        JProgressBar jProgBar = new JProgressBar();
       try{
       jProgBar.setIndeterminate(true);
       jProgBar.setStringPainted(true);
       jProgBar.setBorderPainted(true);
       new Thread(new Runnable() {
           public void run() {
               try {
                   Thread.sleep(1000);
               } catch (InterruptedException ex) {
                   Logger.getLogger(ProgressBarPainter.class.getName()).log(Level.SEVERE, null, ex);
               }
               jProgBar.setStringPainted(false);
               jProgBar.setBorderPainted(true);
               jProgBar.setIndeterminate(false);
       }
       }).start();
   }
   catch(IllegalStateException ex){
       //some code
   }
    }
            
}
