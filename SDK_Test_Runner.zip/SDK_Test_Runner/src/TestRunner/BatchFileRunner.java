/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestRunner;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author mayur
 */
public class BatchFileRunner {
    
   public static int NumberOfModulesToTest = 0;
    
     public void getAdbLogs() throws InterruptedException, IOException{

        Runtime rt = Runtime.getRuntime();

        String [] getFolderCommand = {"cmd", "/c", "D:\\Project\\ConnectNext\\Automation\\Functional.bat"};

         NewJFrame newFrame = new NewJFrame();
        try {
            Process proc = rt.exec(getFolderCommand);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(proc.getInputStream()));
            while(proc.isAlive()) {
                String currentString = br.readLine();
                System.out.println(currentString);
                if (currentString.contains("CONNECTION TEST STARTED")) {
                    newFrame.setLabelText("CONNECTION TEST STARTED");
                }

                if (currentString.contains("SECURITY TEST STARTED")) {
                    newFrame.setLabelText("SECURITY TEST STARTED");
                }

                if (currentString.contains("DISCOVERY TEST STARTED")) {
                    newFrame.setLabelText("DISCOVERY TEST STARTED");
                }

                if (currentString.contains("HEARTBEAT TEST STARTED")) {
                    newFrame.setLabelText("HEARTBEAT TEST STARTED");
                }

                if (currentString.contains("FRAMEWORK TEST STARTED")) {
                    newFrame.setLabelText("FRAMEWORK TEST STARTED");
                }

                if (currentString.contains("VIS TEST STARTED")) {
                    newFrame.setLabelText("VIS TEST STARTED");
                }

                if (currentString.contains("BULK TRANSFER TEST STARTED")) {
                    newFrame.setLabelText("BULK TRANSFER TEST STARTED");
                }

                if (currentString.contains("LEGACY TEST STARTED")) {
                    newFrame.setLabelText("LEGACY TEST STARTED");
                }

                if (currentString.contains("ONE USER ONE LOGIN TEST STARTED")) {
                    newFrame.setLabelText("ONE USER ONE LOGIN TEST STARTED");
                }

                if (currentString.contains("CONNECTION TEST COMPLETED")) {
                    newFrame.setLabelText("CONNECTION TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("SECURITY TEST COMPLETED")) {
                    newFrame.setLabelText("SECURITY TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("DISCOVERY TEST COMPLETED")) {
                    newFrame.setLabelText("DISCOVERY TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("HEARTBEAT TEST COMPLETED")) {
                    newFrame.setLabelText("HEARTBEAT TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("FRAMEWORK TEST COMPLETED")) {
                    newFrame.setLabelText("FRAMEWORK TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("VIS TEST COMPLETED")) {
                    newFrame.setLabelText("VIS TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("BULK TRANSFER TEST COMPLETED")) {
                    newFrame.setLabelText("BULK TRANSFER TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("LEGACY TEST COMPLETED")) {
                    newFrame.setLabelText("LEGACY TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }

                if (currentString.contains("ONE USER ONE LOGIN TEST COMPLETED")) {
                    newFrame.setLabelText("ONE USER ONE LOGIN TEST COMPLETED");
                    newFrame.setProgressValue(100 / NumberOfModulesToTest);
                }
            }
        } catch (IOException e) {
          e.printStackTrace();
        }
    }

    
    
    public void runBatchFile(String pathOfBatch, String outputDir) throws InterruptedException, IOException
    {
        //"D:\\Project\\ConnectNext\\Automation\\Sanity.bat"
        final File batchFile = new File(pathOfBatch);

        // The output file. All activity is written to this file
        final File outputFile = new File(String.format(outputDir,
                System.currentTimeMillis()));

        // The argument to the batch file.
        final String argument = "Albert Attard";

        // Create the process
        final ProcessBuilder processBuilder = new ProcessBuilder(batchFile.getAbsolutePath(), argument);
        // Redirect any output (including error) to a file. This avoids deadlocks
        // when the buffers get full.
        processBuilder.redirectErrorStream(true);
        processBuilder.redirectOutput(outputFile);
        processBuilder.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        // Add a new environment variable
        processBuilder.environment().put("message", "Example of process builder");

        // Set the working directory. The batch file will run as if you are in this
        // directory.
        processBuilder.directory(new File("D:\\Project\\ConnectNext\\Automation"));

        // Start the process and wait for it to finish.
        final Process process = processBuilder.start();        
        System.out.println("Process start successfully");           
        
        final int exitStatus = process.waitFor();
        System.out.println("Processed finished with status: " + exitStatus);
	
    }
    
    public String generateXML(ModulesToTest module)
    {
        String finalString=null;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                                "<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\">\n" +
                                "<suite name=\"TML ConnectNext3.0 Test Suite\">\n" +
                                "    <listeners>\n" +
                                "            <listener class-name=\"com.tml.utils.CustomListener\"></listener>\n" +
                                "            <listener class-name=\"com.tml.utils.Annotation\"></listener>\n" +
                                "    </listeners>\n\n");
        
        
        stringBuilder.append("    <test name=\"TML_ConnectNext\">\n");
        if(module.SanityFlag){
            stringBuilder.append("<groups>\n" +
"            <run>\n" +
"                <include name=\"Sanity\"/>\n" +
"            </run>\n" +
"        </groups>\n");
        }
        stringBuilder.append("        <classes>\n");
        
        //************************************************************************************************************
        
        if(module.FunctionalFlag){
            stringBuilder.append("\t<class name=\"com.tml.Connection\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Security\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Discovery\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_Part_No\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vc_info\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vin\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_Variant\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_HUTime\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_tpa_list\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_tpa_State_Change\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_data\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_heartbeat\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigSubsc\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigUnsubscr\"/>\n"); 
            stringBuilder.append("\t<class name=\"com.tml.BulkTransfer\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.OneUser_OneLogin\"/>\n");
             stringBuilder.append("        </classes>\n" +
                                "    </test>\n" +
                                            "\n" +
                                            "\n" +
                            "</suite>");
             finalString = stringBuilder.toString();
             return finalString;
        }
        
        if(module.SanityFlag){
            stringBuilder.append("\t<class name=\"com.tml.Connection\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Security\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Discovery\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_Part_No\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vc_info\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vin\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_Variant\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_HUTime\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_tpa_list\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_tpa_State_Change\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_data\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_heartbeat\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigSubsc\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigUnsubscr\"/>\n"); 
            stringBuilder.append("\t<class name=\"com.tml.BulkTransfer\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.OneUser_OneLogin\"/>\n");
             stringBuilder.append("        </classes>\n" +
                                "    </test>\n" +
                                            "\n" +
                                            "\n" +
                            "</suite>");
             finalString = stringBuilder.toString();
             return finalString;
        }
              
        
        if(module.ConnectionFlag){
            stringBuilder.append("\t<class name=\"com.tml.Connection\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Security\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Discovery\"/>\n");
        }
        
        if(module.FrameworkFlag){
            stringBuilder.append("\t<class name=\"com.tml.Framework_Part_No\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vc_info\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_vin\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_Variant\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_HUTime\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_cn_tpa_list\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Framework_tpa_State_Change\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_data\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.Generic_TPA_cn_tpa_heartbeat\"/>\n");
                      
        }        
        
        if(module.VISFlag){
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigSubsc\"/>\n");
            stringBuilder.append("\t<class name=\"com.tml.VIS_sigUnsubscr\"/>\n");            
        }
        
        if(module.BulkTransferFlag){
            stringBuilder.append("\t<class name=\"com.tml.BulkTransfer\"/>\n");            
        }
        
        if(module.OneUserOneLoginFlag){
            stringBuilder.append("\t<class name=\"com.tml.OneUser_OneLogin\"/>\n");  
        }
        
        if(module.LegacyFlag){
            stringBuilder.append("\t<class name=\"com.tml.OneUser_OneLogin\"/>\n");
        }
       
        //************************************************************************************************************
        stringBuilder.append("        </classes>\n" +
                                "    </test>\n" +
                                            "\n" +
                                            "\n" +
                            "</suite>");
        
        
        finalString = stringBuilder.toString();
        return finalString;
    }
}
