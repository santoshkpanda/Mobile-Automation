package TestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class PropertiesReader {
	
	public static String getData(String input){
		//File file = new File(System.getProperty("user.dir")+"\\data\\config.properties");
                try {
                File file = new File(System.getProperty("user.dir")+"\\data\\config.properties");
		FileInputStream fileInput = null;
		
			fileInput = new FileInputStream(file);
		
		Properties prop = new Properties();
		
			prop.load(fileInput);
                        return	prop.getProperty(input);
		} catch (IOException e) {
			e.printStackTrace();
		}

	return null;
		
	}
	
        
        public static void setData(List<String[]> dataToDump) throws IOException{
		//File file = new File();
                
                FileInputStream in = new FileInputStream(System.getProperty("user.dir")+"\\data\\config.properties");
                Properties props = new Properties();
                props.load(in);
                in.close();

                FileOutputStream out = new FileOutputStream(System.getProperty("user.dir")+"\\data\\config.properties");
                for (Iterator<String[]> iterator = dataToDump.iterator(); iterator.hasNext();) {
                        String[] next = iterator.next();
                        props.setProperty(next[0], next[1]);
                    }   
                //props.setProperty("country", "america");
                props.store(out, null);
                out.close();
                
                
//                
//                File file = new File("D:\\Project\\ConnectNext\\Automation\\data\\config.properties");
//		FileInputStream fileInput = null;
//                FileWriter writer = new FileWriter("D:\\Project\\ConnectNext\\Automation\\data\\config.properties");
//                
//		try {
//			fileInput = new FileInputStream(file);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		Properties prop = new Properties();
//		try {
//			prop.load(fileInput);
//                          
//                                             
//                        prop.store(writer, "");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}              
//		
	}
        
        public static void writeConfigFile(){
            File configFile = new File("config.properties");
            
        }
	
}
