/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestRunner;

/**
 *
 * @author mayur
 */
public class ModulesToTest {
    boolean ConnectionFlag=false;
    boolean FrameworkFlag = false;
    boolean VISFlag=false;
    boolean BulkTransferFlag=false;
    boolean LegacyFlag = false;
    boolean FunctionalFlag = false;
    boolean SanityFlag = false;
    boolean OneUserOneLoginFlag = false;
   
    
}
