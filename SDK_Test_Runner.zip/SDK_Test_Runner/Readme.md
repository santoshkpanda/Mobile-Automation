Instructions:
1. Copy the code in root folder of ConnectNext SDK Test Automation
2. There should be "config.properties" file in location "./data/config.properties"
