"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '05 Oct 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Contacts:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/contacts.json')

    def contacts_app_launch(self):
        """
        Name          : contacts_app_launch
        Description   : This method is to launch contacts app
        Pre-requisite : App list must be opened
        Input         : NA
        Return        : NA
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.app_name)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_open_more_option(self):
        """
        Name          : contacts_open_more_option
        Description   : This method is to open more options in contacts app
        Pre-requisite : Contacts app must be opened
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("More options")
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_close_more_option(self): #TODO Pallavi remove this methods
        """
        Name          : contacts_close_more_option
        Description   : This method is to close more options popup in contacts app
        Pre-requisite : More options popup must be open in contacts app
        Input         : NA
        Return        : NA
        """
        device.pressBack()

    def contacts_open_contact_select_screen(self):
        """
        Name          : contacts_open_contact_select
        Description   : This method is to open select contacts screen
        Pre-requisite : More options popup must be open in contacts app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.select.text)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_open_contact_select_all(self):
        """
        Name          : contacts_open_contact_select_all
        Description   : This method is to select all contacts
        Pre-requisite : More options popup must be open in contacts app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.select_all.text)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_delete_selected_contacts(self):#TODO
        """
        Name          : contacts_open_contact_select_all
        Description   : This method is to select all contacts
        Pre-requisite : Contact must be selected with 'Select' or 'Select all' from more options
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.text_view.delete.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_handle_popup_actions(self, index):
        """
        Name          : bluetooth_handle_popup_actions
        Description   : This method is handle all pop up actions in bluetooth module
        Pre-requisite : Popup must be opened from bluetooth module
        Input         : index- enter 0-1 for action to take on forget device dialog like "CANCEL", "FORGET DEVICE", "RENAME"
        Return        : NA
        """
        dialog_actions = [self.data_model.buttons.cancel.text, self.data_model.buttons.delete.text, self.data_model.buttons.ok.text]
        device.tapText(dialog_actions[index])
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_open_details_screen(self, contact_name):#TODO
        """
        Name          : contacts_open_details_screen
        Description   : This method is to open contacts details screen
        Pre-requisite : Contacts app must be opened and have at least one contact available
        Input         : contactName- name of the contact to open details screen
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(contact_name)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_open_create_contact_screen(self):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Contacts app must be opened
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.buttons.create_contact.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)

        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # # close keyboard TODO Pallavi
        # device.pressBack()
        # time.sleep(config.SLEEP_TIME_LOW)
        #
        # device.refreshView(uiautomatorDump=True)
        # time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_enter_first_name_create_contact(self, first_name):
        """
        Name          : contacts_enter_first_name_create_contact
        Description   : This method is to enter enter first name on create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : first_name- contact persons first name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.first_name.text)
        device_conn.sendType(first_name)
        # close keyboard
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_enter_last_name_create_contact(self, last_name):
        """
        Name          : contacts_enter_last_name_create_contact
        Description   : This method is to enter enter last name on create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : last_name- contact persons last name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.last_name.text)
        device_conn.sendType(last_name)
        # close keyboard
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_enter_phone_create_contact(self, phone_number):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : phone_number- contact persons phone number in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.phone.text)
        device_conn.sendType(phone_number)
        # close keyboard
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_enter_mobile_phone_create_contact(self, index, custom_name=None):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : index- enter 0-20 for predefined mobile phone single selection list
                        custom_name- custom option for mobile phone in string format, its mendatory parameter for index 7
        Return        : NA
        """
        device.tapContentDesc(self.data_model.spinner.phone.mobile_text.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        if index > 8:
            device.swipeText(Constant.CREATE_CONTACT_MOBILE_PHONE_LIST[0], "north")
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        if index > 17:
            device.swipeText(Constant.CREATE_CONTACT_MOBILE_PHONE_LIST[9], "north")
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)


        tap_successful = device.tapText(Constant.CREATE_CONTACT_MOBILE_PHONE_LIST[index])
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        if index == 7: # custom
            device_conn.sendType(custom_name)
            self.contacts_handle_popup_actions(2)
            #device.tapText("OK")
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # to dissmiss keyboard
        device.pressBack()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_enter_email_create_contact(self, email):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : email- contact persons email in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.email.text)
        device_conn.sendType(email)
        # close keyboard
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_enter_home_email_create_contact(self, index, custom_name=None):  # TODO with dynamic name as parameter
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : index- enter 0-4 for predefined mobile phone single selection list
                        custom_name- custom option for home email in string format, its mendatory parameter for index 4
        Return        : NA
        """
        device.tapContentDesc(self.data_model.spinner.email.home_text.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(Constant.CREATE_CONTACT_HOME_EMAIL_LIST[index])
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        if index == 4:  # custom
            device_conn.sendType(custom_name)
            self.contacts_handle_popup_actions(2)
            #device.tapText("OK")
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        # to dissmiss keyboard
        device.pressBack()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_save_contact(self):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Contacts app must be opened
        Input         : NA
        Return        : NA
        """
        device.tapContentDesc(self.data_model.buttons.save.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # close details screen and back to contact's home page
        # device.pressBack()
        # device.refreshView(uiautomatorDump=True)
        # time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_create_open_more_fields(self):
        """
        Name          : contacts_create_open_more_fields
        Description   : This method is to open more field from create contact screen
        Pre-requisite : Create contacts screen must be opened from Contacts app
        Input         : NA
        Return        : NA
        """
        device.tapText("More fields")

        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def contacts_enter_phonetic_fname_create_contact(self, phonetic_fname):
        """
        Name          : contacts_enter_phonetic_fname_create_contact
        Description   : This method is to enter enter phonetic first name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : phonetic_fname- contact persons phonetic first name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.phonetic_first_name.text)
        device_conn.sendType(phonetic_fname)

    def contacts_enter_phonetic_lname_create_contact(self, phonetic_lname):
        """
        Name          :contacts_enter_phonetic_lname_create_contact
        Description   : This method is to enter phonetic last name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : phonetic_fname- contact persons phonetic first name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.phonetic_last_name.text)
        device_conn.sendType(phonetic_lname)

    def contacts_enter_phonetic_mname_create_contact(self, phonetic_mname):
        """
        Name          : contacts_enter_phonetic_mname_create_contact
        Description   : This method is to enter phonetic last name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : last_name- contact persons last name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.phonetic_middle_name.text)
        device_conn.sendType(phonetic_mname)

    def contacts_enter_nickname_create_contact(self, nick_name):
        """
        Name          : contacts_enter_nickname_create_contact
        Description   : This method is to enter nick name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : nick_name- contact persons nick name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.nickname.text)
        device_conn.sendType(nick_name)

    def contacts_enter_company_create_contact(self, company_name):
        """
        Name          : contacts_enter_company_create_contact
        Description   : This method is to enter company name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : company_name- contact persons company name in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.company.text)
        device_conn.sendType(company_name)

    def contacts_enter_title_create_contact(self, title):
        """
        Name          : contacts_enter_title_create_contact
        Description   : This method is to enter title name on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : title- contact persons title in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.title.text)
        device_conn.sendType(title)

    def contacts_enter_SIP_create_contact(self, sip):
        """
        Name          : contacts_enter_SIP_create_contact
        Description   : This method is to enter SIP value on create contacts screen in contacts app
        Pre-requisite : 'More fields' should be opened from Create contacts screen in Contacts app
        Input         : sip - contact persons SIP value in string format
        Return        : NA
        """
        device.tapText(self.data_model.edit_text.sip.text)
        device_conn.sendType(sip)

    def contacts_app_close(self):
        """
        Name          : phone_app_close
        Description   : This method is to close Contacts app
        Pre-requisite : Phone app should be open
        Input         : NA
        Return        : NA
        """
        common.close_application(self.data_model.image_view.dismiss_contacts.content_desc)

    def contacts_is_contacts_available(self):
        """
         Name          : contacts_tap_on_send_icon_message_app
         Description   : This method taps on the send option in message app
         Pre-requisite : The message should be present in the text editor
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.no_contacts_yet.text)
        time.sleep(config.SLEEP_TIME_LOW)


    def contacts_create(self): #TODO Pallavi move this to function test case as it not library function
        """
        Name          : contacts_create
        Description   : This method is to create contact with first name, last name and pphone number app
        Pre-requisite : Contacts app must be opened
        Input         : NA
        Return        : NA
        """
        self.contacts_open_create_contact_screen()
        self.contacts_enter_first_name_create_contact(config.FIRST_NAME)
        self.contacts_enter_last_name_create_contact(config.LAST_NAME)
        self.contacts_enter_phone_create_contact(config.PHONE_NO)
        self.contacts_save_contact()

    def contacts_name_available_in_list(self, fname, lname):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Contacts list must be opened having atleast one contact
        Input         : NA
        Return        : NA
        """
        name = fname+" "+lname
        print(name)
        is_contact_available = common.scroll_up_search_text(name)
        return is_contact_available

    def contacts_is_contact_list_empty(self):
        """
         Name          : contacts_is_contact_list_empty
         Description   : This method taps on the send option in message app
         Pre-requisite : The message should be present in the text editor
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_contact_list_empty = device.verifyText(self.data_model.text_view.no_contacts_yet.text)
        print(is_contact_list_empty)
        return is_contact_list_empty

    def contacts_delete_all_contact(self):
        """
        Name          : contacts_open_create_contact_screen
        Description   : This method is to create contacts screen in contacts app
        Pre-requisite : Contacts list must be opened having atleast one contact
        Input         : NA
        Return        : NA
        """
        self.contacts_open_more_option()
        self.contacts_open_contact_select_all()
        self.contacts_delete_selected_contacts()
        self.contacts_handle_popup_actions(1)

    def contacts_tap_on_saved_number(self):
        """
        Name          : contacts_tap_on_saved_number
        Description   : This method taps on a specified saved number
        Pre-requisite : The number that is saved must be configurable
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(config.SAVED_PHONE_NAME)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_call_the_saved_number(self):
        """
        Name          : contacts_call_the_saved_number
        Description   : This method calls the taped number
        Pre-requisite : The number that is saved must be configurable
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("Call Mobile 98765 4321")
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_end_ongoing_call(self):
        """
         Name          : contacts_end_ongoing_call
         Description   : This method ends the ongoing call
         Pre-requisite : The call must be ongoing
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("End call")
        time.sleep(config.SLEEP_TIME_LOW)


    def contacts_tap_on_share_option(self):
        """
        Name          : contacts_tap_on_share_option
        Description   : This method taps on the 'share' option
        Pre-requisite : The saved contact must be tapped
        Input         : NA
        Return        : NA
        """
        common.dialer_more_options()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Share")
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_select_message_app_to_share_the_contact(self):
        """
         Name          : contacts_select_message_app_to_share_the_contact
         Description   : This method selects the message app to share the selected contact
         Pre-requisite : The message app must be installed
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Messaging")
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_share_the_contact(self):
        """
          Name          : contacts_share_the_contact
          Description   : This method shares the selected number
          Pre-requisite : There should be a sim card inserted
          Input         : NA
          Return        : NA
          """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(config.SAVED_PHONE_NAME)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("Send Message")
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()

    def contacts_tap_on_message_icon_in_contact_app(self):
        """
         Name          : contacts_tap_on_message_icon_in_contact_app
         Description   : This method taps on the message icon
         Pre-requisite : The saved number must be tapped
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("Text 98765 4321")
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_write_message_to_saved_number(self):
        """
         Name          : contacts_write_message_to_saved_number
         Description   : This method writes a message in the text editor in message app
         Pre-requisite : The message to be sent must be configured
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Send message")
        time.sleep(config.SLEEP_TIME_LOW)
        device_conn.sendType(config.CONTACTS_MESSAGE)
        time.sleep(config.SLEEP_TIME_LOW)

    def contacts_tap_on_send_icon_message_app(self):
        """
         Name          : contacts_tap_on_send_icon_message_app
         Description   : This method taps on the send option in message app
         Pre-requisite : The message should be present in the text editor
         Input         : NA
         Return        : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("Send Message")
        time.sleep(config.SLEEP_TIME_LOW)



