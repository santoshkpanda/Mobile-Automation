#!/bin/bash
NOW=$(date +"%m-%d-%Y-%T")
#while true; do
    sleep 5
    robot -d Results/$NOW/PixelXL12/MasterSequence/ MasterSequence.robot
    #robot -d Results/$NOW/PixelXL12/MasterStress/ MasterStress.robot
#done

#echo "Test message"

#echo "env variable"
#echo $PATH;

#robot MasterSequence.robot


