"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__Author__ = 'Pradnya Bargal'
__Email__ = 'pradnya.bargal@darkmatter.ae'
__Version__ = '1.0'
__Date__='04 Oct 2018'

import fmbtandroid
import time
import WiFi
import Constants as Constant
import CommonFunctions
import MobileData
import DeviceScreen
from Config import Configuration as config
import pdb

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
mobile_data = MobileData.MobileData()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
device_screen = DeviceScreen.DeviceScreen()


class FileDownload:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/File_Download.json')
        pass

    def browser_screen_lock(self):
        """
        Function Name   : browser_screen_lock
        Description     : This method opens the lock screen
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : NA
        """
        device_screen.open_screen_lock()

    def browser_launch(self):
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.File_Download.text_view.app_text.text)
        return flag

    def browser_open_image(self):
        """
        Function Name   : browser_open_image
        Description     : This method opens the image in the browser
        Prerequisites   : The URL to the image must be given
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.File_Download.text_view.enter_link.text)
        if flag:
            device_conn.sendType(config.LINK)
            device.shellSOE(config.ENTER)
            time.sleep(Constant.OPEN_IMAGE)
        return flag

    def download_image(self):
        """
        Function Name   : download_image
        Description     : This method download the given image
        Prerequisites   : Image should appear on the screen in the browser
        Input           : NA
        Return          : NA
        """
        common.long_press_at_device_center()
        time.sleep(config.SLEEP_TIME_MEDIUM)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.File_Download.text_view.select_download_image_option.text)
        if flag:
            flag = self.handle_pop_up_box(self.data_model.File_Download.handle_pop_up_box.download.text)
        return flag

    def handle_pop_up_box(self, txt):
        """
         Function Name   : dialer_handle_pop_up_box
         Description     : This method taps on the input text provided
         Prerequisites   : A screen containing a pop up box must appear on the screen
         Input           : txt : It is a string which represents various pop up options like "DELETE" or "BLOCK" etc
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(txt)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def browser_close(self):
        """
        Function Name   : browser_close
        Description     : This method closes the Browser
        Prerequisites   : The browser app must be on
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        common.close_application(self.data_model.File_Download.Buttons.close_app.content_desc)

    def download_file_via_wifi(self):
        """
        Function Name   : download_file_via_wifi
        Description     : This method downloads a specific image using the enabled Wifi Network
        Prerequisites   : URL to the image must be configured
        Input           : NA
        Return          : NA
        """
        wifi = WiFi.WiFi()
        wifi.wifi_enable()
        flag = self.browser_launch()
        if flag:
            flag = self.browser_open_image()
            if flag:
                flag = self.download_image()
                if flag:
                    device.pressBack()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.pressBack()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.browser_close()
        return flag

    def download_file_via_mobile_data(self):
        """
        Function Name   : download_file_via_mobile_data
        Description     : This method downloads a specific image using the mobile data
        Prerequisites   : URL to the image must be configured
        Input           : NA
        Return          : NA
        """
        mobile_data.mobile_data_enable_disable_via_UI()
        flag = self.browser_launch()
        if flag:
            flag = self.browser_open_image()
            if flag:
                flag = self.download_image()
                if flag:
                    device.pressBack()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.pressBack()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.browser_close()
        return flag


# obj = FileDownload()
# obj.download_file_via_mobile_data()
# obj.download_file_via_wifi()
