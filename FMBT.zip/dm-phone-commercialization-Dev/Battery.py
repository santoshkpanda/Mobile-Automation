"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import time
from Config import Configuration as config

device = fmbtandroid.Device()


class Battery:

    def __init__(self):
        pass

    def battery_charging_disable(self):
        """
        Name          : battery_charging_disable
        Description   : This method is to Turn Charging Off
        Pre-requisite : Device charging Should be enable
        input         : NA
        Return        : NA
        """
        device.shellSOE("dumpsys battery set ac 0")
        device.shellSOE("dumpsys battery set usb 0")
        time.sleep(config.SLEEP_TIME_LOW)

    def battery_charging_enable(self):
        """
          Name          : battery_charging_enable
          Description   : This method is to Turn Charging On
          Pre-requisite : Device charging Should be disable
          input         : NA
          Return        : NA
          """
        device.shellSOE("dumpsys battery set ac 1")
        device.shellSOE("dumpsys battery set usb 1")
        time.sleep(config.SLEEP_TIME_LOW)

    def battery_charging_on_enable_status(self):
        """
          Name          : battery_status
          Description   : This method is to check current battery status
          Pre-requisite : Device should be on
          input         : NA
          Return        : True or False
          """
        status = False
        st, out, err = device.shellSOE("dumpsys battery | grep AC")
        if 'true' in out:
            status = True
        return status

    def battery_charging_off_enable_status(self):
        """
          Name          : battery_status
          Description   : This method is to check current battery status
          Pre-requisite : Device should be on
          input         : NA
          Return        : True or False
          """
        status = False
        st, out, err = device.shellSOE("dumpsys battery | grep AC")
        if 'false' in out:
            status = True
        return status









