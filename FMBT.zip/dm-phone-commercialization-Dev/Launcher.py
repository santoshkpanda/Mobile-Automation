"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """


__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Launcher:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/launcher.json')
        pass

    def launcher_launch_home_page(self):
        """
        Name          : launcher_launch_home_page
        Description   : This method is to launch launcher home page
        Pre-requisite : device should on
        input         : NA
        Return        : True or False
        """
        status = device.pressHome()
        return status

    def launcher_scroll_applist(self):
        """
        Name          : launcher_scroll_applist# Todo assertions
        Description   : This method is to open and scroll applist
        Pre-requisite : launcher home page should be launch
        input         : NA
        Return        : NA
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        common.device_screen_swipe_down()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()

    def launcher_back_to_home(self):
        """
        Name          : launcher_back_to_home
        Description   : This method is to open clock application and go to home screen
        Pre-requisite : Application should be launch
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.app_name.text)
        if status:
            time.sleep(config.SLEEP_TIME_LOW)
            status = device.pressHome()
            time.sleep(config.SLEEP_TIME_LOW)
        return status


    def launcher_press_back(self):
        """
        Name          : launcher_press_back
        Description   : This method is to go back to previous screen on device here usecase to open app list and press
                        back to move to home screen
        Pre-requisite : Applist should be opened
        input         : NA
        Return        : True or False
        """
        flag = False
        device.pressHome()
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.app_name.text)
        if status:
            time.sleep(config.SLEEP_TIME_LOW)
            status = device.pressBack()
            if status:
                flag = device.pressHome()
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def launcher_recentapp_clearall(self):
        """
        Name          : launcher_recentapp_clearall
        Description   : This method is to clear recent application list
        Pre-requisite : Multiple applications should be opened previously
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        status = device.pressAppSwitch()
        if status:
            common.device_screen_swipe_down()
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text.clear_all.text)
        return status

    def launcher_open_statusbar(self):
        """
        Name          : launcher_open_statusbar
        Description   : This method is to scroll down the statusbar
        Pre-requisite : NA
        input         : device should be on
        Return        : True or False
        """
        device.pressHome()
        flag = False
        st, out, err = device.shellSOE("service call statusbar 1")
        if st == 0 and out is not None:
            flag = True
        return flag

    def launcher_close_statusbar(self):
        """
        Name          : launcher_close_statusbar
        Description   : This method is to scroll up the statusbar
        Pre-requisite : NA
        input         : NA
        Return        : True or False
        """
        flag = False
        st, out, err = device.shellSOE("service call statusbar 2")
        if st == 0 and out is not None:
            print(out)
            flag = True
        return flag

    def launcher_open_quick_settings(self):
        """
        Name          : launcher_open_quick_settings
        Description   : This method is to expand quick settings and collapse quick settings
        Pre-requisite : NA
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.open_quick_setting.content_desc)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def launcher_close_quick_settings(self):
        """
        Name          : launcher_close_quick_settings
        Description   : This method is to collapse quick settings
        Pre-requisite : statusbar should be open and quick settings should be open
        input         : NA
        Return        : True or False
        """
        # self.launcher_open_quick_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.close_quick_setting.content_desc)
        self. launcher_close_statusbar()
        print status
        return status


    def launcher_overview_panel_select_option(self, index):
        """
        Name          : launcher_overview_panel_select_option
        Description   : This method is to open Home settings,set wallpaper,open widgets
        Pre-requisite : launcher home page should be launch
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        flag = False
        st, out, err = device.shellSOE("input keyevent 82")
        if st == 0 and out is not None:
            flag = True
            if flag:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapText(Constant.OVERVIEW_PANEL_LIST[index])
                time.sleep(config.SLEEP_TIME_LOW)
                device.pressHome()
        return status

    def launcher_google_text_search(self):
        """
        Name          : launcher_google_text_search
        Description   : This method is to search in google in text format
        Pre-requisite : launcher home page should be launch
        Return        : True or False
        """
        flag = False
        device.pressHome()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.search.content_desc)
        if status:
            time.sleep(config.SLEEP_TIME_LOW)
            device_conn.sendType(config.SEARCH_TEXT)
            time.sleep(config.SLEEP_TIME_LOW)
            st, out, err = device.shellSOE("input keyevent 66")
            if st == 0 and out is not None:
                flag =  True
                if flag:
                    device.refreshView(uiautomatorDump=True)
                    time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                    device.pressHome()
        return status























