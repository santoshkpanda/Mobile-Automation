#!/bin/bash
NOW=$(date +"%m-%d-%Y-%T")
sleep 5
# robot -d Results/$NOW/PixelXL12/Functional/AirplaneMode/ --include FUNCTIONAL AirplaneMode.robot
robot -d Results/$NOW/PixelXL12/Functional/Audio/ --include FUNCTIONAL Audio.robot
robot -d Results/$NOW/PixelXL12/Functional/Bluetooth/ --include FUNCTIONAL Bluetooth.robot
# robot -d Results/$NOW/PixelXL12/Functional/Boot/ --include FUNCTIONAL Boot.robot
robot -d Results/$NOW/PixelXL12/Functional/Calculator/ --include FUNCTIONAL Calculator.robot
robot -d Results/$NOW/PixelXL12/Functional/clock/ --include FUNCTIONAL clock.robot
robot -d Results/$NOW/PixelXL12/Functional/Contacts/ --include FUNCTIONAL Contacts.robot
#robot -d Results/$NOW/PixelXL12/Functional/HardwareSwitch/ --include FUNCTIONAL HardwareSwitch.robot
#robot -d Results/$NOW/PixelXL12/Functional/Launcher/ --include FUNCTIONAL Launcher.robot
#robot -d Results/$NOW/PixelXL12/Functional/Location/ --include FUNCTIONAL Location.robot
#robot -d Results/$NOW/PixelXL12/Functional/Messaging/ --include FUNCTIONAL Messaging.robot
#robot -d Results/$NOW/PixelXL12/Functional/WiFi/ --include FUNCTIONAL WiFi.robot




