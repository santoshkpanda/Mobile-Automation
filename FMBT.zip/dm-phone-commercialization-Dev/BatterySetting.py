"""
# Copyright (C) 2016, Dark Matter LLC. All rights Reserved
# This software and/or source code may be used, copied and/or disseminated only
# with the written permission of Dark Matter LLC, or in accordance with the terms
# and conditions stipulated in the agreement/contract under which the software
# and/or source code has been supplied by Dark Matter LLC or its affiliates.
# Unauthorized use, copying, or dissemination of this file, via any medium, is
# strictly prohibited, and will constitute an infringement of copyright.


__Author__ = "Dimple Bhat"
__Email__ = "dimple.bhat@darkmatter.ae"
__Version__ = "1.0"
__Date__ = '17 Nov 2018'
"""
import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config
import BaseSettings

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
base_settings = BaseSettings.BaseSettings()


class BatterySetting:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Battery.json')
        pass
    def settings_launch(self):
        """
        Name            : settings_launch
        Description     : This method is use to launch setting.
        Pre-requisites  : NA
        Input           : NA
        Return          : NA

        """
        base_settings.setting_app_open_via_UI()

    def battery_settings_launch(self):
        """
        Name            : battery_settings_launch
        Description     : This method is use to open battery settings from setting.
        Pre-requisites  : Device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery.text)
        return status

    # def battery_advanced_battery_usage(self):
    #     """
    #     Name            : battery_advanced_battery_usage
    #     Description     : This method is use to open battery advanced battery usage option from battery settings from setting.
    #     Pre-requisites  : Battery settings from device settings should be open
    #     Input           : NA
    #     Return          : NA
    #
    #     """
    #     device.refreshView(uiautomatorDump=True)
    #     time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
    #     status = device.tapText("Charging")
    #     while not status:            status = common.scroll_up_search_text("Play Music")
    #     device.refreshView(uiautomatorDump=True)
    #     device.tapText("Charging")
    #     time.sleep(config.SLEEP_TIME_LOW)
    #     return status
    #     # time.sleep(config.SLEEP_TIME_LOW)
    #     device.pressBack()

    def battery_saver(self):
        """
        Name            : battery_saver
        Description     : This method is use to open battery saver option from battery settings from setting.
        Pre-requisites  : Battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.Battery_saver.text)
        print status
        return status

    def battery_set_saver_time(self,index):
        """
        Name            : battery_saver
        Description     : This method is use to open battery saver option from battery settings from setting.
        Pre-requisites  : Battery saver from battery settings from device settings should be open
        Input           : index : set time for  start battery saver
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.labels.battery_set_saver_time.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(Constant.BATTERY_SAVER_SET_TIME[index])
        print status
        return status

    def show_battery_percentage_on_off(self):
        """
        Name            : show_battery_percentage_on_off
        Description     : This method is use to open show battery percentage on off option from battery settings from setting.
        Pre-requisites  : battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.show_battery_percentage_on_off.text)
        return status

    def battery_adaptive_brightness_on_off(self):
        """
        Name            : battery_adaptive_brightness_on_off
        Description     : This method is use to open adaptive brightness on off option from battery settings from setting.
        Pre-requisites  : battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_adaptive_brightness_on_off.text)
        return status

    def battery_ambient_display(self):
        """
        Name            : battery_Ambient_display
        Description     : This method is use to open battery ambient display option from battery settings from setting.
        Pre-requisites  : battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_ambient_display.text)
        return status

    def battery_ambient_display_setting_tap_check_phone_on_off(self):
        """
        Name            : battery_ambient_display_setting_tap_check_phone_on_off
        Description     : This method is use to open tap check phone on and off from battery ambient display option from battery settings from setting.
        Pre-requisites  : battery ambient display from battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_ambient_display_setting_tap_check_phone_on_off.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.labels.text)
            if status:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapContentDesc(self.data_model.labels.battery_ambient_display_setting_tap_check_phone_on_off.ContentDesc)
        return status

    def battery_ambient_lift_to_check_phone(self):
        """
        Name            : battery_ambient_lift_to_check_phone
        Description     : This method is use to open battery ambient lift to check phone option  from battery ambient display option of the  battery settings from setting.
        Pre-requisites  : battery ambient display from battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_ambient_lift_to_check_phone.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.labels.battery_ambient_lift_to_check_phone.text1)
            if status:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapContentDesc(self.data_model.labels.battery_ambient_lift_to_check_phone.ContentDesc)
        return status

    def battery_new_notifications_on_off(self):
        """
        Name            : battery_new_notifications_on_off
        Description     : This method is use to open new notification option from  the  battery settings from setting.
        Pre-requisites  : battery settings from device settings should be open
        Input           : NA
        Return          : NA

        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_new_notifications_on_off.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapContentDesc(self.data_model.labels.battery_new_notifications_on_off.ContentDesc)
        return status

    def battery_sleep_time_inactivity(self, index):
        """
        Name            : battery_sleep_time_inactivity
        Description     : This method is use to set battery sleep inactivity time from battery settings from setting.
        Pre-requisites  : Battery saver from battery settings from device settings should be open
        Input           : index : set time for battery sleep inactivity time
        Return          : NA

        """
        common.device_screen_swipe_down()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.labels.battery_sleep_time_inactivity.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(Constant.SLEEP_TIME_INACTIVE[index])
        return status

    def battery_close_settings(self):
        """
        Name          : battery_close_settings
        Description   : This method is to close battery setting application
        Pre-requisite : battery setting application should be open
        input         : NA
        Return        : NA
        """
        common.close_application("Dismiss Settings.")

#
# bat = BatterySetting()
# bat.settings_launch()
# bat.battery_settings_launch()
# # bat.battery_advanced_battery_usage()
# # bat.battery_saver()
# # bat.battery_set_saver_time(1)
# # bat.show_battery_percentage_on_off()
# # bat.battery_adaptive_brightness_on_off()
# # bat.battery_sleep_time_inactivity(1)
# bat.battery_ambient_display()
# bat.battery_ambient_display_setting_tap_check_phone_on_off()
# bat.battery_ambient_lift_to_check_phone()
# bat.battery_new_notifications_on_off()
# bat.battery_close_settings()
# bat.battery_saver()
# bat.battery_set_saver_time(1)
# bat.battery_set_saver_time(1)