"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '08 Oct 2018'

import fmbtandroid
import time
from Config import Configuration as config

device = fmbtandroid.Device()


class HardwareSwitch:

    def __init__(self):
        pass

    def power_btn_screen_on(self):
        """
        Name          : power_btn_screen_on
        Description   : This method is to power on the device
        Pre-requisite : Device's adb shell should be accessible
        input         : NA
        Return        : NA
        """
        device.shellSOE("input keyevent 26")
        time.sleep(config.SLEEP_TIME_LOW)


    def power_btn_screen_off(self):
        """
        Name          : power_btn_screen_off
        Description   : This method is to power off the device
        Pre-requisite : Device's adb shell should be accessible
        input         : NA
        Return        : NA
        """
        device.shellSOE("input keyevent 26")
        time.sleep(config.SLEEP_TIME_LOW)

    def volume_up(self):
        """
        Name          : volume_up
        Description   : This method is to volume UP
        Pre-requisite : Device's adb shell should be accessible
        input         : NA
        Return        : NA
        """
        device.pressVolumeUp()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressVolumeUp()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressVolumeUp()
        time.sleep(config.SLEEP_TIME_LOW)

    def volume_down(self):
        """
        Name          : volume_down
        Description   : This method is to volume DOWN
        Pre-requisite : Device's adb shell should be accessible
        input         : NA
        Return        : NA
        """
        device.pressVolumeDown()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressVolumeDown()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressVolumeDown()
        time.sleep(config.SLEEP_TIME_LOW)






