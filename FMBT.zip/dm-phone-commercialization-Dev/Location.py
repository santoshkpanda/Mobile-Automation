"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
*
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '05 Oct 2018'

import fmbtandroid
import time
import subprocess
import Constants as Constant
import CommonFunctions
import BaseSettings
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
settings = BaseSettings.BaseSettings()


class Location:
    def __init__(self):
        pass

    def get_location_providers(self):
        """
        Name          : get_location_providers
        Description   : This method is to get available Location Provider
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Return comma separated list of available location provider
        """
        proc = subprocess.Popen("adb shell settings get secure location_providers_allowed", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        output = proc.stdout.readline()
        return output.rstrip()

    def gps_provider_enable(self):
        """
        Name          : gps_provider_enable
        Description   : This method is to turn GPS Location Provider On
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put secure location_providers_allowed +gps", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def network_provider_enable(self):
        """
        Name          : network_provider_enable
        Description   : This method is to turn Network Location Provider On
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put secure location_providers_allowed +network", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def gps_provider_disable(self):
        """
        Name          : gps_provider_disable
        Description   : This method is to turn GPS Location Provider Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put secure location_providers_allowed -gps", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def network_provider_disable(self):
        """
        Name          : network_provider_disable
        Description   : This method is to turn Network Location Provider Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put secure location_providers_allowed -network",
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def assert_location_provider_state(self, actual_output, expected_output):
        """
        Name          : assert_location_provider_state
        Description   : This method is to Location Provider changed state
        Pre-requisite : Device's adb shell should be accessible
        Input         : actual_output-  output return by get_airplane_mode_state after change in state
                        expected_output-    This is expected output after change in state
        Return        : NA
        """
        print("Asserting Network Provider changed state ...")
        print(actual_output + "==" + expected_output)
        assert actual_output == expected_output
        if 'gps' in actual_output and 'network' not in actual_output:
            print("Only GPS location provider available")
        elif 'network' in actual_output and 'gps' not in actual_output:
            print("Only Network location provider available")
        elif 'gps,network' in actual_output:
            print("Both GPS and Network location provider available")
        elif '' == actual_output:
            print("No location provider Available")
        else:
            print("Invalid location Provider")

    def security_and_location_open(self):
        """
        Name          : security_and_location_open
        Description   : This method is to Open Security and Location setting from Device's Setting App
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        settings.setting_app_launch_via_adb()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.swipeText("Network & Internet", "north")
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Security & location")
        time.sleep(config.SLEEP_TIME_LOW)

    def location_setting_open(self):
        """
        Name          : location_setting_open
        Description   : This method is to open Location setting open from Device Setting app
        Pre-requisite : Need to open Security and Location setting from device's settings app
        Input         : NA
        Return        : NA
        """
        self.security_and_location_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.swipeText("Google Play Protect", "north")
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Location")
        time.sleep(config.SLEEP_TIME_LOW)

    def handle_improve_location_accuracy_popup(self):
        """
        Name          : handle_improve_location_accuracy_popup
        Description   : This method is to handle location service improve accuracy popup from Location setting under
                        Device's Setting app while changing accuracy from Device only to Battery saving or High accuracy
        Pre-requisite : Need to open Location mode from Location setting from device's settings app and change accuracy
                        from Device only to Battery saving or High accuracy
        Input         : NA
        Return        : NA
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_tapped = device.tapText("AGREE")
        if is_tapped:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def set_location_enabled(self):
        """
        Name          : set_location_enabled
        Description   : This method is to turn Location Service On by enabling all location providers
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        self.gps_provider_enable()
        self.network_provider_enable()
        self.handle_improve_location_accuracy_popup()

    def set_location_disable(self):
        """
        Name          : set_location_disable
        Description   : This method is to turn Location Service Off by disabling all location providers
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        self.gps_provider_disable()
        self.network_provider_disable()

    def location_mode_open(self):
        """
        Name          : location_mode_open
        Description   : This method is to open location mode setting open from Device Setting app
        Pre-requisite : Need to open Location setting from device's settings app
        Input         : NA
        Return        : NA
        """
        self.location_setting_open()
        self.set_location_enabled()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Mode")
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def set_location_mode_high_accuracy(self):
        """
        Name          : set_location_mode_high_accuracy
        Description   : This method is to set location mode to high accuracy from Device Setting app
        Pre-requisite : Need to open Location mode setting from device's settings app
        Input         : NA
        Return        : NA
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.tapText("High accuracy")

    def set_location_mode_battery_saving(self):
        """
        Name          : set_location_mode_battery_saving
        Description   : This method is to set location mode to battery saving from Device Setting app
        Pre-requisite : Need to open Location mode setting from device's settings app
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.tapText("Battery saving")

    def set_location_mode_device_only(self):
        """
        Name          : set_location_mode_battery_saving
        Description   : This method is to set location mode to device only from Device Setting app
        Pre-requisite : Need to open Location mode setting from device's settings app
        Input         : NA
        Return        : NA
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.tapText("Device only")

    def location_setting_close(self):
        """
        Name          : location_setting_close
        Description   : This method is to close location setting and move to home screen
        Pre-requisite : location setting page should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        device.pressBack()
        self.set_location_disable()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()

    def location_mode_change_in_sequence(self):
        """
        Name          : location_mode_change_in_sequence
        Description   : This method is to change location mode in sequence
        Pre-requisite : location setting page should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        self.location_mode_open()
        self.set_location_mode_high_accuracy()
        self.set_location_mode_battery_saving()
        self.set_location_mode_device_only()
        self.location_setting_close()

    def maps_app_launch_close(self): #TODO Pallavi move to map file
        """
        Name          : maps_app_launch
        Description   : This method is to launch Maps app
        Pre-requisite : Home screen should be open.
        Input         : NA
        Return        : NA
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Maps")
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # close
        device.pressBack()
        device.pressBack()

    def get_current_location(self):
        """
        Name          : get_device_current_location
        Description   : This method is to get current location of device
        Pre-requisite : NA(location service should be enable and Map application should be launch once.)
        Input         : NA
        Return        : NA
        """
        self.set_location_enabled()
        self.maps_app_launch_close()
        proc = subprocess.Popen("adb shell dumpsys location | grep \"gps: Location\"", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        output = proc.stdout.readline()
        if len(output) > 0:
            list = output.split()
            return list[2]



