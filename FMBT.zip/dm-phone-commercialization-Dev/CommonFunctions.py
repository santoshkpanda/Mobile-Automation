"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '09 Oct 2018'


import time
import subprocess
import fmbtandroid
from Config import Configuration as config
import Constants as Constant
import json
from collections import namedtuple

"""This modules has class providing common functionalities which will be used through out different modules"""

device = fmbtandroid.Device()


class CommonFunctions:

    def __init__(self):
        pass

    def get_UI_metadata(self, json_file_path):
        """
        Name          : get_UI_metadata
        Description   : This method is to parse json file and get object
        Pre-requisite : NA
        Input         : json_file_path-  json file name with relative path
        Return        : data_model- return python object created from python dictionary after loading json file
        """
        fp = open(json_file_path, 'r')
        data = fp.read()
        data_model = json.loads(data, object_hook=lambda d: namedtuple('Obj', d.keys())(*d.values()))
        return data_model

    def screen_refresh_and_take_screen_shot(self, image_name):
        """
        Name          : screen_refresh_and_take_screen_shot
        Description   : This method is to refresh screen UI and take screen shot
        Pre-requisite : Device's adb shell should be accessible
        Input         : image_name-  name for screen shot image
        Return        : NA
        """
        device.refreshScreenshot().save(config.SCREEN_SHOT_LOCATION+image_name)

    def app_list_open(self):
        """
        Name          : app_list_open
        Description   : This method is to open Device's App List
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc("Apps list")

    def input_keyevent(self, keycode):
        """
        Name          : input_keyevent
        Description   : This method is to open Device's App List
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell input keyevent "+keycode, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def get_USB_connected_device(self, index):
        """
        Name          : get_USB_connected_device
        Description   : This method is to get device from list of USB connected devices at given index
        Pre-requisite : At-least one Android device should be connected to System
        Input         : index- index as integer to get device from USB connected device list
        Return        : NA
        """
        serial_number = fmbtandroid.listSerialNumbers()
        if len(serial_number) >= index:
            return serial_number[index]


    def device_screen_swipe_up(self):
        """
         Name          : device_screen_swipe_up
         Description   : This method is to swipe device screen down from center
         Pre-requisite : device screen should be on
         Input         : NA
         Return        : NA
         """
        size = device.screenSize()
        downx1 = size[0] / 2
        downy1 = int(size[1] / 1.3)
        upx2 = size[0] / 2
        upy2 = int(size[1] / 4.5)
        device_conn = fmbtandroid._AndroidDeviceConnection(self.get_USB_connected_device(0))
        device_conn.sendSwipe(downx1, downy1, upx2, upy2)

    def device_screen_swipe_down(self):#TODO Calculation of center of screen should be separated at common place
        """
        Name          : device_screen_swipe_down
        Description   : This method is to swipe device screen up from center
        Pre-requisite : device screen should be on
        Input         : NA
        Return        : NA
        """
        size = device.screenSize()
        downx2 = size[0] / 2
        downy2 = int(size[1] / 1.3)
        upx1 = size[0] / 2
        upy1 = int(size[1] / 4.5)
        device_conn = fmbtandroid._AndroidDeviceConnection(self.get_USB_connected_device(0))
        device_conn.sendSwipe(upx1, upy1, downx2, downy2)

    def close_application(self, app):
        """
        Name            : close_application
        Description     : This method is to close the application with given content description.
        Pre-requisite :   device screen should be on
        Input           : app- App's cross/dismiss icon content description from app switcher.
        Return          : NA
        """
        device.pressHome()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressAppSwitch()
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(app)
        device.pressHome()

    def long_press_at_device_center(self):
        """
        Name          : long_press_at_device_center
        Description   : This method holds and press the device screen for long press action
        Pre-requisite : device screen should be on
        Input         : NA
        Return        : NA
        """
        size = device.screenSize()
        x1 = size[0]/2
        y1 = size[1]/2
        x2 = x1+3
        y2 = y1+3
        count = 1000
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)

    def get_content_desc_by_id(self, id, index=0):
        """
        Name          : get_content_desc_by_id
        Description   : This method is to get contentDesc by id
        Pre-requisite :
        Input         : UI Automator resource id (for example: id/play_pause)
        Return        : Content Desc
        """

        content = device.refreshView(uiautomatorDump=True).findItemsById(id)[index].content_desc()
        return content

    def get_text_by_id(self, id, index=0):
        """
        Name          : get_content_desc_by_id
        Description   : This method is to get contentDesc by id
        Pre-requisite :
        Input         : UI Automator resource id (for example: id/play_pause)
        Return        : Content Desc
        """

        text = device.refreshView(uiautomatorDump=True).findItemsById(id)[index].text()
        return text

    def scroll_up_search_text(self, text, scroll_count=5): #TODO Pallavi use count for loop iteration
        """
        Name            : scroll_up_search_text
        Description     : This method is use scroll screen up till text is not found using center of device.
        Pre-requisites  : Screen should opened where text search has to be performed with scrolling up the screen
        Input           : text- text for search on the screen
        Return          : True if text found #TODO else infinite loop break
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_found = device.verifyText(text)
        while not is_found:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            self.device_screen_swipe_up()
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            is_found = device.verifyText(text)
        return is_found

    def press_device_back(self):
        """
        Name            : press_device_back
        Description     : This method is to press device back button
        Pre-requisites  : NA
        Input           : NA
        Return          : NA
        """
        device.pressBack()

    def pull_statusbar(self):
        """
        Name          : pull_statusbar
        Description   : This method is to scroll down the statusbar
        Pre-requisite : NA
        input         : device should be on
        Return        : NA
        """
        device.pressHome()
        device.shellSOE("service call statusbar 1")


    def device_screen_swipe_up1(self):
        """
        Name          : device_screen_swipe_up
        Description   : This method is to swipe device screen down from center
        Pre-requisite : device screen should be on
        Input         : NA
        Return        : NA
        """
        size = device.screenSize()
        downx1 = size[0] / 2
        downy1 = int(size[1] / 2.1)
        upx2 = size[0] / 2
        upy2 = int(size[1] / 4.5)
        device_conn = fmbtandroid._AndroidDeviceConnection(self.get_USB_connected_device(0))
        device_conn.sendSwipe(downx1, downy1, upx2, upy2)






