"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__Author__ = 'Pradnya Bargal'
__Email__ = 'pradnya.bargal@darkmatter.ae'
__Version__ = '1.0'
__Date__='24 Oct 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
import DeviceScreen
from Config import Configuration as config


device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_screen = DeviceScreen.DeviceScreen()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Messaging:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Messaging.json')
        pass

    def messaging_open_lock_screen(self):
        """
        Function Name   : messaging_open_lock_screen
        Description     : This method opens the lock screen
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : NA
        """
        device_screen.open_screen_lock()

    def messaging_app_launch(self):
        """
        Function Name   : messaging_app_launch
        Description     : This method opens the messaging app
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : NA
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.message_app.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def handle_pop_up_box(self, txt):
        """
         Function Name   : dialer_handle_pop_up_box
         Description     : This method taps on the input text provided
         Prerequisites   : A screen containing a pop up box must appear on the screen
         Input           : txt : It is a string which represents various pop up options like "DELETE" or "BLOCK" etc
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(txt)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_click_on_add_button_to_start_new_conversation(self):
        """
         Function Name   : messaging_click_on_add_button_to_start_new_conversation
         Description     : This method taps on the add button to start a new conversation
         Prerequisites   : The messaging app must be open
         Input           : NA
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.start_new_conversation.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_select_phone_number(self, index):
        """
         Function Name   : messaging_select_phone_number
         Description     : This method selects one number from contacts
         Prerequisites   : The contact to which message is to be sent must be configured
         Input           : NA
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device_conn.sendType(Constant.SEND_MESSAGE_TO_CONTACT_LIST[index])
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapId(self.data_model.Messaging.linear_layout.select_contact_layout.id)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_select_one_contact(self):
        """
         Function Name   : messaging_select_one_contact
         Description     : This method selects one contact to which the message is to be sent
         Prerequisites   : The contact to which message is to be sent must be configured
         Input           : NA
         Return          : NA
         """
        flag = self.messaging_click_on_add_button_to_start_new_conversation()
        if flag:
            self.messaging_select_phone_number(0)
        return flag

    def messaging_add_more_participants(self):
        """
         Function Name   : messaging_add_more_participants
         Description     : This method clicks on the button add more participants
         Prerequisites   : The contact to which message is to be sent must be configured
         Input           : NA
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.add_more_participants.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_confirm_participants(self):
        """
         Function Name   : messaging_confirm_participants
         Description     : This method clicks on the button confirm participants
         Prerequisites   : The contact to which message is to be sent must be configured
         Input           : NA
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.confirm_participants.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_select_multiple_contacts(self):
        """
          Function Name   : messaging_select_multiple_contacts
          Description     : This method selects multiple contacts to which the message is to be sent
          Prerequisites   : The contacts to which message is to be sent must be configured
          Input           : NA
          Return          : NA
          """
        self.messaging_click_on_add_button_to_start_new_conversation()
        self.messaging_select_phone_number(0)
        self.messaging_add_more_participants()
        self.messaging_select_phone_number(1)
        self.messaging_select_phone_number(2)
        self.messaging_confirm_participants()

    def messaging_write_message(self):
        """
        Function Name   : messaging_write_message
        Description     : This method writes a message in the text area of the messaging app
        Prerequisites   : The message should be configured
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.send_message.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            flag = device_conn.sendType(config.MESSAGE_FROM_MESSAGING_APP)
        return flag

    def messaging_send_message(self):
        """
        Function Name   : messaging_send_message
        Description     : This method sends the message typed in the text area to the selected contact
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapId(self.data_model.Messaging.linear_layout.send_button_layout.id)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_read_received_message(self):
        """
        Function Name   : messaging_read_received_message
        Description     : This method reads the message received from a specific contact
        Prerequisites   : The contact from which the message is received must be configured
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(config.MESSAGE_RECEIVED_FROM)
        if flag:
            time.sleep(config.SLEEP_TIME_MEDIUM)
            self.messaging_navigate_up()
        return flag

    def messaging_navigate_up(self):
        """
        Function Name   : messaging_navigate_up
        Description     : This method clicks on the navigate up button and goes back to the previous page
        Prerequisites   : The navigate up button should be visible
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.navigate_up.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_visit_archived_contacts(self):
        """
        Function Name   : messaging_visit_archived_contacts
        Description     : This method opens the page where message from all the archived contacts are stored
        Prerequisites   : The messaging app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.more_options.content_desc)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Messaging.text_view.archived.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag


    def messaging_visit_blocked_contacts(self):
        """
        Function Name   : messaging_visit_blocked_contacts
        Description     : This method opens the page where message from all the blocked contacts are stored
        Prerequisites   : The messaging app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.more_options.content_desc)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Messaging.text_view.blocked_contacts.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_press_back(self):
        """
        Function Name   : messaging_press_back
        Description     : This method is to press on back button
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        flag = device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag


    def messaging_open_settings(self):
        """
         Function Name   : messaging_open_settings
         Description     : This method opens the settings page
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.more_options.content_desc)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Messaging.text_view.settings.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_set_default_messaging_app(self):
        """
         Function Name   : messaging_set_default_messaging_app
         Description     : This method sets a default messaging app
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.default_messaging_app.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.cancel.text)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_disable_outgoing_message_sounds(self):
        """
         Function Name   : messaging_enable_disable_outgoing_message_sounds
         Description     : This method enables or disables the outgoing message sounds
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.outgoing_messaging_sound.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_visit_notifications_page(self):
        """
         Function Name   : messaging_enable_disable_notifications
         Description     : This method visits the notification page
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.notifications.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_disable_vibrate_option(self):
        """
         Function Name   : messaging_enable_disable_vibrate_option
         Description     : This method enables or disables the vibrate option
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.vibrate.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_set_sound(self):
        """
         Function Name   : messaging_set_sound
         Description     : This method sets the message sound
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.sound.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.OK.text)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_open_advanced_settings(self):
        """
          Function Name   : messaging_open_advanced_settings
          Description     : This method opens the advanced settings page
          Prerequisites   : The messaging app should be open
          Input           : NA
          Return          : NA
          """
        self.messaging_open_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.advanced_settings.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_set_group_messaging_option(self):
        """
         Function Name   : messaging_set_group_messaging_option
         Description     : This method sets group messaging option
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_advanced_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.group_messaging.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.cancel.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_view_your_phone_number(self):
        """
         Function Name   : messaging_view_your_phone_number
         Description     : This method displays the phone number of the SIM in the device
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_advanced_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.text_view.your_phone_number.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.cancel.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_disable_auto_retrieve(self):
        """
         Function Name   : messaging_enable_disable_auto_retrieve
         Description     : This method enables and disables the auto retrieve option
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_advanced_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.auto_retrieve.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_disable_roaming_auto_retrieve(self):
        """
         Function Name   : messaging_enable_disable_roaming_auto_retrieve
         Description     : This method enables or disables the roaming auto retrieve option
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_advanced_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.roaming_auto_retrieve.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_disable_sms_delivery_reports(self):
        """
         Function Name   : messaging_enable_disable_sms_delivery_reports
         Description     : This method enables and disables the SMS delivery reports option
         Prerequisites   : The messaging app should be open
         Input           : NA
         Return          : NA
         """
        self.messaging_open_advanced_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Messaging.Buttons.sms_delivery_reports.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_long_press_contact(self, index):
        """
         Function Name   : messaging_long_press_contact
         Description     : This method holds and presses a contact
         Prerequisites   : The contact must be configured
         Input           : index: The index of the contact which needs to be long pressed
         Return          : NA
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.LONG_PRESS_CONTACT_LIST[index], hold=10)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_archive_conversation(self):
        """
         Function Name   : messaging_archive_contact
         Description     : This method archives messages with a contact
         Prerequisites   : The contact to be archived must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_long_press_contact(0)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.archive.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_unarchive_conversation(self):
        """
         Function Name   : messaging_unarchive_contact
         Description     : This method archives messages with a contact
         Prerequisites   : The contact to be archived must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_visit_archived_contacts()
        time.sleep(config.SLEEP_TIME_LOW)
        self.messaging_long_press_contact(0)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.unarchive.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_delete_conversation(self):
        """
         Function Name   : messaging_delete_contact
         Description     : This method deletes messages with a contact
         Prerequisites   : The contact to be deleted must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_long_press_contact(1)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.delete.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.delete.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_enable_notification_for_conversation(self):
        """
         Function Name   : messaging_enable_notification_for_contact
         Description     : This method enables notification for a contact
         Prerequisites   : The contact must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_long_press_contact(2)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.turn_off_notifications.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_disable_notification_for_conversation(self):
        """
         Function Name   : messaging_disable_notification_for_conversation
         Description     : This method disables notification for a contact
         Prerequisites   : The contact must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_long_press_contact(2)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.turn_on_notifications.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_block_conversation(self):
        """
         Function Name   : messaging_block_conversation
         Description     : This method blocks messages with a contact
         Prerequisites   : The contact to be blocked must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_long_press_contact(2)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.block.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            self.handle_pop_up_box(self.data_model.Messaging.handle_pop_up_box.block.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_unblock_conversation(self):
        """
         Function Name   : messaging_unblock_conversation
         Description     : This method unblocks messages with a contact
         Prerequisites   : The contact to be unblocked must be configured
         Input           : NA
         Return          : NA
         """
        self.messaging_visit_blocked_contacts()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Messaging.Buttons.unblock.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Messaging.handle_pop_up_box.unblock.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                device.pressBack()
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def messaging_app_close(self):
        """
        Function Name   : messaging_app_close
        Description     : This method closes the messaging app
        Prerequisites   : The messaging app must be open
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        common.close_application(self.data_model.Messaging.Buttons.close_app.content_desc)


"""obj = Messaging()
obj.messaging_app_launch()
obj.messaging_click_on_add_button_to_start_new_conversation()
obj.messaging_select_one_contact()
obj.messaging_write_message()
obj.messaging_send_message()
obj.messaging_select_multiple_contacts()
obj.messaging_write_message()
obj.messaging_send_message()
obj.messaging_read_received_message()
obj.messaging_visit_archived_contacts()
obj.messaging_navigate_up()
obj.messaging_visit_blocked_contacts()
obj.messaging_navigate_up()
obj.messaging_set_default_messaging_app()
obj.messaging_enable_disable_outgoing_message_sounds()
obj.messaging_open_advanced_settings()
obj.messaging_set_group_messaging_option()
obj.messaging_view_your_phone_number()
obj.messaging_enable_disable_auto_retrieve()
obj.messaging_enable_disable_roaming_auto_retrieve()
obj.messaging_enable_disable_sms_delivery_reports()
obj.messaging_long_press_contact()
obj.messaging_archive_contact()
obj.messaging_delete_contact()
obj.messaging_enable_notification_for_contact()
obj.messaging_disable_notification_for_contact()
obj.messaging_block_contact()
obj.messaging_unarchive_contact()
obj.messaging_unblock_contact()
obj.messaging_app_close()"""

