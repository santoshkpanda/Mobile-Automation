"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """

__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '09 Oct 2018'

import fmbtandroid
import time
import subprocess
import Constants as Constant
from CommonFunctions import CommonFunctions
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions()
device_connection = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class BaseSettings:
    def __init__(self):
        pass

    def setting_app_launch_via_adb(self):
        """
        Name          : setting_app_launch
        Description   : This method is to launch Device's Setting App
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """

        proc = subprocess.Popen("adb shell am start -a android.settings.SETTINGS", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def connected_devices_setting_open(self):
        """
        Name          : connected_devices_setting_open
        Description   : This method is to open connected devices settings from device's settings app
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        self.setting_app_launch_via_adb()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Connected devices")

    def network_and_internet_setting_open(self):
        """
        Name          : network_and_internet_setting_open
        Description   : This method is to open Network & Internet Setting from device's settings app
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Network & Internet")
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def setting_app_open_via_UI(self):
        """
        Name            : setting_app_open
        Description     : This method is use to launch setting.
        Pre-requisites  : NA
        Input           : NA
        Return          : NA

        """
        device.pressHome()
        common.app_list_open()
        common.scroll_up_search_text("Settings")
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("Settings")

    def setting_close_app(self):
        """
        Name            : setting_close_app
        Description     : This method is use to close the setting app.
        Input           :
        Note:-          :
        Return          :
        Pre-requisites  :    1. Firstly run setting_display_open

        """
        common.close_application("Dismiss Settings.")