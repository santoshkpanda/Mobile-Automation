#!/bin/bash
NOW=$(date +"%m-%d-%Y-%T")
sleep 5
robot -d Results/$NOW/PixelXL12/Smoke/AirplaneMode/ --include SMOKE AirplaneMode.robot
robot -d Results/$NOW/PixelXL12/Smoke/Audio/ --include SMOKE Audio.robot
robot -d Results/$NOW/PixelXL12/Smoke/Bluetooth/ --include SMOKE Bluetooth.robot
robot -d Results/$NOW/PixelXL12/Smoke/Boot/ --include SMOKE Boot.robot
robot -d Results/$NOW/PixelXL12/Smoke/Calculator/ --include SMOKE Calculator.robot
robot -d Results/$NOW/PixelXL12/Smoke/clock/ --include SMOKE clock.robot
robot -d Results/$NOW/PixelXL12/Smoke/Contacts/ --include SMOKE Contacts.robot
robot -d Results/$NOW/PixelXL12/Smoke/HardwareSwitch/ --include SMOKE HardwareSwitch.robot
robot -d Results/$NOW/PixelXL12/Smoke/Launcher/ --include SMOKE Launcher.robot
robot -d Results/$NOW/PixelXL12/Smoke/Location/ --include SMOKE Location.robot
#robot -d Results/$NOW/PixelXL12/Smoke/Messaging/ --include SMOKE Messaging.robot
#robot -d Results/$NOW/PixelXL12/Smoke/Telephony/ --include SMOKE Telephony.robot
robot -d Results/$NOW/PixelXL12/Smoke/WiFi/ --include SMOKE WiFi.robot




