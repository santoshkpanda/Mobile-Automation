"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pradnya Bargal'
__email__ = 'pradnya.bargal@darkmatter.ae'
__version__ = '1.0'
__Date__ = '04 Oct 2018'

import fmbtandroid
import time
import Constants as Constant
from Config import Configuration as config
import CommonFunctions
import DeviceScreen
device_screen = DeviceScreen.DeviceScreen()
device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()


class Camera:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Camera.json')
        pass

    def camera_open_lock_screen(self):
        """
        Function Name   : camera_open_lock_screen
        Description     : This method opens the lock screen
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : NA
        """
        device_screen.open_screen_lock()

    def camera_launch(self):
        """
        Function Name   : camera_launch
        Description     : This method is to open camera app
        Prerequisites   : Device's adb shell should be accessible
        Input           : NA
        Return          : NA
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Camera.text_view.camera_app.text)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        return flag

    def camera_launch_from_home_screen(self):
        """
        Function Name   : camera_launch_from_home_screen
        Description     : This method is to open camera app from the home screen
        Prerequisites   : Camera App should be on the home screen
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Camera.text_view.camera_app.text)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        return flag

    def camera_open_from_recent_app(self):
        """
        Function Name   : camera_open_from_recent_app
        Description     : This method is to open camera app from the home screen
        Prerequisites   : Camera app should be installed
        Input           : NA
        Return          : NA
        """
        self.camera_launch()
        device.pressHome()
        device.pressAppSwitch()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Camera.text_view.open_via_recent_apps.content_desc)
        return flag

    def camera_open_after_reboot(self):
        """
        Function Name   : camera_open_after_reboot
        Description     : This method is to open camera app after rebooting the device
        Prerequisites   : Camera app should be installed
        Input           : NA
        Return          : NA
        """
        device.reboot()
        time.sleep(config.BOOT_TIME)
        self.camera_launch()

    def camera_photo_take(self):
        """
        Function Name   : camera_photo_take
        Description     : This method is captures picture
        Prerequisites   : camera app should be opened with image mode
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return device.tapContentDesc(self.data_model.Camera.Buttons.shutter.content_desc)

    def camera_front_camera_switch(self):
        """
        Function Name   : camera_front_camera_switch
        Description     : This method opens front camera
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return device.tapContentDesc(self.data_model.Camera.Buttons.front_camera_switch.content_desc)

    def camera_back_camera_switch(self):
        """
        Function Name   : back_camera_switch
        Description     : Opens Back camera
        Prerequisites   : camera app should be open in front camera mode
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return device.tapContentDesc(self.data_model.Camera.Buttons.back_camera_switch.content_desc)

    def camera_timer(self):
        """
        Function Name   : camera_timer
        Description     : This method is to Set the camera timer to 3 secs/10 secs /off
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.TIMER_SET[0])
        if flag:
            for x in Constant.TIMER_SET[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.TIMER_SET[0])
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_hdr_mode(self):
        """
        Function Name   : camera_hdr_mode
        Description     : This method to sets different HDR+ modes in camera
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.HDR_OPTIONS[0])
        if flag:
            for x in Constant.HDR_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.HDR_OPTIONS[0])
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
            return flag

    def camera_grid_mode(self):
        """
        Function Name   : camera_grid_mode
        Description     : This method sets grid modes like 3*3/4*4/ golden ratio for camera
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.GRID_OPTIONS[0])
        if flag:
            for x in Constant.GRID_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.GRID_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_white_balance_mode(self):
        """
        Function Name   : camera_white_balance_mode
        Description     : This method sets various White Balance modes like cloudy/sunny in camera
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[0])
        if flag:
            for x in Constant.WHITE_BALANCE_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_flash_mode(self):
        """
        Function Name   : camera_flash_mode
        Description     : This method to Set flash on/off/auto for camera
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.FLASH_OPTIONS[0])
        if flag:
            for x in Constant.FLASH_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.FLASH_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_face_retouching_off(self):
        """
        Function Name   : camera_face_retouching_off
        Description     : This method to sets the face retouching option off
        Prerequisites   : Front camera should be on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[0])
        if flag:
            device.refreshView(uiautomatorDump=True)
            flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[1])
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                self.camera_photo_take()
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_face_retouching_on(self):
        """
        Function Name   : camera_face_retouching_on
        Description     : This method to sets the face retouching option on
        Prerequisites   : Front camera should be on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.FACE_TOUCHING_OPTION[0])
        if flag:
            device.refreshView(uiautomatorDump=True)
            flag = device.tapContentDesc(Constant.FACE_TOUCHING_OPTION[2])
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                self.camera_photo_take()
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_switch_to_panorama_mode(self):
        """
        Function Name   : camera_switch_to_panorama_mode
        Description     : This method opens the camera in Panorama mode
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.shellSOE(config.SWIPE_COORDINATES)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Camera.text_view.switch_to_panorama_mode.content_desc)
        if flag:
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_switch_to_photo_sphere_mode(self):
        """
        Function Name   : camera_switch_to_photo_sphere_mode
        Description     : This method to open the camera in photo sphere mode
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.shellSOE(config.SWIPE_COORDINATES)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Camera.text_view.switch_to_sphere_mode.content_desc)
        if flag:
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_switch_to_lens_blur_mode(self):
        """
        Function Name   : camera_switch_to_lens_blur_mode
        Description     : This method to open  the camera in the lens blur mode
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.shellSOE(config.SWIPE_COORDINATES)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Camera.text_view.switch_to_lens_blur_mode.content_desc)
        if flag:
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_settings(self):
        """
        Function Name   : camera_settings
        Description     : This method to open the camera settings
        Prerequisites   : camera app should be open
        Input           : NA
        Return          : NA
        """
        device.shellSOE(config.SWIPE_COORDINATES)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Camera.text_view.settings_open.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_save_location_enable_disable(self):
        """
        Function Name   : camera_save_location_enable_disable
        Description     : This method to enable and disable the default location where the camera stores its images
        Prerequisites   : Camera app settings must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Camera.Buttons.save_location.text)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Camera.Buttons.save_location.text)
        return flag

    def camera_sounds_enable_disable(self):
        """
        Function Name   : camera_sounds_enable_disable
        Description     : This method enables and disables the camera sounds
        Prerequisites   : Camera app settings must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Camera.Buttons.camera_sounds.text)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.tapText(self.data_model.Camera.Buttons.camera_sounds.text)
        return flag

    def camera_open_gestures(self):
        """
        Function Name   : camera_open_gestures
        Description     : This method opens the gestures
        Prerequisites   : Camera app settings must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        return device.tapText(Constant.VOLUME_KEY_ACTIONS[0])

    def camera_gestures_volume_key_action(self):
        """
        Function Name   : camera_gestures_volume_key_action
        Description     : This method Sets the action that the volume key performs in the camera
        Prerequisites   : Camera app settings must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(Constant.VOLUME_KEY_ACTIONS[1])
        if flag:
            for x in Constant.VOLUME_KEY_ACTIONS[2:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapText(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapText(Constant.VOLUME_KEY_ACTIONS[1])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_enable_disable_double_tap_to_zoom_setting(self):
        """
        Function Name   : camera_double_tap_to_zoom_enable_disable
        Description     : This method enables and disables 'Double-tap_to_zoom' settings from camera app settings
        Prerequisites   : 'Gestures'setting must be opened from camera app settings
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Camera.Buttons.double_tap_to_zoom.text)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Camera.Buttons.double_tap_to_zoom.text)
            device.pressBack()
        return flag

    def back_camera_photo_resolution(self):
        """
        Function Name   : back_camera_photo_resolution
        Description     : This method is to Set resolution for back camera
        Prerequisites   : Camera app settings must be opened
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(Constant.BACK_CAMERA_RESOLUTION[0])
        if flag:
            for x in Constant.BACK_CAMERA_RESOLUTION[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapText(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapText(Constant.BACK_CAMERA_RESOLUTION[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def front_camera_photo_resolution(self):
        """
        Function Name   : front_camera_photo_resolution
        Description     : This method sets resolution for the front camera
        Prerequisites   : Camera app settings must be opened
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(Constant.FRONT_CAMERA_RESOLUTION[0])
        if flag:
            for x in Constant.FRONT_CAMERA_RESOLUTION[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapText(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_photo_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapText(Constant.FRONT_CAMERA_RESOLUTION[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_burst_setting_enable_disable(self):
        """
        Function Name   : camera_burst_setting_enable_disable
        Description     : This method enables and disables the burst settings in the camera
        Prerequisites   : Camera app settings must be opened
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        string = self.data_model.Camera.Buttons.burst.text
        flag = device.tapOcrText(string)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Camera.Buttons.auto_generate_creations.text)
            if flag:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                device.tapText(self.data_model.Camera.Buttons.auto_generate_creations.text)
                device.pressBack()
        return flag

    def camera_panorama_resolution(self):
        """
        Function Name   : camera_panaroma_resolution
        Description     : This method sets resolution for panaroma mode in camera
        Prerequisites   : Camera app settings must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(Constant.panaroma_resolution[0])
        if flag:
            for x in Constant.panaroma_resolution[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapText(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapText(Constant.panaroma_resolution[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_zoom_in(self):
        """
        Function Name   : camera_zoom_in
        Description     : This method zooms in the image to be taken
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        return device.pinchOpen()

    def camera_zoom_out(self):
        """
        Function Name   : camera_zoom_out
        Description     : This method is to zoom out the image to be taken
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.pinchClose()
        time.sleep(config.SLEEP_TIME_LOW)
        return device.pinchClose()

    def camera_press_back(self):
        """
        Function Name   : camera_press_back
        Description     : This method is to press on back button
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        flag = device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_switch_to_video_mode(self):
        """
        Function Name   : camera_switch_to_video_mode
        Description     : This method to switch camera in video mode
        Prerequisites   : Device's ADB shell should be accessible
        Input           : NA
        Return          : NA
        """

        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        print(self.data_model.Camera.image_view.switch_to_video_mode.id)
        flag = device.tapId(self.data_model.Camera.image_view.switch_to_video_mode.id)
        print(flag)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_video_take(self):
        """
        Function Name   : camera_video_take
        Description     : This method is to record video using camera app
        Prerequisites   : Camera app should be opened in video mode
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapId(self.data_model.Camera.image_view.video_take.id)
        time.sleep(Constant.VIDEO_CAPTURE)
        return flag

    def video_stop_video(self):
        """
        Function Name   : video_stop_video
        Description     : This method is to stop the recording video using camera app
        Prerequisites   : Camera app should be opened in video mode
        Input           : NA
        Return          : NA
        """
        flag = device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def video_select_slow_motion_video(self):
        """
        Function Name   : video_take_slow_motion_video
        Description     : This method takes video in slow motion
        Prerequisites   : Camera app must be open
        Input           : NA
        Return          : NA
        """
        flag = self.camera_settings()
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(self.data_model.Camera.text_view.slow_motion_mode.content_desc)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def video_frames_per_second(self):
        """
        Function Name   : video_frames_per_second
        Description     : This sets frames per second
        Prerequisites   : Camera app settings must be opened
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.FRAMES_PER_SECOND[0])
        if flag:
            for x in Constant.FRAMES_PER_SECOND[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_video_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_press_back()
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.FRAMES_PER_SECOND[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def video_flash_mode(self):
        """
        Function Name   : video_flash_mode
        Description     : This method to Set flash on/off/auto for video
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.FLASH_OPTIONS[0])
        if flag:
            for x in Constant.FLASH_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_video_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_press_back()
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.FLASH_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def video_white_balance_mode(self):
        """
        Function Name   : video_white_balance_mode
        Description     : This method sets various White Balance modes like cloudy/sunny in video
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[0])
        if flag:
            for x in Constant.WHITE_BALANCE_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_video_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_press_back()
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.WHITE_BALANCE_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def video_grid_mode(self):
        """
        Function Name   : video_grid_mode
        Description     : This method sets grid modes like 3*3/4*4/ golden ratio for video
        Prerequisites   : Camera app should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.GRID_OPTIONS[0])
        if flag:
            for x in Constant.GRID_OPTIONS[1:]:
                device.refreshView(uiautomatorDump=True)
                flag = device.tapContentDesc(x)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_video_take()
                    time.sleep(config.SLEEP_TIME_LOW)
                    self.camera_press_back()
                    device.refreshView(uiautomatorDump=True)
                    flag = device.tapContentDesc(Constant.GRID_OPTIONS[0])
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def switch_from_video_to_camera_mode(self):
        """
        Function Name   : switch_from_video_to_camera_mode
        Description     : This method switches from video mode to camera mode
        Prerequisites   : Video mode should be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapId(self.data_model.Camera.image_view.video_to_camera.id)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_close_via_recent_app(self):
        """
        Function Name   : camera_close_via_recent_app
        Description     : This method is to close the camera app via the recent app
        Prerequisites   : Camera app must be open
        Input           : NA
        Return          : NA
        """
        common.close_application(self.data_model.Camera.Buttons.camera_close.content_desc)

    def camera_close_via_press_back(self):
        """
        Function Name   : camera_close_via_press_back
        Description     : This method is to close the camera app via the recent app
        Prerequisites   : Camera app must be open
        Input           : NA
        Return          : NA
        """
        flag = device.pressBack()
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            flag = device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def camera_close_via_press_home(self):
        """
        Function Name   : camera_close_via_press_home
        Description     : This method is to close the camera app via the recent app
        Prerequisites   : Camera app must be open
        Input           : NA
        Return          : NA
        """
        device.pressHome()


