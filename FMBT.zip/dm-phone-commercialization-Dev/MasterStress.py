import random

import AirplaneMode
import Battery
import Bluetooth
import Boot
import Calculator
import Camera
import Contacts
import Constants as Constants
import DeviceScreen
# # import Dialer as di
import FileDownload
import HardwareSwitch
import Launcher
import Location
import MobileData
import WiFi
from BaseSettings import BaseSettings


class MasterStress:

    def __init__(self):
        pass

    def stress_airplane_mode_enable_disable(self, stress_count):
        """
        Name          : airplane_mode_disable
        Description   : This method runs stress test to enable and disable Airplane Mode
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        airplane = AirplaneMode.AirplaneMode()
        state = airplane.airplane_mode_get_state()
        if state == Constants.STATE_ENABLED:
            for i in range(int(stress_count)):
                airplane.airplane_mode_disable()
                airplane.airplane_mode_enable()
        elif state == Constants.STATE_DISABLED:
            for i in range(int(stress_count)):
                airplane.airplane_mode_enable()
                airplane.airplane_mode_disable()

    def stress_bluetooth_enable_disable(self, stress_count):
        """
        Name          : stress_bluetooth_enable_disable
        Description   : This method runs stress test to enable and disable bluetooth
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        bt = Bluetooth.Bluetooth()
        state = bt.bluetooth_get_state_via_adb()
        if state == Constants.STATE_ENABLED:
            for i in range(int(stress_count)):
                bt.bluetooth_disable_via_adb()
                bt.bluetooth_enable_via_adb()
        elif state == Constants.STATE_DISABLED:
            for i in range(int(stress_count)):
                bt.bluetooth_enable_via_adb()
                bt.bluetooth_disable_via_adb()

    def stress_bluetooth_device_headset_pair_unpair(self, stress_count):
        """
        Name          : stress_bluetooth_device_headset_pair_unpair
        Description   : This method runs stress test to pair and unpair bluetooth device
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        base_settings = BaseSettings()
        bt = Bluetooth.Bluetooth()
        bt.bluetooth_enable_via_adb()
        bt.bluetooth_setting_open()
        for i in range(int(stress_count)):
            bt.bluetooth_pair_new_device("JABRA EASYGO") # TODO PALLAVI
            bt.bluetooth_unpair_paired_device()
            bt.bluetooth_handle_popup_actions(1)
        base_settings.setting_close_app()
        bt.bluetooth_disable_via_adb()

    def stress_bluetooth_device_headset_connect_disconnect(self, stress_count):
        """
        Name          : stress_bluetooth_device_headset_connect_disconnect
        Description   : This method runs stress test to connect and disconnect bluetooth device
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        base_settings = BaseSettings()
        bt = Bluetooth.Bluetooth()
        bt.bluetooth_enable_via_adb()
        bt.bluetooth_setting_open()
        bt.bluetooth_pair_new_device("JABRA EASYGO")  # TODO PALLAVI
        for i in range(int(stress_count)):
            bt.bluetooth_disconnect_connected_device("JABRA EASYGO")
            bt.bluetooth_connect_disconnected_device()
        bt.bluetooth_unpair_paired_device()
        bt.bluetooth_handle_popup_actions(1)
        base_settings.setting_close_app()
        bt.bluetooth_disable_via_adb()

    def stress_wifi_enable_disable(self, stress_count):
        """
        Name          : stress_wifi_enable_disable
        Description   : This method runs stress test to enable and disable Wi-Fi
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        wifi = WiFi.WiFi()
        state = wifi.wifi_get_state_via_adb()
        if state == 'Wi-Fi is enabled':
            for i in range(int(stress_count)):
                wifi.wifi_disable_via_adb()
                wifi.wifi_enable_via_adb()
        elif state == 'Wi-Fi is disabled':
            for i in range(int(stress_count)):
                wifi.wifi_enable_via_adb()
                wifi.wifi_disable_via_adb()

    def stress_mobile_data_enable_disable(self, stress_count):
        """
        Name          : stress_mobile_data_enable_disable
        Description   : This method runs stress test to enable and disable Mobile Data
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        data = MobileData.MobileData()
        state = data.mobile_data_get_state()
        if state == 'mDataConnectionState=2':
            for i in range(int(stress_count)):
                data.mobile_data_disable_via_adb()
                data.mobile_data_enable_via_adb()
        elif state == 'mDataConnectionState=2':
            for i in range(int(stress_count)):
                data.mobile_data_enable_via_adb()
                data.mobile_data_disable_via_adb()

    def stress_wifi_bluetooth_enable_disable_randomly(self, stress_count):
        """
        Name          : stress_wifi_bluetooth_enable_disable_randomly
        Description   : This method runs stress test to enable and disable Wi-Fi and Bluetooth randomly
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        wifi = WiFi.WiFi()
        bt = Bluetooth.Bluetooth()
        for i in range(int(stress_count)):
            random_num = random.randint(0, 3)
            if 0 == random_num:
                wifi.wifi_enable_via_adb()
            if 1 == random_num:
                wifi.wifi_disable_via_adb()
            if 2 == random_num:
                bt.bluetooth_enable_via_adb()
            if 3 == random_num:
                bt.bluetooth_disable_via_adb()

    def stress_gps_provider_enable_disable(self, stress_count):
        """
        Name          : stress_gps_provider_enable_disable
        Description   : This method runs stress test to enable and disable GPS Location provide
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        loc = Location.Location()
        for i in range(int(stress_count)):
            loc.gps_provider_enable()
            loc.gps_provider_disable()

    def stress_network_provider_enable_disable(self, stress_count):
        """
        Name          : stress_network_provider_enable_disable
        Description   : This method runs stress test to enable and disable Network Location provide
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        loc = Location.Location()
        for i in range(int(stress_count)):
            loc.network_provider_enable()
            loc.network_provider_disable()

    def stress_location_enable_disable(self, stress_count):
        """
        Name          : stress_location_enable_disable
        Description   : This method runs stress test to enable and disable all Location provide for Location services
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        loc = Location.Location()
        for i in range(int(stress_count)):
            loc.set_location_enabled()
            loc.set_location_disable()

    def stress_location_mode_in_sequence(self, stress_count):
        """
        Name          : stress_location_mode_in_sequence
        Description   : This method runs stress test to set location mode in sequence
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        loc = Location.Location()
        loc.location_mode_open()
        last_mode = -1
        for i in range(int(stress_count)):
            # high accuracy
            loc.set_location_mode_high_accuracy()
            if last_mode == 2:
                loc.handle_improve_location_accuracy_popup()
            last_mode = 0

            # battery saving
            loc.set_location_mode_battery_saving()
            last_mode == 1

            # device only
            loc.set_location_mode_device_only()
            last_mode == 2
        loc.location_setting_close()

    def stress_location_mode_randomly(self, stress_count):
        """
        Name          : stress_location_mode_randomly
        Description   : This method runs stress test to to set location mode randomly
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        loc = Location.Location()
        loc.location_mode_open()
        last_mode = -1
        for i in range(int(stress_count)):
            random_num = random.randint(0, 2)
            if 0 == random_num:
                if last_mode == 2:
                    loc.handle_improve_location_accuracy_popup()
                    loc.set_location_mode_high_accuracy()
                last_mode = 0
            if 1 == random_num:
                if last_mode == 2:
                    loc.handle_improve_location_accuracy_popup()
                    loc.set_location_mode_battery_saving()
                last_mode = 1
            if 2 == random_num:
                loc.set_location_mode_device_only()
                last_mode = 2
        loc.location_setting_close()

    def stress_calculator_arithmatic_operations(self, stress_count):
        """
        Name          : stress_calculator_arithmatic_operations
        Description   : This method runs stress test to perform arithmatic operations in calculator app
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        calc = Calculator.Calculator()
        for i in range(int(stress_count)):
            calc.calculator_launch()
            calc.calculator_perform_operation("plus", "290", "45")
            calc.calculator_perform_operation("minus", "500", "288")
            calc.calculator_perform_operation("multiply", "390", "9")
            calc.calculator_perform_operation ("divide", "1250", "50")
            calc.calculator_perform_operation("plus", "145.89", "78.9")
            calc.calculator_perform_operation("minus", "67.9", "34.2")
            calc.calculator_perform_operation("multiply", "345.9", "9.8")
            calc.calculator_perform_operation("divide", "67.2", "7.0")
            calc.calculator_close_app()

    def stress_contact_create_save_delete(self, stress_count):
        """
        Name          : stress_location_mode_randomly
        Description   : This method runs stress test to create contact, save and delete it from Contacts app
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        cont = Contacts.Contacts()
        for i in range(int(stress_count)):
            # Home screen
            cont.contacts_app_launch()
            cont.contacts_create()
            cont.contacts_delete_all_contact()
            cont.contacts_app_close()

    def stress_launcher(self, stress_count):
        """
        Name          : stress_Launcher
        Description   : This method runs stress test to launch launcher and perform different actions
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """

        for i in range(int(stress_count)):
            launch = Launcher.Launcher()
            launch.launcher_launch_home_page()
            launch.launcher_scroll_applist()
            launch.launcher_back_to_home()
            launch.launcher_press_back()
            launch.launcher_open_recentapp()
            launch.launcher_recentapp_clearall()
            launch.launcher_open_statusbar()
            launch.launcher_close_statusbar()
            launch.launcher_open_quick_settings()
            launch.launcher_overview_panel_select_option(0)
            launch.launcher_overview_panel_select_option(1)
            launch.launcher_overview_panel_select_option(2)
            launch.launcher_google_text_search()

    def stress_camera_launch_close(self, stress_count):
        """
        Name          : stress_camera_launch_close
        Description   : This method runs stress test to open and close the camera app
        Pre-requisite : Device's ADB shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        cam = Camera.Camera()
        for i in range(int(stress_count)):
            cam.camera_launch()
            cam.camera_close()

    def stress_camera_image_capture(self, stress_count):
        """
        Name          : camera_stress_image_capture
        Description   : This method runs stress test to capture image using Camera app
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        cam = Camera.Camera()
        for i in range(int(stress_count)):
            cam.camera_launch()
            cam.camera_photo_take()
            cam.camera_close()

    # def stress_camera_video_recording(stress_count):
    #     """
    #     Name          : stress_camera_video_recording
    #     Description   : This method runs stress test to Record video using camera app
    #     Pre-requisite : NA
    #     Input         : stress_count- used to run the stress test in loop with given count
    #     Return        : NA
    #     """
    #     for i in range(int(stress_count)):
    #         cam.camera_launch()
    #         cam.camera_switch_to_video_mode()
    #         cam.camera_video_take()
    #         cam.camera_close()

    # def stress_image_video_mode_toggle(stress_count):
    #     """
    #     Name          : stress_image_video_mode_toggle
    #     Description   : This method runs stress test to switch camera in image and video mode
    #     Pre-requisite : NA
    #     Input         : stress_count- used to run the stress test in loop with given count
    #     Return        : NA
    #     """
    #     cam = Camera.Camera()
    #     cam.camera_launch()
    #     for i in range(int(stress_count)):
    #         cam.camera_switch_to_video_mode()
    #         cam.camera_switch_to_image_mode()
    #     cam.camera_close()

    def stress_switch_camera_front_back(self, stress_count):
        """
        Name          : stress_switch_camera_front_back
        Description   : This method runs stress test to switch Camera in front and back
        Pre-requisite : NA
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        cam = Camera.Camera()
        cam.camera_launch()
        for i in range(int(stress_count)):
            cam.camera_front_camera_switch()
            cam.camera_back_camera_switch()
        cam.camera_close()

    def stress_battery_charging_enable_disable(self, stress_count):
        """
        Name          : stress_battery_charging_enable_disable
        Description   : This method runs stress test to enable and disable device battery charging
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        bat = Battery.Battery()
        for i in range(int(stress_count)):
            bat.battery_charging_disable()
            bat.battery_charging_enable()

    def stress_screen_suspend_resume(self, stress_count):
        """
        Name          : stress_screen_suspend_resume
        Description   : This method runs stress test to screen suspend and resume
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        screen = DeviceScreen.DeviceScreen()
        for i in range(int(stress_count)):
            screen.screen_suspend_resume()

    """Stress test for volume UP and DOWN"""
    def stress_volume_up_down(self, stress_count):
        """
        Name          : stress_volume_up_down
        Description   : This method runs stress test to volume up and down
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        hardware = HardwareSwitch.HardwareSwitch()
        for i in range(int(stress_count)):
            hardware.volume_up()
            hardware.volume_down()

    """Stress test hardware switch """
    def stress_hardware_switch_power_on_off(self, stress_count):
        """
        Name          : stress_hardware_switch_power_on_off
        Description   : This method runs stress test to screen activate and deactivated
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        hardware = HardwareSwitch.HardwareSwitch()
        for i in range(int(stress_count)):
            hardware.power_btn_screen_off()
            hardware.power_btn_screen_on()

    """Stress tess download file via wifi though browser"""
    def stress_download_file_via_wifi(self, stress_count):
        download = FileDownload.FileDownload()
        for i in range(int(stress_count)):
            download.download_file_via_wifi()

    """Stress tess download file via mobile data though browser"""
    def stress_download_file_via_mobile_data(self, stress_count):
        download = FileDownload.FileDownload()
        for i in range(int(stress_count)):
            download.download_file_via_mobile_data()


    # # """Stress test to enter number using phone app dialer/keypad"""
    # #
    # #
    # # def stress_dialer_enter_number_close(stress_count):
    # #     for i in range(int(stress_count)):
    # #         di.phone_dialer_open()
    # #         di.phone_number_enter()
    # #         di.phone_dialer_close()
    # #
    # #

    def stress_hard_boot(self, stress_count):
        """
        Name          : stress_hard_boot
        Description   : This method runs stress test to hard boot/restart device with adb command
        Pre-requisite : Device's adb shell should be accessible
        Input         : stress_count- used to run the stress test in loop with given count
        Return        : NA
        """
        boot = Boot.Boot()
        for i in range(int(stress_count)):
            boot.hard_boot()





