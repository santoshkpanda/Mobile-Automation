"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.

 """
__Author__ = 'Pradnya Bargal'
__Email__ = 'pradnya.bargal@darkmatter.ae'
__Version__ = '1.0'
__Date__='04 Oct 2018'

import fmbtandroid
import time
import CommonFunctions
import Contacts
import Constants as Constant
from Config import Configuration as config
import Phone_Dialer

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
contacts = Contacts.Contacts()
phone_dialer = Phone_Dialer.PhoneDialer()


class Telephony:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Telephony.json')
        pass

    def telephony_launch_by_making_a_call(self):
        """
        Function Name   : telephony_launch_by_making_a_call
        Description     : This method performs all operations required to call a specific number
        Prerequisites   : phone should be switched on
        Input           : NA
        Return          : NA
        """
        flag = phone_dialer.dialer_launch()
        if flag:
            flag = phone_dialer.dialer_keypad_open()
            if flag:
                flag = phone_dialer.dialer_enter_number(1)
                if flag:
                    flag = phone_dialer.dialer_number_call()
        return flag

    def telephony_mute_the_ongoing_call(self):
        """
        Function Name   : telephony_mute_the_ongoing_call
        Description     : This method enables the mute option in the ongoing call
        Prerequisites   : The call should be ongoing
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.mute.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_unmute_the_ongoing_call(self):
        """
        Function Name   : telephony_unmute_the_ongoing_call
        Description     : This method disables the mute option in the ongoing call
        Prerequisites   : The call should be ongoing
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.unmute.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_speaker_enable(self):
        """
        Function Name   : telephony_speaker_enable
        Description     : This method enables the speaker option in the call
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Telephony.Buttons.enable_speaker.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_speaker_disable(self):
        """
        Function Name   : telephony_speaker_disable
        Description     : This method disables the speaker option in the call
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Telephony.Buttons.disable_speaker.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_keypad_enable_disable(self):
        """
        Function Name   : telephony_keypad_enable_disable
        Description     : This method pops on the keypad dialer in an ongoing call
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.keypad.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_hold_call(self):
        """
        Function Name   : telephony_hold_call
        Description     : This method holds the ongoing call
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapId(self.data_model.Telephony.Buttons.hold_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_release_call(self):
        """
        Function Name   : telephony_release_call
        Description     : This method releases the ongoing call
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Telephony.Buttons.resume_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_add_call(self):
        """
        Function Name   : telephony_add_call
        Description     : This method add another call and start a conference call
        Prerequisites   : The call must be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.add_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_select_contact_to_add_call(self):
        """
        Function Name   : telephony_select_contact_to_add_call
        Description     : This method selects another contact to add another call and start a conference call
        Prerequisites   : The call must be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = phone_dialer.dialer_enter_number(0)
        if flag:
            flag = phone_dialer.dialer_number_call()
        return flag

    def telephony_swap_calls(self):
        """
        Function Name   : telephony_swap_calls
        Description     : This method swaps calls between 2 calls going on
        Prerequisites   : The call must be going on and the call must be in conference
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.swap_calls.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(self.data_model.Telephony.Buttons.swap_calls.content_desc)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_merge_calls(self):
        """
        Function Name   : telephony_merge_calls
        Description     : This method merge calls
        Prerequisites   : The call must be going on and the call must be in conference
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.merge_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_end_call(self):
        """
        Function Name   : telephony_end_call
        Description     : This method ends the ongoing call/calls
        Prerequisites   : The call should be going on
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Telephony.Buttons.end_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def telephony_close(self):
        """
        Function Name   : phone_dialer_close
        Description     : This method closes the Phone app
        Prerequisites   : Phone app must be open
        Input           : NA
        Return          : NA
        """
        phone_dialer.dialer_close()


"""obj = Telephony()
obj.telephony_launch_by_making_a_call()
obj.telephony_mute_the_ongoing_call()
obj.telephony_unmute_the_ongoing_call()
obj.telephony_speaker_enable()
obj.telephony_speaker_disable()
obj.telephony_keypad_enable_disable()
obj.telephony_hold_call()
obj.telephony_release_call()
obj.telephony_add_call()
obj.telephony_end_call()"""
