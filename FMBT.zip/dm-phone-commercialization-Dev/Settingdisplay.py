"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* this software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__author__ = "Aakib Qureshi"
__email__ = "aakib.qureshi@darkmatter.ae"
__version__ = "1.0"
__date__ = "08 Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
import Constants as Constant
from CommonFunctions import CommonFunctions


device = fmbtandroid.Device()
common = CommonFunctions()
device_connection = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Settingdisplay:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Settingdisplay.json')

    def setting_open_display(self):
        """
        Name            : setting_open_display
        Description     : This method is to open display setting inside the setting app.
        Pre-requisites  : run setting_app_open()
        Input           : NA
        Return          : True and False
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(self.data_model.text_view.display.text)
        return flag

    def setting_display_open_brightness_level(self):
        """
        Name            : setting_display_open_brightness_level
        Description     : This method is to open brightness level popup from display settings.
        Pre-requisites  : run setting_app_open() -> setting_open_display()
        Input           : NA
        Return          : True and False
        """

        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(self.data_model.text_view.brightness.text)
        return flag

    def display_change_brightness(self, index):
        """
        Name            : display_increase_brightness
        Description     : This method is used for increase the brightness of mobile device.
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> setting_display_open_brightness_level()
        Input           :  index- in between 0-2 for "Increase", "Decrease" , "Middle" for BRIGHTNESS LEVEL
        Return          : True and False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        BRIGHTNESS_LEVEL = Constant.BRIGHTNESS_LEVEL_OPTION[index]
        flag = False
        if BRIGHTNESS_LEVEL == "Increase":
            flag = device.swipeText(self.data_model.text_view.brightness_level.text, "EAST")
        elif BRIGHTNESS_LEVEL == "Decrease":
            flag = device.swipeText(self.data_model.text_view.brightness_level.text, "WEST")
        elif BRIGHTNESS_LEVEL== "Middle":
            device.refreshView(uiautomatorDump=True)
            flag = device.tapText(self.data_model.text_view.brightness_level.text)
        device.pressBack()
        return flag

    def display_open_advanced_setting(self):
        """
        Name            : display_open_advanced_setting
        Description     : This method is to open advanced display settings
        Pre-requisites  : run setting_app_open() -> setting_open_display()
        Input           : NA
        Return          : True and False
        """

        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(self.data_model.text_view.advanced.text)
        return flag

    def display_auto_rotate_screen_enable_disable(self):
        """
        Name            : display_auto_rotate_screen_enable_disable
        Description     : This method is used for auto-rotate screen on/off.
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()
        Input           : NA
        Return          : True and False
        """

        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(self.data_model.text_view.auto_rotate_screen.text)
        return flag

    def display_open_font_size_setting(self):
        """
        Name            : display_open_font_size_setting
        Description     : This method is to open font size settings.
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()
        Input           : NA
        Return          : True and False
        """

        device.refreshView(uiautomatorDump=True)
        flag = device.tapText(self.data_model.text_view.font_size.text)
        return flag

    def display_set_font_size_setting(self, index):
        """
        Name            : display_set_font_size_setting
        Description     : This method is used to set font size.
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> display_open_advanced_setting() ->
                            display_open_font_size_setting()
        Input           : index- in between 0-3 for  "Small", "Default" , "Large" , "Largest" font size
        Return          : True and False
        """
        device.refreshView(uiautomatorDump=True)
        flag = device.tapContentDesc(Constant.FONT_SIZE[int(index)])
        return flag

    def display_back_to_display_settings(self): #TODO write common function to nevigate back
        """
        Name            : display_back_to_display_settings
        Description     : This method is use for back from font size
        Pre-requisites  : set font size screen should be open
        Note            :
        Input           : NA
        Return          : NA
        """
        device.pressBack()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

    def display_open_screen_saver_setting(self):
        """
        Name            : display_open_screen_saver_setting
        Description     : This method is to open screen saver settings
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()
        Input           :
        Return          : True and False
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.text_view.screen_sever.text)
        return flag

    def display_start_now_screen_saver(self):
        """
        Name            : display_start_now_screen_saver
        Description     : This method is to start now screen saver
        Pre-requisites  : run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()->display_open_screen_saver_setting()
        Input           :
        Return          : True and False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        isTap = device.tapText(self.data_model.text_view.start_now.text)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return isTap

    def display_set_sleep_time(self, index):
        """
        Name            : display_set_sleep_time
        Description     : This method is used for set sleep time.
        Pre-requisites  : first run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()
        Input           : index- in between 0-6 for  "15 seconds", "30 seconds" , "1 minutes" , "2 minutes" , "5 minutes" , "10 minutes" ,
                            "30 minutes"
        Return          : True and False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        isTap = device.tapText(self.data_model.text_view.sleep.text)
        if isTap:
            device.refreshView(uiautomatorDump=True)
            flag = device.tapText(Constant.SLEEP_TIME_LIST[int(index)])
        return flag

    def setting_display_open_display_size(self):
        """
        Name            : setting_display_open_display_size
        Description     : This method is to open display size setting screen.
        Pre-requisites  : first run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()
        Input           :
        Return          : True and False
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        device.waitText(self.data_model.text_view.display_size.text)
        flag = device.tapText(self.data_model.text_view.display_size.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return flag

    def setting_display_set_display_size(self, index):
        """
        Name            : setting_display_set_display_size
        Description     : This method is to set display size.
        Pre-requisites  : first run setting_app_open() -> setting_open_display()-> display_open_advanced_setting()->
                          setting_display_open_display_size()
        Input           : index- between 0-4 for "Small", "Default" , "Large" , "Larger" ,"Largest".
        Return          : True and False
        """
        isTap = device.tapContentDesc(Constant.DISPLAY_SIZE[int(index)])
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return isTap
