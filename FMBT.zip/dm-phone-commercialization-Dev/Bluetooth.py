"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '05 Oct 2018'

import fmbtandroid
import time
import subprocess
import Constants as Constant
import CommonFunctions
from BaseSettings import BaseSettings
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Bluetooth:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/bluetooth.json')

    def bluetooth_get_state_via_adb(self):
        """
        Name          : get_bluetooth_state
        Description   : This method is to read bluetooth state enabled/disabled(On/Off)
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Returns '1' or '0' if bluetooth mode is enabled or disabled respectively.
        """
        proc = subprocess.Popen("adb shell settings get global bluetooth_on", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        output = proc.stdout.read(1)
        return output

    def bluetooth_enable_via_adb(self):
        """
        Name          : bluetooth_enable
        Description   : This method is to turn bluetooth On
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell am start -a android.bluetooth.adapter.action.REQUEST_ENABLE",
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.refreshView(uiautomatorDump = True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("ALLOW")

    def bluetooth_disable_via_adb(self):
        """
        Name          : bluetooth_disable
        Description   : This method is to turn bluetooth Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell am start -a android.bluetooth.adapter.action.REQUEST_DISABLE",
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText("ALLOW")

    def bluetooth_enable_disable(self):
        """
        Name          : bluetooth_enable_disable
        Description   : This method is to toggle bluetooth On-Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        time.sleep(config.SLEEP_TIME_MEDIUM)
        state = self.bluetooth_get_state_via_adb()
        if state == Constant.STATE_ENABLED:
            self.bluetooth_disable_via_adb()
            self.bluetooth_enable_via_adb()
        elif state == Constant.STATE_DISABLED:
            self.bluetooth_enable_via_adb()
            self.bluetooth_disable_via_adb()

    def assert_bluetooth_state_via_adb(self, expected_output):
        """
        Name          : assert_bluetooth_state
        Description   : This method is to assert bluetooth changed state
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        print("Asserting Bluetooth changed state ...")
        actual_output = self.bluetooth_get_state_via_adb()
        print(actual_output + "==" + expected_output)
        if Constant.STATE_ENABLED == actual_output:
            print("Bluetooth Turned ON")
        elif Constant.STATE_DISABLED == actual_output:
            print("Bluetooth Turned OFF")
        else:
            print("Invalid Bluetooth state")
        assert actual_output == expected_output

    def get_bluetooth_mac_address(self):
        """
        Name          : get_bluetooth_mac_address
        Description   : This method is to read bluetooth device's MAC address
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Returns bluetooth device's MAC address if successful.
        """
        proc = subprocess.Popen("adb shell settings get secure bluetooth_address",
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        output = proc.stdout.readline()
        return output.rstrip()

    def get_bluetooth_device_name(self):
        """
        Name          : get_bluetooth_device_name
        Description   : This method is to read bluetooth device's name
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Return bluetooth device's name address if successful.
        """
        proc = subprocess.Popen("adb shell settings get secure bluetooth_name",
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        output = proc.stdout.readline()
        return output.rstrip()

    def bluetooth_setting_open(self):
        """
        Name          : bluetooth_setting_open
        Description   : This method is to open Bluetooth setting open from Device Setting app
        Pre-requisite : Need to open connected devices setting from device's settings app
        Input         : NA
        Return        : NA
        """
        base_settings = BaseSettings()
        base_settings.connected_devices_setting_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.waitText(self.data_model.text_view.bluetooth.text)
        device.tapText(self.data_model.text_view.bluetooth.text)

    def bluetooth_pair_new_device(self, device_to_pair):
        """
        Name          : bluetooth_pair_new_device
        Description   : This method is to click on Pair new device from bluetooth setting.
        Pre-requisite : Device should be visible on first page after device scan (as scroll and search will be covered
                        in advance cases)
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.waitText(self.data_model.text_view.pair_new_device.text)
        device.tapText(self.data_model.text_view.pair_new_device.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_successful = device.tapText(device_to_pair)
        time.sleep(config.SLEEP_TIME_LOW)
        if not is_successful:
            # back to bluetooth settings
            device.pressBack()
            return is_successful

    def bluetooth_disconnect_connected_device(self, device_to_pair):
        """
        Name          : bluetooth_disconnect_connected_device
        Description   : This method is to disconnect paired and connected bluetooth device
        Pre-requisite : Device should be visible on first page after device scan (as scroll and search will be covered
                        in advance cases)
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_successful = device.tapText(device_to_pair)
        time.sleep(config.SLEEP_TIME_LOW)
        if is_successful:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

            device.waitText(self.data_model.text_view.disconnect_device.text)
            device.tapText(self.data_model.text_view.ok.text)
            time.sleep(config.SLEEP_TIME_LOW)

    def bluetooth_unpair_paired_device(self):
        """
        Name          : bluetooth_unpair_paired_device
        Description   : This method is to unpair(forget) paired device
        Pre-requisite : Only One Device should be paired at a time (as scroll and search for index for required device
                        from paired devices list and click it will be covered in advance cases)
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # device.waitText("Paired devices")

        is_successful = device.tapContentDesc(self.data_model.image_buttons.settings_button.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        if is_successful:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

            device.waitText(self.data_model.text_view.device_details.text)
            device.tapText(self.data_model.buttons.forget.text)
            time.sleep(config.SLEEP_TIME_LOW)

            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.waitText(self.data_model.text_view.forget_device.text)

    def bluetooth_handle_popup_actions(self, index):
        """
        Name          : bluetooth_handle_popup_actions
        Description   : This method is handle all pop up actions in bluetooth module
        Pre-requisite : Popup must be opened from bluetooth module
        Input         : index- enter 0-1 for action to take on forget device dialog like "CANCEL", "FORGET DEVICE", "RENAME"
        Return        : NA
        """
        dialog_actions = [self.data_model.buttons.cancel.text, self.data_model.buttons.forget_device.text, self.data_model.buttons.rename.text]
        device.tapText(dialog_actions[index])
        time.sleep(config.SLEEP_TIME_LOW)

    def bluetooth_connect_disconnected_device(self):
        """
        Name          : bluetooth_connect_disconnected_device
        Description   : This method is to Connect disconnected and paired device
        Pre-requisite : Only One Device should be paired at a time (as scroll and search for index for required device
                        from paired devices list and click it will be covered in advance cases)
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        is_successful = device.tapContentDesc(self.data_model.image_buttons.settings_button.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        if is_successful:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

            device.waitText(self.data_model.text_view.device_details.text)
            device.tapText(self.data_model.buttons.connect.text)
            time.sleep(config.SLEEP_TIME_LOW)

    def bluetooth_device_rename(self):# TODO Pallavi clear edit text and send new_name as parameter
        """
        Name          : bluetooth_device_rename
        Description   : This method is to To rename bluetooth device
        Pre-requisite : Need to open bluetooth setting from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)

        device.waitText(self.data_model.text_view.device_name.text)
        is_successful = device.tapText(self.data_model.text_view.device_name.text)
        time.sleep(config.SLEEP_TIME_LOW)
        if is_successful:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device_conn.sendType("1") # TODO Pallavi  send new_name as parameter
            device_conn.sendType("2") # TODO Pallavi send new_name as parameter
