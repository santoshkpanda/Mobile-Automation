"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import subprocess
import time
import Constants as Constant
from Config import Configuration as config

device = fmbtandroid.Device()


class DeviceScreen:

    def __init__(self):
        pass

    def open_screen_lock(self):
        """
        Name          : open_screen_lock
        Description   : This method is to unlock device screen
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        device.pressHome()
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshScreenshot().save(config.SCREEN_SHOT_LOCATION+"lock.png")
        device.swipeBitmap(config.SCREEN_SHOT_LOCATION+"lock.png", "north")

    def get_on_screen_state(self):
        """
        Name          : get_screen_state
        Description   : This method is to read screen state i.e ON/OFF
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : True or False
        """
        status = False
        st, out, err = device.shellSOE("dumpsys power | grep 'Display Power'")
        if 'ON' in out:
            status = True
        return status

    def get_off_screen_state(self):
        """
        Name          : get_screen_state
        Description   : This method is to read screen state i.e ON/OFF
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : True or False
        """
        time.sleep(config.SLEEP_TIME_20)
        status = False
        st, out, err = device.shellSOE("dumpsys power | grep 'Display Power'")
        if 'OFF' in out:
            status = True
        return status

    def screen_suspend_15sec(self):
        """
        Name          : screen_suspend_15sec
        Description   : This method is to suspend screen in 30 sec
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc3 = subprocess.Popen("adb shell settings put system screen_off_timeout 15000", stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, shell=True)

    def screen_resume(self):
        """
        Name          : screen_resume
        Description   : This method is to resume Device's Screen
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        time.sleep(config.SLEEP_TIME_20)
        device.shellSOE("input keyevent KEYCODE_WAKEUP")
        time.sleep(config.SLEEP_TIME_LOW)

    def screen_suspend_resume(self):
        """
        Name          : screen_suspend_resume
        Description   : This method is to Suspend and resumes Device Screen
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        self.screen_suspend_15sec()
        time.sleep(Constant.SLEEP_TIME_EIGHTEEN)
        self.screen_resume()
        time.sleep(config.SLEEP_TIME_LOW)

