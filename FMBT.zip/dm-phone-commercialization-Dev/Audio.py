""""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pradnya Bargal'
__email__ = 'pradnya.bargal@darkmatter.ae'
__version__ = '1.0'
__Date__ = '04 Oct 2018'

import fmbtandroid
import time
import Constants as Constant
from CommonFunctions import CommonFunctions
from Config import Configuration as config
import DeviceScreen

device = fmbtandroid.Device()
common = CommonFunctions()


class Audio:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Audio.json')

    def audio_play_music_app_launch(self):
        """
        Function Name   : audio_play_music_launch
        Description     : This method launches Music Player app
        Prerequisites   : Launcher must be open
        Input           : NA
        Return          : NA
        """
        screen = DeviceScreen.DeviceScreen()
        screen.open_screen_lock()
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.app_name)
        time.sleep(config.SLEEP_TIME_LOW)

    def audio_play(self):
        """
        Function Name   : audio_play
        Description     : This method plays a specific audio
        Prerequisites   : Music player must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(config.AUDIO_TO_BE_PLAYED)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Play.content_desc)
        contentDesc = common.get_content_desc_by_id(self.data_model.image_button.Play.id)
        return contentDesc

    def audio_pause(self):
        """
        Function Name   : audio_pause
        Description     : This method pauses the playing audio
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Pause.content_desc)
        contentDesc = common.get_content_desc_by_id(self.data_model.text.audio_play.id)
        return contentDesc

    def audio_play_from_play_control(self):
        """
        Function Name   : audio_play_from_play_control
        Description     : This method plays song from play controls button
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : Return Pause as a string
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.play_control.Play.content_desc)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        contentDesc = common.get_content_desc_by_id(self.data_model.play_control.Play.id)
        return contentDesc

    def audio_pause_from_play_control(self):
        """
        Function Name   : audio_pause_from_play_control
        Description     : This method pauses the song from play controls button
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : Return Play as a string
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.play_control.Pause.content_desc)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        contentDesc = common.get_content_desc_by_id(self.data_model.play_control.Pause.id)
        return contentDesc



    def audio_play_next_Audio(self):
        """
        Function Name   : audio_play_next_Audio
        Description     : This method plays next audio from list
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.drag(config.DRAG_SCREEN_X1Y1, config.DRAG_SCREEN_X2Y2)  #TODO Pradnya update coordinates as per katim device
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        currentTrack = common.get_text_by_id(self.data_model.play_control.Next.id)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.play_control.Next.content_desc)
        return currentTrack

    def audio_play_previous_audio(self):
        """
        Function Name   : audio_play_previous_audio
        Description     : This method plays previous audio
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """

        device.refreshView(uiautomatorDump=True)
        currentTrack = common.get_text_by_id(self.data_model.play_control.Next.id)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.play_control.Previous.content_desc)
        device.tapContentDesc(self.data_model.play_control.Previous.content_desc)

        return currentTrack

    def audio_shuffle_enable_disable(self):
        """
        Function Name   : audio_shuffle_enable_disable
        Description     : This method is to enable or disable audio list shuffle option
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Shuffle.content_desc)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        content = common.get_content_desc_by_id(self.data_model.image_button.Shuffle.id)
        time.sleep(config.SLEEP_TIME_LOW)
        return content

    def audio_enable_all_repeat(self):
        """
        Function Name   : audio_enable_all_repeat
        Description     : This method repeats the complete playlist
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Repeat_all.content_desc)

    def audio_repeat_audio_once(self):
        """
        Function Name   : audio_repeat_audio_once
        Description     : This method repeats the ongoing audio
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Repeat_once.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Repeat_once.content_desc)

    def audio_repeat_audio_disable(self):
        """
        Function Name   : audio_repeat_audio_disable
        Description     : This method disables the audio repeat option
        Prerequisites   : Play control from Music player app must be open
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.Repeat_disable.content_desc)

    def audio_close_music_play(self):
        """
        Function Name   : audio_close_music_play
        Description     : This method closes the music player
        Prerequisites   : Music player must be open
        Input           : NA
        Return          : NA
        """
        common.close_application(self.data_model.image_button.close.text)

