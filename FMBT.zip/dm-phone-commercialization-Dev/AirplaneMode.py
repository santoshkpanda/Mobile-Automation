"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '05 Oct 2018'

import fmbtandroid
import time
import subprocess
import Constants as Constant
from Config import Configuration as config

device = fmbtandroid.Device()


class AirplaneMode:
    def __init__(self):
        pass

    def airplane_mode_get_state(self):
        """
        Name          : get_airplane_mode_state
        Description   : This method is to get airplane mode state enabled/disabled(On/Off)
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Return '1' or '0' if airplane mode is enabled or disabled respectively.
        """
        proc3 = subprocess.Popen("adb shell settings get global airplane_mode_on", stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, shell=True)
        output = proc3.stdout.read(1)
        return output

    def airplane_mode_enable(self):
        """
        Name          : airplane_mode_enable
        Description   : This method is to turn airplane mode On
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put global airplane_mode_on 1", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def airplane_mode_disable(self):
        """
        Name          : airplane_mode_disable
        Description   : This method is to turn airplane mode Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell settings put global airplane_mode_on 0", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def airplane_mode_enable_disable(self):
        """
        Name          : airplane_mode_enable_disable
        Description   : This method is to toggle Airplane mode On-Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        state = self.airplane_mode_get_state()
        if state == Constant.STATE_ENABLED:
            self.airplane_mode_disable()
            self.airplane_mode_enable()
        elif state == Constant.STATE_DISABLED:
            self.airplane_mode_enable()
            self.airplane_mode_disable()

    def assert_airplane_mode_state(self, expected_output):
        """
        Name          : assert_airplane_mode_state
        Description   : This method is to assert airplane mode changed state
        Pre-requisite : Device's adb shell should be accessible
        Input         : actual_output-  output return by get_airplane_mode_state() after change in state
                        expected_output-    This is expected output after change in state
        Return        : NA
        """
        print("Asserting airplane mode changed status ...")
        actual_output = self.airplane_mode_get_state()
        print(actual_output + "==" + expected_output)
        if Constant.STATE_ENABLED == actual_output:
            print("Airplane mode Turned ON")
        elif Constant.STATE_DISABLED == actual_output:
            print("Airplane mode Turned OFF")
        else:
            print("Invalid Airplane Mode")
        assert actual_output == expected_output
