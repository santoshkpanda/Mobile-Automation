"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Aakib Qureshi'
__email__ = 'Aakib Qureshi@darkmatter.ae'
__version__ = '1.0'
__Date__ = '23 Oct 2018'


import time
import subprocess
import fmbtandroid
from Config import Configuration as config

"""This modules has class providing common functionalities which will be used through out different modules"""

device = fmbtandroid.Device()


class Assertion:
    def assert_text_on_screen(self, expected_text):
        """
        Name            : assert_text_on_screen
        Description     : This method is to verify expected text to actual text on current screen. this will fail
                        the test case if the text is not available.
        Input           : expected_text
        Return          : assertion if failed

        """
        device.refreshView(uiautomatorDump=True)
        flag = device.verifyText(expected_text)

        if flag:
            print(expected_text + " is displayed")
        else:
            print(expected_text + " is not displayed")
            assert flag == True

    def assert_equals(self, actual, expected):
        """
        Name            : assert_equals
        Description     : This method is to verify expected to actual
        Input           : actual ,expected
        Return          : NA

        """
        assert (actual == expected), expected+" not found"

    def assert_text_on_screen_not_displayed(self, expected_text):
        """
        Name            : assert_text_on_screen
        Description     : This method is to verify expected text to actual text on current screen. this will fail
                        the test case if the text is not available.
        Input           : expected_text
        Return          : assertion if failed

        """
        device.refreshView(uiautomatorDump=True)
        flag = device.verifyText(expected_text)

        if flag:
            print(expected_text + " is displayed")
            assert flag == True
        else:
            print(expected_text + " is not displayed")

