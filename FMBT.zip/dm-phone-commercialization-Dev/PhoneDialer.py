"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__Author__ = 'Pradnya Bargal'
__Email__ = 'pradnya.bargal@darkmatter.ae'
__Version__ = '1.0'
__Date__='04 Oct 2018'

import fmbtandroid
import time
import CommonFunctions
import Constants as Constant
from Config import Configuration as config
import DeviceScreen
import Messaging

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
device_screen = DeviceScreen.DeviceScreen()
messaging = Messaging.Messaging()


class PhoneDialer:
    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Phone_dialer.json')
        pass

    def dialer_open_lock_screen(self):
        """
        Function Name   : messaging_open_lock_screen
        Description     : This method opens the lock screen
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : True or false
        """
        device_screen.open_screen_lock()

    def dialer_launch(self):
        """
        Function Name   : dialer_launch
        Description     : This method opens the Launcher followed by opening the applist and then finally opening the phone app
        Prerequisites   : The phone must be switched on
        Input           : NA
        Return          : True or false
        """
        device_screen.open_screen_lock()
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.text_view.phone_app.text)
        return flag

    def dialer_keypad_open(self):
        """
        Function Name   : dialer_keypad_open
        Description     : This method taps the Keypad to open the dialpad of the phone
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.key_pad.content_desc)

    def dialer_enter_number(self, index):
        """
        Function Name   : dialer_enter_number
        Description     : This method dials the phone number
        Prerequisites   : Phone dialer should be open
        Input           : index: It is the index to the list to fetch a particular number
        Return          : True or false
        """
        cmd = "input text " + config.PHONE_NUMBER_LIST[index]
        st, out, err = device.shellSOE(cmd)
        flag = False
        if st == 0 and out is not None:
            flag = True
        return flag

    def dialer_number_call(self):
        """
        Function Name   : phone_number_call
        Description     : This method calls the dialed number
        Prerequisites   : The required number should be dialed in the dialer
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.dial.content_desc)
        time.sleep(config.SLEEP_TIME_CALL)
        return flag

    def dialer_end_call(self):
        """
         Function Name   : dialer_end_call
         Description     : This method ends the ongoing call
         Prerequisites   : The call must be ongoing
         Input           : NA
         Return          : True or false
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.end_call.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_create_contact(self, index):
        """
        Function Name   : dialer_create_contact
        Description     : This method creates a new contact and saves the dialed number
        Prerequisites   : The required number should be dialed in the dialer
        Input           : index: It is the index to the list to fetch a particular number
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.create_new_contact.text)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.first_name.text)
            if flag:
                flag = device_conn.sendType(Constant.SAVE_PHONE_NUMBER_LIST[index])
                if flag:
                    device.refreshView(uiautomatorDump=True)
                    time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                    flag = device.tapContentDesc(self.data_model.Phone_Dialer.text_view.save.text)
        return flag

    def dialer_handle_pop_up_box(self, txt):
        """
         Function Name   : dialer_handle_pop_up_box
         Description     : This method taps on the input text provided
         Prerequisites   : A screen containing a pop up box must appear on the screen
         Input           : txt : It is a string which represents various pop up options like "DELETE" or "BLOCK" etc
         Return          : True or false
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(txt)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_delete_contact(self):
        """
        Function Name   : dialer_delete_contact
        Description     : This method deletes the recently saved contact
        Prerequisites   : The phone app must be open and the contact to be deleted should be saved
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.more_options.content_desc)
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.delete.text)
            if flag:
                flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.delete.text)
        return flag

    def dialer_check_backspace_of_dialer(self):
        """
        Function Name   : dialer_check_backspace_of_dialer
        Description     : This method erases a ten digit number entered in the dialer
        Prerequisites   : The phone app must be open and the dialer should have a 10 digit number dialed on the dial pad
        Input           : NA
        Return          : True or false
        """
        self.dialer_enter_number(1)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = False
        for i in range(0, 10):
            flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.backspace.content_desc)
            time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return flag

    def dialer_search_contacts_given_by_keyboard_input(self):
        """
        Function Name   : dialer_search_contacts_given_by_keyboard_input
        Description     : This method searches a specific contact
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.search_contacts.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            flag = device_conn.sendType(config.SEARCH_CONTACT)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                device.pressBack()
                time.sleep(config.SLEEP_TIME_LOW)
                device.pressBack()
        return flag

    def dialer_call_history_tab(self):
        """
        Function Name   : dialer_call_history_tab
        Description     : This method views Call History of all contacts
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.Buttons.history_tab.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_block_unblock_number_via_recent_calls(self, index):
        """
        Function Name   : dialer_block_unblock_number_via_recent_calls
        Description     : This method blocks a particular number form the recent calls and unblocks it again
        Prerequisites   : The phone recent calls tab also called call history tab must be open
        Input           : index: It is the index to the list to fetch a particular number
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.CONTACT_LIST[index])
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.block_numbers_via_recent_calls.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.block_from_recent.text)
                time.sleep(config.SLEEP_TIME_LOW)
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                flag = device.tapText(self.data_model.Phone_Dialer.text_view.unblock_number_via_recent_calls.text)
                time.sleep(config.SLEEP_TIME_LOW)
                self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.unblock_from_recent.text)
        return flag

    def dialer_send_message_via_recent_calls(self, index):
        """
         Function Name   : dialer_send_message_via_recent_calls
         Description     : This method sends a message to a  particular number from the recent calls
         Prerequisites   : The phone recent calls tab also called call history tab must be open and the number that the
                           message is to be sent should be tapped
         Input           : index: It is the index to the list to fetch a particular number
         Return          : True or false
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.CONTACT_LIST[index])
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.send_message_via_recent_calls.text)
            if flag:
                flag = messaging.messaging_write_message()
                if flag:
                    flag = messaging.messaging_send_message()
        return flag

    def dialer_check_call_details(self, index):
        """
          Function Name   : dialer_check_call_details
          Description     : This method checks the call details with a particular number or contact
          Prerequisites   : The phone recent calls tab also called call history tab must be open and the number that the
                            call details are to be checked should be tapped
          Input           : index: It is the index to the list to fetch a particular number
          Return          : True or false
          """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.CONTACT_LIST[index])
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.call_details.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.close.content_desc)
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_add_contact_to_favorites(self):
        """
          Function Name   : dialer_add_contact_to_favorites
          Description     : This method adds a number to the favorites
          Prerequisites   : The phone contact tab must be open
          Input           : NA
          Return          : True or false
          """
        flag = self.dialer_go_to_all_contacts()
        if flag:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(config.ADD_TO_FAVORITES)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.add_to_favorites.content_desc)
            time.sleep(config.SLEEP_TIME_LOW)
            device.pressBack()
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_add_to_contacts_via_recent_calls(self):
        """
        Function Name   : dialer_add_to_contacts_via_recent_calls
        Description     : This method adds a particular number form the recent calls
        Prerequisites   : The phone recent calls tab also called call history tab must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(config.SAVE_VIA_RECENT_CONTACTS)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.add_to_contacts_via_recent_calls.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                flag = self.dialer_create_contact(1)
        return flag

    def dialer_go_to_all_contacts(self):
        """
        Function Name   : dialer_go_to_all_contacts
        Description     : This method views All contacts available
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.Buttons.all_contacts.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_favorites(self):
        """
        Function Name   : dialer_favorites
        Description     : This method views Favorite contacts
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.Buttons.all_favorite_contacts.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_voice_search_contacts(self):
        """
        Function Name   : dialer_voice_search_contacts
        Description     : This method searches contacts using VoiceSearch
        Prerequisites   : The phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.voice_search.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return flag

    def dialer_clear_frequents(self):
        """
        Function Name   : dialer_clear_frequents
        Description     : This method clears the frequent contacts form dialer
        Prerequisites   : The 'more options' icon in the phone app should be tapped
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.more_options.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.clear_frequents.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.cancel.text)
        return flag

    def dialer_launch_settings(self):
        """
        Function Name   : dialer_launch_settings
        Description     : This method opens settings option
        Prerequisites   : Phone dialer must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapContentDesc(self.data_model.Phone_Dialer.Buttons.more_options.content_desc)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.settings_open.text)
        return flag

    def dialer_settings_display_options(self):
        """
        Function Name   : dialer_settings_display_options
        Description     : This method sets display options like Sort by and Name format
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        flag = self.dialer_launch_settings()
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.display_options.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                flag = device.tapText(self.data_model.Phone_Dialer.text_view.sort_by.text)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    device.pressBack()
                    device.refreshView(uiautomatorDump=True)
                    time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                    flag = device.tapText(self.data_model.Phone_Dialer.text_view.name_format.text)
                    time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_settings_sounds_and_vibrations(self):
        """
        Function Name   : dialer_settings_sounds_and_vibrations
        Description     : This method sets the ring tone and sets the vibration option
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        self.dialer_launch_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.sounds_and_vibrations.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.phone_ringtone.text)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_settings_edit_quick_responses(self):
        """
        Function Name   : dialer_settings_edit_quick_responses
        Description     : This method opens the Edit the quick responses page
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        self.dialer_launch_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.quick_responses.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_settings_edit_call_settings(self):
        """
        Function Name   : dialer_settings_edit_call_settings
        Description     : This method opens the page to edit different call settings like call forwarding
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        self.dialer_launch_settings()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.calls_settings.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_call_forwarding(self):
        """
        Function Name   : dialer_call_forwarding
        Description     : This method edits the Option 'Call forwarding'
        Prerequisites   : 'Calls' option in phone settings must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.call_forwarding.text)
        if flag:
            time.sleep(config.SLEEP_TIME_HIGH)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText("Always forward")
            if flag:
                time.sleep(config.SLEEP_TIME_MEDIUM)
                flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.turn_on.text)
                time.sleep(config.SLEEP_TIME_HIGH)
        return flag

    def dialer_fixed_dialing_number(self):
        """
        Function Name   : dialer_fixed_dialing_number
        Description     : This method visits the Option 'Fixed Dialing Number'
        Prerequisites   : In settings calls option must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.FDN_LIST[0])
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_enable_fdn(self):
        """
        Function Name   : dialer_enable_fdn
        Description     : This method edits the Option 'Fixed Dialing Number' by enabling FDN
        Prerequisites   : 'Fixed Dialing Number' option in phone settings must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.FDN_LIST[1])
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device_conn.sendType(Constant.FDN_OLD)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.OK.text)
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def change_pin_2(self):
        """
        Function Name   : change_pin_2
        Description     : This method edits the Option 'Fixed Dialing Number' by changing PIN2
        Prerequisites   : 'Fixed Dialing Number' option in phone settings must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(Constant.FDN_LIST[2])
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device_conn.sendType(Constant.FDN_OLD)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.OK.text)
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_settings_edit_call_blocking(self):
        """
        Function Name   : dialer_settings_edit_call_blocking
        Description     : This method opens page to set a particular number to BLOCKED STATE
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.call_blocking_settings.text)
        if flag:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.Phone_Dialer.text_view.add_number_to_block.text)
            if flag:
                time.sleep(config.SLEEP_TIME_LOW)
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                flag = device.tapText(self.data_model.Phone_Dialer.text_view.phone_number_to_block.text)
                if flag:
                    time.sleep(config.SLEEP_TIME_LOW)
                    flag = device_conn.sendType(Constant.NUMBER_TO_BE_BLOCkED)
                    if flag:
                        flag = self.dialer_handle_pop_up_box(self.data_model.Phone_Dialer.Handle_pop_up_box.block.text)
        return flag

    def dialer_settings_accessibility(self):
        """
        Function Name   : dialer_settings_accessibility
        Description     : This method edits the accessibility option in the phone settings
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        flag = False
        for x in config.ACCESSIBILITY_LIST[:]:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(x)
            time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_settings_voicemail(self):
        """
        Function Name   : dialer_settings_voicemail
        Description     : This method sets Voice Mails Settings
        Prerequisites   : Phone settings must be open
        Input           : NA
        Return          : True or false
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.text_view.voicemail_settings.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_enable_disable_callID_and_spams(self):
        """
         Function Name   : dialer_enable_disable_callID_and_spams
         Description     : This method enables or disables the 'CALL id and spams' option in the settings
         Prerequisites   : Phone settings must be open
         Input           : NA
         Return          : True or false
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = device.tapText(self.data_model.Phone_Dialer.Buttons.caller_id_spam.text)
        time.sleep(config.SLEEP_TIME_LOW)
        if flag:
            flag = device.tapText(self.data_model.Phone_Dialer.Buttons.caller_id_spam.text)
            time.sleep(config.SLEEP_TIME_LOW)
            if flag:
                flag = device.tapText(self.data_model.Phone_Dialer.Buttons.caller_id_spam.text)
                time.sleep(config.SLEEP_TIME_LOW)
        return flag

    def dialer_close(self):
        """
        Function Name   : phone_dialer_close
        Description     : This method closes the Phone app
        Prerequisites   : Phone app must be open
        Input           : NA
        Return          : True or false
        """
        device.pressHome()
        common.close_application(self.data_model.Phone_Dialer.Buttons.close_phone.content_desc)

