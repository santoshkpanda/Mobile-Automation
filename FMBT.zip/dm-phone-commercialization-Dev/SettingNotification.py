"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__author__ = "Aakib Qureshi"
__email__ = "aakib.qureshi@darkmatter.ae"
__version__ = "1.0"
__date__ = "15 Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
from CommonFunctions import CommonFunctions

device = fmbtandroid.Device()
device_connection = fmbtandroid._AndroidDeviceConnection(fmbtandroid.listSerialNumbers()[0])
common = CommonFunctions()

class SettingNotification:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/SettingNotification.json')
        pass

    def setting_click_apps_and_notification(self):
        """
       Name            = setting_click_apps_notification
       Description     = this method is use to click apps and notification in the setting
       Pre-requisites  = 1. Firstly run setting_display_open->setting_display
       Input           = NA
       Return          = True And False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.app_notification.text)
        return status

    def setting_click_apps_notification(self):
        """
        Name            = setting_click_apps_notification
        Description     = this method is use to click app notification and after that Notification menu.
        Pre-requisites  = 1. Firstly run setting_display_open->setting_display->setting_click_apps_and_notification
        Input           = NA
        Return          = NA
        """

        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.notification.text)
        return status

    def setting_app_notification(self):
        """
        Name            = setting_app_notification
        Description     = this method is use to click app notification menu.
        Pre-requisites  = 1. Firstly run setting_display_open->setting_display->setting_click_apps_notification

        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.app_notifications.text)
        return status

    def setting_all_app(self):
        """
        Name            = setting_all_app
        Description     = this method is use to click all apps notification.
        Pre-requisites  = firstly run setting_display_open_setting->setting_click_apps_notification
                         ->setting_app_notification()
        Input           = NA
        Return          = NA
       """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        device.tapText(self.data_model.text_view.all_apps.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.all_apps.text)
        return status

    def setting_apps_turned_off(self):
        """
        Name            = setting_apps_turned_off
        Description     = this method is use to turned off all the notification.
        Pre-requisites  = firstly run setting_display_open_setting->setting_click_apps_notification
                           ->setting_app_notification()
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        device.tapText(self.data_model.text_view.all_apps.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.turned_off.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def setting_click_on_the_lock_screen(self):
        """
        Name            = setting_show_all_notification_content
        Description     = this method is use to click on the lock screen.
        Pre-requisites   = firstly run setting_display_open_setting->setting_click_apps_notification

        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.on_lock_screen.text)
        return status

    def setting_show_all_notification_content(self):
        """
        Name            = setting_show_all_notification_content
        Description     = this method is use to click show all notification content.
        Pre-requisites   = firstly run setting_display_open_setting->setting_click_apps_notification
        Input           = NA
        Return          = NA
        """

        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        status = device.tapText(self.data_model.text_view.show_all_notifications.text)
        return status

    def setting_dont_show_notification_content(self):
        """
        Name            = setting_dont_show_notification_content
        Description     = this method is use to click don't show all notification content.
        Pre-requisites   = firstly run setting_display_open_setting->setting_click_apps_notification
        Input           = NA
        Return          = NA
        """

        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        text = common.get_text_by_id(self.data_model.text_view.do_not_show_all_notifications.id, 1)
        status = device.tapText(text)
        return status

    def setting_allow_notification_dots(self, status):
        """
        Name            = setting_allow_notification_dots
        Description     = this method is use to allow notification dots.
        Pre-requisites   = firstly run setting_display_open_setting->setting_click_apps_notification
        Input           = "ON", "OFF"
        Return          = True and False
        """
        flag = False
        if status == self.data_model.text_view.OFF.text:
            device.refreshView(uiautomatorDump=True)
            flag = device.tapText(self.data_model.text_view.ON.text)
        elif status == self.data_model.text_view.ON.text:
            device.refreshView(uiautomatorDump=True)
            flag = device.tapText(self.data_model.text_view.OFF.text)
        return flag

    def setting_default_notification_sound(self):
        """
        Name            = setting_default_notification_sound
        Description     = this method is use to click default notification sound after that choose one ringtone and
                            select as a default notification tone.
        Pre-requisites  = firstly run setting_display_open_setting->setting_click_apps_notification
                         ->setting_show_all_notification_content
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.default_notification_sound.text)
        device.refreshView(uiautomatorDump=True)
        device.tapText(config.RINGTONE)
        device.refreshView(uiautomatorDump=True)
        status = device.tapText(self.data_model.text_view.ok.text)
        return status

