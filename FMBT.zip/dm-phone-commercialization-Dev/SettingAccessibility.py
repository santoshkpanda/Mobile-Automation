"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '27 Nov 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config
import Settingdisplay
import Clock


device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
display = Settingdisplay.Settingdisplay()
clock = Clock.Clock()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class SettingAccessibility:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/setting.json')
        pass

    def setting_launch(self):
        """
        Name          : setting_launch
        Description   : This method is to launch setting application
        Pre-requisite : App list should be open
        Input         : NA
        Return        : True or False
        """
        device.pressHome()
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status= device.tapText(self.data_model.app_name)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def setting_accessibility_launch(self):
        """
        Name          : setting_accessibility_launch
        Description   : This method is to accessibility open setting inside the setting application
        Pre-requisite : Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.accessibility.text)
        return status

    def setting_accessibility_volume_key_shortcut_on_off(self):
        """
        Name          : setting_accessibility_volume_key_shortcut_on_off
        Description   : This method is to on and off volume key shortcut setting inside the accessibility from setting application
        Pre-requisite : Accessibility setting from setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.volume_key_shortcut.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.on.text)
            if flag:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapText(self.data_model.text_view.off.text)

        return status

    def setting_accessibility_volume_key_shortcut_select_shortcut_service(self,index):
        """
        Name          : setting_accessibility_volume_key_shortcut_select_shortcut_service
        Description   : This method is to select shortcut service from volume key shortcut setting inside the
                        accessibility from setting application
        Pre-requisite : Volume key shortcut setting inside the Accessibility setting from setting application should  be
                        open
        Input         : index :0 : TalkBack,
                              :1 :Select to Speak,
                              :2 :Switch Access
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.shortcut_service.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(Constant.SHORTCUT_SERVICE[index])
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        clock.clock_handle_popup_actions(0)
        device.pressBack()
        return status

    def setting_accessibility_volume_key_allow_from_lock_screen_on_off(self):
        """
        Name          : setting_accessibility_volume_key_allow_from_lock_screen_on_off
        Description   : This method is to on and off allow from lock screen setting inside the volume key settings inside
                        accessibility from  setting application
        Pre-requisite : Volume key shortcut setting inside the Accessibility setting from setting application should  be
                        open
        Input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.allow_from_lock_screen.text)
        device.pressBack()
        return status

    def setting_accessibility_select_to_speak_on_off(self):
        """
        Name          : setting_accessibility_select_to_speak_on_off
        Description   : This method is to on and off select to speak setting inside the accessibility from  setting
                        application
        Pre-requisite : Accessibility setting from setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.select_to_Speak.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.off.text)
            if flag:
                clock.clock_handle_popup_actions(1)
                device.pressBack()

        return flag

    def setting_accessibility_select_talk_back(self):
        """
        Name          : setting_accessibility_select_talk_back
        Description   : This method is to on and off select talk back setting inside the accessibility from  setting
                        application
        Pre-requisite : Accessibility setting from setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.talkBack.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.off.text)
            clock.clock_handle_popup_actions(1)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.pressBack()
        return flag

    def setting_accessibility_font_size(self):
        """
        Name          : setting_accessibility_font_size_new
        Description   : This method is to change font size  accessibility of setting application
        Pre-requisite : Accessibility setting from setting application should  be open
        Input         : text_size: 0 = Default
                                   1 = Large
                                   2 = Largest
                                   3 = Small
        Return        : True or False
        """
        flag = False
        status = display.display_open_font_size_setting()
        if status:
            flag = display.display_set_font_size_setting(1)
            device.pressBack()
        return flag

    def setting_accessibility_display_size(self):
        """
        Name          : setting_accessibility_display_size
        Description   : This method is to change display size setting inside the accessibility of setting application
        Pre-requisite : Accessibility option form Setting application should  be open
        Input         : display_size: 0 : Default
                                   :1 : Large
                                   :2 : Largest
                                   :3 : Small
        Return        : True or False
        """
        # common.device_screen_swipe_up1()
        status = display.setting_display_open_display_size()
        if status:
            status = display.setting_display_set_display_size(1)
            device.pressBack()
        print status
        return status

    def setting_accessibility_magnification(self):
        """
        Name          : setting_accessibility_magnification
        Description   : This method is to open magnification setting form inside the accessibility of setting application
        Pre-requisite : Accessibility option form Setting application should  be open
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.magnification.text)
        return status

    def setting_accessibility_magnification_magnify_with_triple_tap(self):
        """
        Name          : setting_accessibility_magnification_on
        Description   : This method is to open magnify with triple tap setting inside magnification setting inside the
                        accessibility of setting application
        Pre-requisite : magnification setting inside accessibility from Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.magnify_with_triple_tap.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.off.text)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text_view.on.text)
            device.pressBack()
        return status

    def setting_accessibility_magnification_magnify_with_button(self):
        """
        Name          : setting_accessibility_magnification_off
        Description   : This method is to open magnify with button setting inside magnification setting inside the
                        accessibility of setting application
        Pre-requisite : magnification setting inside accessibility from Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        flag = False
        status = device.tapText(self.data_model.text_view.magnify_with_button.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.off.text)
            if flag:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                time.sleep(config.SLEEP_TIME_LOW)
                flag = device.tapText(self.data_model.text_view.on.text)
                device.pressBack()
                device.pressBack()
        return flag

    def setting_accessibility_color_correction(self):
        """
        Name          : setting_accessibility_Color_correction
        Description   : This method is to on and off color correction setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        status = False
        common.device_screen_swipe_up1()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        # print(device.waitText(self.data_model.text_view.color_correction.text))
        status = device.tapText(self.data_model.text_view.color_correction.text)
        print(status)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text_view.off.text)
            if status:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapText(self.data_model.text_view.on.text)
        return status

    def setting_accessibility_color_correction_mode(self):
        """
        Name          : setting_accessibility_color_correction_mode
        Description   : This method is to set color correction mode setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.correction_mode.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(Constant.CORRECTION_MODE[1])
            device.pressBack()
        return status

    def setting_accessibility_Color_inversion(self):
        """
        Name          : setting_accessibility_Color_inversion
        Description   : This method is to on and off color inversion setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        common.device_screen_swipe_up1()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.colour_inversion.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.colour_inversion.text)
        return flag

    def setting_accessibility_Click_after_pointer_stops_moving_on_off(self):
        """
        Name          : setting_accessibility_Click_after_pointer_stops_moving_on_off
        Description   : This method is to open click after pointer stop moving setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.click_after_pointer_stops_moving.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text_view.off.text)
            if status:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapText(self.data_model.text_view.on.text)
                device.pressBack()
        return status

    def setting_accessibility_Power_button_ends_call_on_off(self):
        """
        Name          : setting_accessibility_Power_button_ends_call_on_off
        Description   : This method is to open power button ends call setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.power_button_ends_call.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text_view.power_button_ends_call.text)
        return status

    def setting_accessibility_Auto_rotate_screen_on_off(self):
        """
        Name          : setting_accessibility_Auto_rotate_screen_on_off
        Description   : This method is to auto rotate screen  setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.auto_rotate_screen.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            status = device.tapText(self.data_model.text_view.auto_rotate_screen.text)
        return status

    def setting_accessibility_Touch_and_hold_delay(self):
        """
        Name          : setting_accessibility_Touch_and_hold_delay
        Description   : This method is to touch and hold delay setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.touch_and_hold_delay.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(Constant.TOUCH_AND_HOLD_DELAY[0])
        return flag

    def settings_accessibility_mono_audio(self):
        """
        Name          : settings_accessibility_mono_audio
        Description   : This method is to on and off mono audio setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.mono_audio.text)
        return status

    def setting_accessibility_captions_on_off(self):
        """
        Name          : setting_accessibility_captions_on_off
        Description   : This method is to on and off captions setting inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        flag = False
        common.device_screen_swipe_up()
        common.device_screen_swipe_up1()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.captions.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.On.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.Off.text)
            device.pressBack()
        return flag

    def setting_accessibility_High_contrast_text(self):
        """
        Name          : setting_accessibility_High_contrast_text
        Description   : This method is to on and off high contrast text inside the accessibility of setting
                        application
        Pre-requisite : Accessibility setting form Setting application should  be open
        Input         : NA
        Return        : True or False
        """
        common.device_screen_swipe_up()
        common.device_screen_swipe_up1()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.waitText(self.data_model.text_view.high_contrast_text.text)
        status = device.tapText(self.data_model.text_view.high_contrast_text.text)
        return status

    def setting_accessibility_close(self):
        """
        Name          : setting_accessibility_close
        Description   : This method is to close setting application
        Pre-requisite : Accessibility setting form Setting application should  be open
        input         : NA
        Return        : NA
        """
        common.close_application("Dismiss Settings.")

