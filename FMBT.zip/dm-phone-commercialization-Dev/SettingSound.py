"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__author__ = "Aakib Qureshi"
__email__ = "aakib.qureshi@darkmatter.ae"
__version__ = "1.0"
__date__ = "16th Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
from CommonFunctions import CommonFunctions

device = fmbtandroid.Device()
common = CommonFunctions()
device_connection = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))

class SettingSound:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/SettingSound.json')
        pass

    def click_on_sound(self):
        """
        Name            = click_on_sound
        Description     = this method click on sound inside the setting menu.
        Pre-requisites  = 1. firstly run setting_display_open_setting
                          2. device should be there.
                          3. Android 8.1
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Sound.text)
        return is_tap

    def sound_media_volume(self):
        """
        Name            = sound_media_volume
        Description     = this method is to clicked on media volume.
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound
        Input           = NA
        Return          = True and False
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        is_tap = device.tapContentDesc(self.data_model.text_view.Media_volume.ContentDesc)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_alarm_volume(self):
        """
        Name            = sound_alarm_volume
        Description     = this method to clicked on alarm volume.
        Pre-requisites = 1. firstly run setting_display_open_setting->click_on_sound
        Input           = NA
        Return          = True and False
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        is_tap = device.tapContentDesc(self.data_model.text_view.Alarm_volume.ContentDesc)
        return is_tap

    def sound_ring_volume(self):
        """
        Name            = sound_ring_volume
        Description     = this method clicked on ring volume.
        Pre-requisites  =   1. firstly run setting_display_open_setting->click_on_sound
        Input           = NA
        Return          = True and False
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        is_tap = device.tapContentDesc(self.data_model.text_view.Ring_volume.ContentDesc)
        return is_tap

    def sound_vibrate_for_calls(self):
        """
        Name            = sound_vibrate_for_calls
        Description     = this method enables and then disable vibrate for call option.
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.vibrate_for_call.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.vibrate_for_call.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_do_not_disturb_preferences_click(self):
        """
        Name            = sound_do_not_disturb_preferences_click
        Description     = this method clicks  on Do Not Disturb preferences menu.
        Pre-requisites  =
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.DND_prefrence.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_priority_only_allows_click(self):
        """
        Name            = sound_priority_only_allows_click
        Description     = this method clicks  on Priority ONly Allows option.
        Pre-requisites  =
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Priority_only_allows.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_reminder_click(self):
        """
        Name            = sound_reminder_click
        Description     = this method enables and disables reminder option in priority only allow .
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                          do_not_disturb_preferences_click->priority_only_allows_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Reminders.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Reminders.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_events_click(self):
        """
        Name            = sound_events_click
        Description     = this method enables and disables events option in priority only allow .
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                         do_not_disturb_preferences_click->priority_only_allows_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Events.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Events.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_messages_click(self):
        """
        Name            = sound_messages_click
        Description     = this method enables and disables messages option
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                        do_not_disturb_preferences_click->priority_only_allows_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Messages.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.from_anyone.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_calls_click(self):
        """
        Name            = sound_calls_click
        Description     = this method enables and disables calls option
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                          do_not_disturb_preferences_click->priority_only_allows_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Calls.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.From_contacts_only.text)
        return is_tap

    def sound_repeat_callers_click(self):
        """
        Name            = sound_repeat_callers_click
        Description     = this method enables and disables repeatcallers option
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                         do_not_disturb_preferences_click->priority_only_allows_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Repeat_callers.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Repeat_callers.text)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_block_visual_disturbances_click(self):
        """
        Name            = sound_block_visual_disturbances_click
        Description     = this method clicks on block visual disturbances option
        Pre-requisites  =
        Input           = NA
        Return          = True And False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Block_visual_disturbances.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_block_when_screen_on_click(self):
        """
        Name            = sound_block_when_screen_on_click
        Description     = this method enables and disables block_when_screen_on option
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                        do_not_disturb_preferences_click->block_visual_disturbances_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Block_when_screen_is_on.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Block_when_screen_is_on.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_block_when_screen_off_click(self):
        """
        Name            = sound_block_when_screen_off_click
        Description     = this method enables and disables block_when_screen_off option
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->
                         do_not_disturb_preferences_click->block_visual_disturbances_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.Block_when_screen_is_off.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Block_when_screen_is_off.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return is_tap

    def sound_phone_ring_tone_click(self):
        """
        Name            = sound_phone_ring_tone_click
        Description     = this method selects phone phone_ring_tone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Phone_ringtone.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_phone_ring_tone_select(self):
        """
        Name            = sound_phone_ring_tone_select
        Description     = this method selects phone phone_ring_tone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->phone_ring_tone_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.phone_ringtone_set.text)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.OK.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_advanced_click(self):
        """
        Name            = sound_advanced_click
        Description     = this method clicks on advanced option
        Pre-requisites  =
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Advanced.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_default_notification_sound_click(self):
        """
        Name            = sound_default_notification_sound_click
        Description     = this method selects default notification ringtone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
        Input           = NA
        Return          = True and False
         """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Default_notification_sound.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_default_notification_sound_select(self):
        """
        Name            = sound_default_notification_sound_select
        Description     = this method selects default notification ringtone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
                                      ->default_notification_sound_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.default_notification_tone.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap= device.tapText(self.data_model.text_view.OK.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_default_alarm_sound_click(self):
        """
        Name            = sound_default_alarm_sound_click
        Description     = This method selects default alarm ring tone as a Carbon ring tone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.Default_alarm_sound.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_default_alarm_sound_select(self):
        """
        Name            = sound_default_alarm_sound_select
        Description     = This method selects default alarm ring tone as a Carbon ring tone
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
                                    ->default_alarm_sound_click
        Input           = NA
        Return          = True and False
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.default_alarm_tone.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.OK.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def sound_dial_pad_tones(self):
        """
         Name            = sound_dial_pad_tones
         Description     = This method is to enable/disable dial pad tone
         Pre-requisites  = 1. Firstly run setting_display_open_setting->click_on_sound->advanced_click
         Input           = NA
         Return          = True and False
                """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.dial_pad_tones.text)
        return is_tap

    def sound_screen_locking_sounds(self):
        """
         Name            = sound_screen_locking_sounds
         Description     = this method is use to enable/disable screen lock sound
         Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
         Input           = NA
         Return          = True and False
                        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.screen_locking_sounds.text)
        return is_tap

    def sound_charging_sounds(self):
        """
        Name            = sound_charging_sounds
        Description     = this method is use to enable/disable charging sound
        Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
        Input           =   NA
        Return          = True and False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.charging_sounds.text)
        return is_tap

    def sound_touch_sounds(self):
        """
         Name            = sound_touch_sounds
         Description     = this method is use to enable/disable touch sound
         Pre-requisites  = 1. firstly run setting_display_open_setting->click_on_sound->advanced_click
         Input           = NA
         Return          = True and False
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.touch_sounds.text)
        return is_tap



