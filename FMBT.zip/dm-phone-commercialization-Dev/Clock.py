"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
import Assertion
from Config import Configuration as config
import pdb


device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
assertion = Assertion.Assertion()


class Clock:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/clock.json')
        pass

    def clock_app_launch(self):
        """
        Name          : clock_app_launch
        Description   : This method is to launch clock application
        Pre-requisite : App list should be open
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        common.app_list_open()
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.app_name)
        pdb.set_trace()
        return status

    def clock_select_clock_tab(self):
        """
        Name          : clock_select_clock_tab
        Description   : This method is to launch clock activity from clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.tabs.clock.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_search_city_for_timezone(self):
        """
        Name          : clock_search_city_for_timezone
        Description   : This method is to search city to get time from timezone from clock application
        Pre-requisite : Clock activity should be open and Device should have internet connection on
        input         : NA
        Return        : True or False
        """
        # tap on action button to open search city
        flag = False
        status = device.tapContentDesc(self.data_model.Buttons.cities.content_desc)
        if status ==True:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(self.data_model.Buttons.Search.content_desc)
            time.sleep(config.SLEEP_TIME_LOW)
            device_conn.sendType(config.CITY_NAME)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.pressBack()
            device.pressBack()
        return flag

    def clock_select_alarm_tab(self):
        """
        Name          : clock_select_alarm_tab
        Description   : This method is to launch alarm activity from clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_MEDIUM)
        status = device.tapText(self.data_model.tabs.alarm.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_add_alarm(self):
        """
        Name          : clock_add_alarm
        Description   : This method is to tap on add alarm option from alarm activity of clock application
        Pre-requisite : Alarm tab should be opened from clock application
        input         : NA
        Return        : True or False
        """
        status = device.tapContentDesc(self.data_model.Buttons.add_alarm.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_set_time(self,index):
        """
         Name          : clock_set_time
         Description   : This method is to set alarm from alarm activity of clock application
         Pre-requisite : Alarm tab should be opened from clock app
         input         : min :time in minutes
                         sec :time in second
                         index: 0=AM
                         index: 1=PM
        Return        : True or False
         """
        flag = False
        status = device.tapContentDesc(config.ALARM_HOURS)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(config.ALARM_MINUTES)
            if flag:
                status = device.tapText(Constant.TIME_ZONE[index])
        return status

    def clock_handle_popup_actions(self, index):
        """
         Name          : clock_select_handle_popup
         Description   : This method is to select OK AND CANCEL option while setting alarm from alarm activity of clock application
         Pre-requisite : Add Alarm tab should be opened from clock app
         input         : index: 0=OK
                         index: 1=CANCEL
        Return        : True or False
         """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(Constant.CHOICE[index])
        return status

    def clock_expand_alarm(self):
        """
        Name          : clock_expand_alarm
        Description   : This method is to expand already added alarm for detail options from alarm tab of clock application
        Pre-requisite : Only one Alarm should be available in list #TODO Prajakta work for multiple alarm
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.expand_alarm.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_collapse_alarm(self):
        """
        Name          : clock_collapse_alarm
        Description   : This method is to collapse already expanded alarm details from alarm tab of clock application
        Pre-requisite : Only one Alarm should be available in list with expanded detail options
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.collapse.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def clock_alarm_repeat(self, index):
        """
        Name          : clock_alarm_repeat
        Description   : This method is to repeat alarm from alarm tab of clock application
        Pre-requisite : Alarm should be expanded for more options
        input         : index = excluded day # TODO Prajakta pass integer list
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.repeat.text)
        if status:
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            device.refreshView(uiautomatorDump=True)
            flag = device.tapContentDesc(Constant.EXCLUDED_DAY[index])
        return flag

    def clock_alarm_vibration_on_off(self):
        """
        Name          : clock_alarm_vibration_on_off
        Description   : This method is to ON/OFF vibration of already added alarm in alarm tab from clock application
        Pre-requisite : Only one Alarm should be available in list expanded for detail options
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.vibrate.text)
        return status

    def clock_alarm_label_tap(self):
        """
        Name          : clock_alarm_label_tap
        Description   : This method is to select label option from alarm activity of clock application
        Pre-requisite : Alarm should be expanded for detail options
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.label.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_alarm_add_label(self):
        """
        Name          : clock_alarm_add_label
        Description   : This method is to add label to already set alarm from alarm activity of clock application
        Pre-requisite : Alarm should be expanded for detail options
        input         : NA
        Return        : True or False
        """
        status = device_conn.sendType(config.ADD_LABEL)
        return status

    def clock_alarm_label_close(self,index):
        """
        Name          : clock_alarm_label_close
        Description   : This method is to close current screen of set label from alarm activity of clock application
        Pre-requisite : Alarm should be expanded for detail options
        input         : NA
        Return        : True or False
        """
        status = device.tapText(Constant.CHOICE[index])
        device.pressBack()
        return status

    def clock_alarm_off(self):
        """
        Name          : clock_alarm_off
        Description   : This method is to off already added alarm in alarm tab of clock application
        Pre-requisite : only One Alarm should be added in list
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.on.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status
    def clock_alarm_on(self):
        """
        Name          : clock_alarm_on
        Description   : This method is to on already added alarm in alarm tab of clock application
        Pre-requisite : Alarm should be set
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.off.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_alarm_delete(self):
        """
        Name          : clock_alarm_delete
        Description   : This method is to delete  already set  alarm from alarm activity of clock application
        Pre-requisite : Alarm should be expanded for more options
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.delete.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_select_timer_tab(self):
        """
        Name          : clock_select_timer_tab
        Description   : This method is to launch timer activity from clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.tabs.timer.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_start_timer(self):
        """
        Name          : clock_start_timer
        Description   : This method is to set and start timer in timer activity of clock application
        Pre-requisite : timer tab should be open
        input         :  Configure TIMER_TIME of 6 digit number for add hours,minutes,seconds to timer
                         Configure TIMER_TIME of 4 digit number for add minutes,seconds in timer
                         Configure TIMER_TIME of 4 digit number for add seconds in timer
        Return        : True or False
        """
        flag = False
        status = device_conn.sendType(config.TIMER_TIME)
        if status == True:
            time.sleep(config.SLEEP_TIME_LOW)
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapContentDesc(self.data_model.Buttons.start_timer.content_desc)
            time.sleep(config.SLEEP_TIME_HIGH)
        return flag


    def clock_pause_timer_from_statusbar(self):
        """
        Name          : clock_pause_timer
        Description   : This method is to pause timer of  timer  activity of clock application
        Pre-requisite : timer should be started
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        common.pull_statusbar()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.pause_timer.content_desc)
        return status

    def clock_resume_timer_from_statusbar(self):
        """
        Name          : clock_resume_timer
        Description   : This method is to resume timer of  timer  activity of clock application
        Pre-requisite : timer should be paused
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.resume_timer.content_desc)
        return status

    def clock_reset_timer_from_statusbar(self):
        """
        Name          : clock_resume_timer
        Description   : This method is to reset timer of  timer  activity of clock application
        Pre-requisite : timer should be paused
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.reset_timer.text)
        return status

    def clock_delete_timer(self):
        """
        Name          : clock_delete_timer
        Description   : This method is to reset timer of  timer  activity of clock application
        Pre-requisite : timer should be paused
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.delete_timer.text)
        return status

    def clock_add_new_timer(self):
        """
        Name          : clock_delete_timer
        Description   : This method is to reset timer of  timer  activity of clock application
        Pre-requisite : timer should be paused
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.add_timer.text)
        return status

    def clock_select_stopwatch_tab(self):
        """
        Name          : clock_activity_stopwatch
        Description   : This method is to launch stopwatch activity from clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.tabs.stopwatch.text)
        pdb.set_trace()
        return status

    def clock_start_stopwatch(self):
        """
        Name          : clock_start_stopwatch# Todo assertion (prajakta)
        Description   : This method is to start time in stopwatch activity of clock application
        Pre-requisite : timer activity should be opens
        input         : NA
        Return        : True or False
        """
        #Tap at center of the device screen to start stopwatch timer
        device.shellSOE("input keyevent 23")
        device.shellSOE("input keyevent 23")
        time.sleep(config.SLEEP_TIME_HIGH)
        pdb.set_trace()


    def clock_pause_stopwatch_timer(self):
        """
         Name          : clock_pause_timer
         Description   : This method is to pause time in stopwatch activity of clock application
         Pre-requisite : stopwatch timer should be started
         input         : NA
        Return        : True or False
         """
        device.pressHome()
        common.pull_statusbar()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.pause_timer.content_desc)
        pdb.set_trace()
        return status

    def clock_reset_stopwatch_timer_from_statusbar(self):
        """
         Name          : clock_reset_timer_from_statusbar# Todo assertion (prajakta)
         Description   : This method is to reset stopwatch timer from statusbar
         Pre-requisite : stopwatch timer should be paused
         input         : NA
        Return        : True or False
         """
        self.clock_reset_timer_from_statusbar()
        pdb.set_trace()

    def clock_select_more_options(self):
        """
        Name          : clock_more_options
        Description   : This method is to select more option in clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.more_options.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def clock_set_screen_saver(self):
        """
        Name          : clock_screen_saver
        Description   : This method is to select screen saver option from more options in clock application
        Pre-requisite : more option should be open in clock application
        input         : NA
        Return        : True or False
        """
        self.clock_select_more_options()
        status = device.tapText(self.data_model.text.screen_saver.text)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        #To on device screen from the screen saver
        device.shellSOE("input keyevent 26")
        device.shellSOE("input keyevent 82")
        return status


    def clock_open_setting(self):
        """
        Name          : clock_setting
        Description   : This method is to select setting option from more options in clock application
        Pre-requisite : more option should be open in clock application
        input         : NA
        Return        : True or False
        """
        self.clock_select_more_options()
        status = device.tapText(self.data_model.text.settings.text)
        return status

    def clock_close_setting(self):
        """
        Name          : Navigate_up# Todo assertion (prajakta)
        Description   : This method is to navigate up from current device screen
        Pre-requisite : Device screen view should be taken
        Input         : NA
        Return        : True or False
        """
        device.pressBack()

    def clock_close_app(self):
        """
        Name          : clock_close_app
        Description   : This method is to close clock application
        Pre-requisite : Clock application should be open
        input         : NA
        Return        : NA
        """
        common.close_application(self.data_model.Buttons.close_app.content_desc)











































