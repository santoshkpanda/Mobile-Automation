"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '05 Oct 2018'

import fmbtandroid
import subprocess
import time
import Constants as Constant
import BaseSettings
from Config import Configuration as config

device = fmbtandroid.Device()
settings = BaseSettings.BaseSettings()


class WiFi:

    def __init__(self):
        pass

    def wifi_get_state_via_adb(self):
        """
        Name          : get_wifi_state
        Description   : This method is to get Wi-Fi state enabled/disabled(On/Off)
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Return 'Wi-Fi is enabled' or 'Wi-Fi is disabled' if airplane mode is enabled or disabled respectively.
        """
        proc3 = subprocess.Popen("adb shell dumpsys wifi | grep \"Wi-Fi is\"", stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, shell=True)
        output = proc3.stdout.readline()
        return output.rstrip()

    def wifi_enable_via_adb(self):
        """
        Name          : wifi_enable
        Description   : This method is to turn Wi-Fi On
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell svc wifi enable", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def wifi_disable_via_adb(self):
        """
        Name          : wifi_disable
        Description   : This method is to turn Wi-Fi Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell svc wifi disable", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def wifi_enable_disable(self):
        """
        Name          : wifi_enable_disable
        Description   : This method is to toggle Wi-Fi On-Off
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        state = self.wifi_get_state_via_adb()
        if state == Constant.ENABLED_WIFI:
            self.wifi_disable_via_adb()
            self.wifi_enable_via_adb()
        elif state == Constant.DISABLED_WIFI:
            self.wifi_enable_via_adb()
            self.wifi_disable_via_adb()

    def assert_wifi_state_via_adb(self, expected_output):
        """
        Name          : assert_wifi_state
        Description   : This method is to assert Wi-Fi changed state
        Pre-requisite : Device's adb shell should be accessible
        Input         : actual_output-  output return by get_wifi_state() after change in state
                        expected_output-    This is expected output after change in state
        Return        : NA
        """
        print("Asserting Wifi changed state ...")
        actual_output = self.wifi_get_state_via_adb()
        print(actual_output + "==" + expected_output)
        if Constant.ENABLED_WIFI == actual_output:
            print("Wifi Turned ON")
        elif Constant.DISABLED_WIFI == actual_output:
            print("Wifi Turned OFF")
        else:
            print("Invalid WiFi State")
        assert actual_output == expected_output

    def wifi_setting_open(self):
        """
        Name          : wifi_setting_open
        Description   : This method is to open Wi-Fi setting open from Device Setting app
        Pre-requisite : Need to open  Network & Internet Setting from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.waitText("Wi-Fi")
        device.tapText("Wi-Fi")

    def hotspot_setting_open(self):
        """
        Name          : hotspot_setting_open
        Description   : This method is to open Hotspot and tethering setting open from Device Setting app
        Pre-requisite : Need to open  Network & Internet Setting from device's settings app
        Input         : NA
        Return        : NA
        """
        settings.network_and_internet_setting_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.waitText("Hotspot & tethering")
        device.tapText("Hotspot & tethering")
        time.sleep(config.SLEEP_TIME_LOW)

    def change_wifi_hotspot_state(self):
        """
        Name          : hotspot_setting_open
        Description   : This method is to open Hotspot and tethering setting open from Device Setting app
        Pre-requisite : Need to open  Network & Internet Setting from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.swipeOcrText("Bluetooth tethering", "south")
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.waitText("Wi-Fi hotspot")
        device.tapText("Wi-Fi hotspot")
        # TODO Pallavi Half screen is not visible


