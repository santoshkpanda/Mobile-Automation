"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__Copyright__ = "Copyright 2018, DarkMatter"
__author__ = "Shravan"
__version__ = "1.0"
__date__ = "20 Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
from CommonFunctions import CommonFunctions
import Constants as Constant

device = fmbtandroid.Device()
common = CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class SettingLanguage:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/Settinglanguages.json')
        pass

    def setting_app_open_via_ui(self):
        """
        Name            : setting_app_open_via_ui
        Description     : This method is use to launch setting.
        Pre-requisites  : setting_app
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        common.app_list_open()
        common.scroll_up_search_text(self.data_model.text_view.setting.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.setting.text)

    def setting_open_system_menu(self):
        """
        Name            = setting_open_system_menu
        Description     = this method open System menu.
        Pre-requisites   =setting_app_open_via_ui
        Input           = NA
        Return          = NA
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.system.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def language_open_languages_input(self):
        """
        Name            = language_open_languages_input
        Description     = this method open languages input .
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.language_input.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def language_open_languages(self):
        """
        Name            = language_open_languages
        Description     = this method open languages
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.language_text.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def language_select_language_perference(self):
        """
        Name            = language_select_language_perferences
        Description     = this method select language performance
        Pre-requisites  =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_languages
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.add_languages.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        device.pressBack()
        return is_tap

    def language_open_physical_keyboard(self):
        """
        Name            = language_open_physical_keyboard
        Description     = this method select physical keyboard
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.physical_keyboard.text)
        return is_tap

    def language_select_show_virtual_keyboard(self):
        """
        Name            = language_select_show_virtual_keyboard.
        Description     = this method select virtual keyboard.
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_physical_keyboard
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.virtual_keyboard.text)
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.virtual_keyboard.text)
        device.pressBack()
        return is_tap

    def language_open_advanced(self):
        """
        Name            = language_open_advanced
        Description     = this method select advanced
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.advanced.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def language_open_spell_checker(self):
        """
        Name            = language_open_spell_checker
        Description     = this method select spell checker
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.spell_checker.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def language_select_spell_checker(self):
        """
        Name            = language_select_spell_checker
        Description     = this method toggle ON or OFF
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        text = device.tapId(self.data_model.text_view.ID.id)
        return text

    def language_open_language(self):
        """
        Name            = language_open_language
        Description     = this method open language
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker->language_select_spell_checker
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.language.text)
        return is_tap

    def language_set_language(self):
        """
        Name            = language_set_language
        Description     = this method set language
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker->language_select_spell_checker
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.select_language.text)
        return is_tap

    def language_select_language(self):
        """
        Name            = language_select_language
        Description     = this method select language
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker->language_select_spell_checker->
                          language_set_language
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.default_spell_checker.text)
        return is_tap

    def language_select_android_spell_checker(self):
        """
        Name            = language_select_android_spell_checker
        Description     = this method select spell checker
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker->language_select_spell_checker->
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.android_spell_checker.text)
        return is_tap

    def language_spell_checker_back(self):
        """
        Name            = language_spell_checker_back
        Description     = this method press back
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_spell_checker->language_select_spell_checker->
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()

    def language_open_pointer_speed(self):
        """
        Name            = language_open_pointer_speed
        Description     = this method open pointer speed
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.pointer_speed.text)
        return is_tap

    def language_set_pointer_speed(self):
        """
        Name            = system_select_pointer_speed
        Description     = this method set pointer speed
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_pointer_speed
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        device.shellSOE("input swipe 250 1254 1000 1254")

    def language_select_ok(self):
        """"
        Name            = language_select_ok
        Description     = this method select ok
        Pre-requisites   =setting_app_open_via_ui->setting_open_system_menu->language_open_languages_input->
                          language_open_advanced->language_open_pointer_speed
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.ok.text)
        return is_tap

    def setting_close_app(self):
        """
        Name            : setting_close_app
        Description     : This method is use to close the setting app.
        Input           :
        Note:-          :
        Return          :
        Pre-requisites  :    1. Firstly run setting_display_open

        """
        common.close_application(self.data_model.text_view.dismiss_setting.text)
