"""
  Copyright (C) 2018, Dark Matter LLC. All rights Reserved

  This software and/or source code may be used, copied and/or disseminated only
  with the written permission of Dark Matter LLC, or in accordance with the terms
  and conditions stipulated in the agreement/contract under which the software
  and/or source code has been supplied by Dark Matter LLC or its affiliates.
  Unauthorized use, copying, or dissemination of this file, via any medium, is
  strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '09 Oct 2018'


class Configuration:
    def __init__(self):
        pass

    """Project level/Global configuration"""
    SLEEP_TIME_LOW = 1
    SLEEP_TIME_MEDIUM = 4
    SLEEP_TIME_HIGH = 8
    SLEEP_TIME_CALL = 15

    DEVICE_UDID = "HT6A60204949"

    """Airplane mode configuration"""

    """Audio configuration"""
    AUDIO_TO_BE_PLAYED = "Begin Again (Music From and Inspired By the Original Motion Picture) [Deluxe Version]"
    DRAG_SCREEN_X1Y1 = (670, 2220)
    DRAG_SCREEN_X2Y2 = (670, 1300)
    """Battery configuration"""

    """Bluetooth configuration"""

    """Boot configuration"""

    """Calculator configuration"""

    """Calendar configuration"""
    REMINDER = "meeting at 2.00 pm"

    """Camera configuration"""
    CAMERA_APP_ACTIVITY = "com.google.android.GoogleCamera/com.android.camera.CameraLauncher"
    VIDEO_MODE_OPEN = "-a android.media.action.VIDEO_CAPTURE"

    """Clock configuration"""
    ADD_LABEL = "CLCOK LABEL"
    CITY_NAME = "Dubai"
    ALARM_HOURS = "8"
    ALARM_MINUTES = "55"
    TIMER_HOURS = "9"
    TIMER_MINUTES = "45"
    SLEEP_TIME_20 = 20
    TIMER_TIME = "011530"

    """Common functions configuration"""
    SCREEN_SHOT_LOCATION = "/home/sysadmin/Pictures/fmbtImg/"

    """Contacts configuration"""
    FIRST_NAME = "ABC"
    LAST_NAME = "DEF"
    PHONE_NO = "1234567890"

    """Device Screen configuration"""

    """Dialer configuration"""
    PHONE_NUMBER_LIST = ["7276419924", "8483918804", "9887766554"]
    SEARCH_CONTACT = "Idea"
    FORWARD_CALL_TO_NUMBER = "7276419924"
    SAVE_VIA_RECENT_CONTACTS = "76879 86543"
    ACCESSIBILITY_LIST = ["Accessibility", "TTY mode", "TTY Full", "TTY mode", "TTY HCO", "TTY mode", "TTY VCO"]
    ADD_TO_FAVORITES = "Bsnl"

    """File Download configuration"""
    IMAGE_DOWNLOAD = "https://uploadevice.wikimedia.org/wikipedia/commons/2/2c/A_new_map_of_Great_Britain_according_to_the_newest_and_most_exact_observations_%288342715024%29.jpg -n com.androidevice.chrome/com.google.androidevice.apps.chrome.Main"
    LINK = "https://img." + "raremaps." + "com." + "/xlarge/" + "51322." + "jpg"
    ENTER = "input keyevent 66"

    """HardwareSwitch configuration"""

    """Launcher configuration"""
    SEARCH_TEXT = "latest movies"

    """Location configuration"""

    """Messaging App Configuration"""
    MESSAGE_RECEIVED_FROM = "Idea"
    MESSAGE_FROM_MESSAGING_APP = "This message is sent from the messaging app"

    """Mobile Data configuration"""

    """Wi-Fi configuration"""

    """Setting Ringtone"""
    RINGTONE = "Chime"


