"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__Copyright__ = "Copyright 2018, DarkMatter"
__Author__ = "Shravan"
__Version__ = "1.0"
__Date__ = "18 Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
from CommonFunctions import CommonFunctions
import Constants as Constant

device = fmbtandroid.Device()
common = CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class SettingDateTime:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/SettingDateTime.json')
        pass

    def setting_app_open_via_ui(self):
        """
        Name            : setting_app_open
        Description     : This method is use to launch setting.
        Pre-requisites  : setting app
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        common.app_list_open()
        common.scroll_up_search_text(self.data_model.text_view.setting.text)
        device.refreshView(uiautomatorDump=True)
        time.sleep(config.SLEEP_TIME_LOW)
        is_tap = device.tapText(self.data_model.text_view.setting.content_desc)
        return is_tap

    def setting_open_system_menu(self):
        """
        Name            = setting_select_system_menu
        Description     = this method press System icon and open System menu.
        Pre-requisites   =setting_app_open_via_ui
        Input           = NA
        Return          = NA
        """
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.system.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return is_tap

    def datetime_open_datetime_menu(self):
        """
        Name            = datetime_open_datetime_menu
        Description     = this method press Date & time icon and open Date & time menu.
        Pre-requisites   =setting_app_open_via_ui->setting_select_system_menu
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.date_time.text)
        return is_tap

    def datetime_select_automatic_date_time(self, ):
        """
        Name            = datetime_select_automatic_date_time
        Description     = this method select the automatic date & time
        Pre-requisites  = setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.automatic_date_time.text)
        return is_tap

    def datetime_open_set_date(self):
        """
        Name            = datetime_open_set_date
        Description     = this method open the set date to set date
        Pre-requisites  = setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
                          ->datetime_select_automatic_date_time
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.set_date.text)
        return is_tap

    def datetime_select_ok(self):
        """
        Name            = datetime_select_ok
        Description     = this method select ok.
        Pre-requisites  = setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
                          ->datetime_select_automatic_date_time->datetime_open_set_date
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.ok.text)
        return is_tap

    def datetime_open_set_time(self):
        """
        Name            = datetime_open_set_time
        Description     = this method open the set time to set time
        Pre-requisites  = setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
                          ->datetime_select_automatic_date_time
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.set_time.text)
        return is_tap

    def datetime_select_automatic_time_zone(self):
        """
        Name            = datetime_select_automatic_time_zone
        Description     = this method select Automatic time zone
        Pre-requisites   =setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.automatic_time_zone.text)
        return is_tap

    def datetime_open_select_time_zone(self):
        """
        Name            = datetime_open_select_time_zone
        Description     = this method open select time zone to set time zone
        Pre-requisites   =setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
                           ->datetime_select_automatic_time_zone
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.select_time_zone.text)
        return is_tap

    def system_select_automatic_time_zone(self):
        """
        Name            = system_select_automatic_time_zone
        Description     = this method select time zone
        Pre-requisites   =setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
                           ->datetime_select_automatic_time_zone
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.time_zone_name.text)
        return is_tap

    def datetime_select_hours_format(self):
        """
        Name            = datetime_select_hours_format
        Description     = this method press Use 24-hour format icon to change the time format.
        Pre-requisites  =setting_app_open_via_ui->setting_select_system_menu->datetime_open_datetime_menu
        Input           = NA
        Return          = NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.use_hour_format.text)
        return is_tap

    def setting_close_app(self):
        """
        Name            : setting_close_app
        Description     : This method is use to close the setting app.
        Input           :
        Note:-          :
        Return          :
        Pre-requisites  :    1. Firstly run setting_display_open

        """
        common.close_application(self.data_model.text_view.dismiss_setting.text)
