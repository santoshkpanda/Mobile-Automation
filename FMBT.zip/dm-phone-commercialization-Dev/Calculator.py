"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Calculator:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/calculator.json')

    def calculator_launch(self):
        """
        Name          : calculator_launch
        Description   : This method is to launch calculator application
        Pre-requisite : App list should be open
        Input         : NA
        Return        : True or False
        """
        common.app_list_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.app_name)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def calculator_perform_operation(self, operation, operand1, operand2):
        """
        Name          : calculator_perform_operation
        Description   : This method is to perform arithmetic operation in calculator application
        Pre-requisite : Calculator application should be open
        input         : Operation : It must be 'plus', 'minus', 'multiply', 'divide'
                        operand1 : any number
                        operand2 : any number
        Return        : result
        """
        device_conn.sendType(operand1)
        device.tapContentDesc(operation)
        device_conn.sendType(operand2)
        time.sleep(config.SLEEP_TIME_LOW)
        return self.calculator_equal()

    def calculator_equal(self):
        """
        Name          : calculator_equal
        Description   : This method generates result for operation and clear result on screen in calculator application
        Pre-requisite : calculator_perform_operation() method should be called before this method to take inputs like
                        operation and operands in calculator application
        Input         : NA
        Return        : True or False
        """
        device.tapContentDesc(self.data_model.Buttons.equals.content_desc)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        result = common.get_text_by_id(self.data_model.text_view.result.id)
        device.refreshView(uiautomatorDump=True)
        device.tapContentDesc(self.data_model.Buttons.clear.content_desc)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return result

    def calculator_advance_option(self):
        """
        Name          : calculator_advance_option
        Description   : This method is to launch advance option from calculator application
        Pre-requisite : Calculator application should  be open
        Input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.advanced_operations.content_desc)
        return status

    def calculator_more_option(self):
        """
        Name          : calculator_more_option
        Description   : This method is to launch more option from calculator application
        Pre-requisite : Calculator application should  be open
        Input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.Buttons.more_options.content_desc)
        return status

    def calculator_history(self):
        """
        Name          : calculator_history
        Description   : This method is to launch history option from more options of calculator application
        Pre-requisite : Calculator more option of calculator application should  be open
        Input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.history.text)
        return status

    def calculator_close_advance_option(self):
        """
        Name          : calculator_close_advance_option
        Description   : This method is to close advance option from calculator application
        Pre-requisite : advance option from calculator application should  be open
        Input         : NA
        Return        : True or False
        """
        status = device.pressBack()
        return status

    def calculator_close_app(self):
        """
        Name          : calculator_close_app
        Description   : This method is to close  calculator application
        Pre-requisite : Calculator application should  be open
        Input         : NA
      
        Return        : NA
        """
        common.close_application(self.data_model.Buttons.close_app.content_desc)






