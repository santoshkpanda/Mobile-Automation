"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '09 Oct 2018'

import fmbtandroid
import time
import subprocess
import Constants as Constant
import BaseSettings
import CommonFunctions
from Config import Configuration as config
import DeviceScreen

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
settings = BaseSettings.BaseSettings()


class MobileData:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/MobileData.json')
        pass

    def mobile_data_get_state(self):
        """
        Name          : get_mobile_data_state
        Description   : This method is to get mobile data state enabled/disabled(On/Off)
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : Return '2' or '0' if  mobile data is enabled or disabled respectively.
        """
        proc3 = subprocess.Popen("adb shell dumpsys telephony.registry | grep mDataConnectionState", stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, shell=True)
        output = proc3.stdout.readline()
        return output.rstrip()[-1]

    def mobile_data_enable_via_adb(self):
        """
        Name          : mobile_data_enable_with_adb
        Description   : This method is to turn mobile data On with adb command
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell svc data enable", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_disable_via_adb(self):
        """
        Name          : mobile_data_disable_with_adb
        Description   : This method is to turn mobile data Off with adb command
        Pre-requisite : Device's adb shell should be accessible
        Input         : NA
        Return        : NA
        """
        proc = subprocess.Popen("adb shell svc data disable", stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=True)
        proc.communicate()
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_enable_disable_via_UI(self):
        """
         Name          : mobile_data_enable_disable_via_UI
         Description   : This method is to turn mobile data On/Off through the settings app
         Pre-requisite : Device should be switched on
         Input         : NA
         Return        : NA
         """
        device_screen = DeviceScreen.DeviceScreen()
        device_screen.open_screen_lock()
        settings.setting_app_launch_via_adb()
        settings.network_and_internet_setting_open()
        self.mobile_data_open_mobile_network()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.mobile_data.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressHome()

    def assert_mobile_data_state(self, expected_output):
        """
        Name          : assert_mobile_data_state
        Description   : This method is to assert mobile data changed state
        Pre-requisite : Device's adb shell should be accessible
        Input         : actual_output-  output return by get_mobile_data_state() after change in state
        expected_output-    This is expected output after change in state
        Return        : NA
        """
        print("Asserting Mobile data changed state ...")
        actual_output = self.mobile_data_get_state()
        print(actual_output + "==" + expected_output )
        assert actual_output == expected_output
        if Constant.ENABLED_MOBILE_DATA == actual_output:
            print("Mobile data Turned ON")
        elif Constant.STATE_DISABLED == actual_output:
            print("Mobile data Turned OFF")
        else:
            print("Mobile data invalid state"+actual_output)

    def mobile_data_open_mobile_network(self):
        """
        Name          : mobile_data_open_mobile_network_
        Description   : This method is to open mobile network settings
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        settings.network_and_internet_setting_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.mobile_network.text)
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_open_data_usage(self):
        """
        Name          : mobile_data_open_data_usage
        Description   : This method is to open data usage settings
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        settings.network_and_internet_setting_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.data_usage.text)
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_open_data_saver(self):
        """
        Name          : mobile_data_open_data_saver
        Description   : This method is to open data saver settings
        Pre-requisite : Data usage settings should be open from device's settings app
        Input         : NA
        Return        : NA
        """
        settings.network_and_internet_setting_open()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.data_saver.text)
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_close_data_saver(self):#TODO PALLAVI Remove this method
        """
        Name          : mobile_data_close_data_saver
        Description   : This method is to close data saver settings
        Pre-requisite : Data saver settings should be open from device's settings app
        Input         : NA
        Return        : NA
        """
        device.pressBack()

    def mobile_data_close_data_usage(self): #TODO PALLAVI Remove this method
        """
        Name          : mobile_data_close_data_saver
        Description   : This method is to close data usage settings
        Pre-requisite : Data usage settings should be open from device's settings app
        Input         : NA
        Return        : NA
        """
        device.pressBack()

    def mobile_data_on_off_data_saver(self):
        """
        Name          : mobile_data_on_off_data_saver
        Description   : This method is to on/off data saver settings
        Pre-requisite : Data saver settings should be open from device's settings app -> Data Usage
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_off = device.verifyText(self.data_model.text_view.data_saver_switch_off.text)

        if is_off:
            device.tapText(self.data_model.text_view.data_saver_switch_off.text)
            time.sleep(config.SLEEP_TIME_LOW)
        else:
            device.tapText(self.data_model.text_view.data_saver_switch_on.text)
            time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_roaming_enable_disable(self):
        """
        Name          : mobile_data_enable_with_adb
        Description   : This method is to enable or disable mobile data roaming
        Pre-requisite : Mobile network settings should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.roaming.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        is_text_available = device.verifyText(self.data_model.text_view.allow_data_roaming.text)
        if is_text_available:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            #self.mobile_data_handle_popup_actions(1)

    def mobile_data_handle_popup_actions(self, index):
        """
        Name          : bluetooth_handle_popup_actions
        Description   : This method is handle all pop up actions in mobile data module
        Pre-requisite : Popup must be opened from bluetooth module
        Input         : index- enter 0-1 for action to take on forget device dialog like "CANCEL", "OK"
        Return        : NA
        """
        dialog_actions = [self.data_model.button.cancel.text, self.data_model.button.ok.text]
        device.tapText(dialog_actions[index])
        time.sleep(config.SLEEP_TIME_LOW)

    def mobile_data_close_mobile_network(self):
        """
        Name          : mobile_data_close_mobile_network
        Description   : This method is to close mobile network setting
        Pre-requisite : device's settings app should be opened
        Input         : NA
        Return        : NA
        """
        device.pressBack()


    def mobile_data_open_mobile_network_advance_setting(self):
        """
        Name          : mobile_data_open_mobile_network_advance_setting
        Description   : This method is to close mobile network setting
        Pre-requisite : Mobile network settings should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.advanced.text)

    def mobile_data_open_preferred_network_type_popup(self):
        """
        Name          : mobile_data_open_preferred_network_type_popup
        Description   : This method is to open preferred network type popup
        Pre-requisite : Mobile network's Advanced settings should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(self.data_model.text_view.preferred_network_type.text)

    def mobile_data_select_preferred_network_type(self, index):
        """
        Name          : mobile_data_select_preferred_network_type
        Description   : This method is to open preferred network type popup
        Pre-requisite : Mobile network's Advanced settings should be opened from device's settings app
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapText(Constant.PREFERRED_NETWORK_TYPE[index])

    def mobile_data_open_usage_configuration(self):
        """
        Name          : mobile_data_close_preferred_network_type_popup
        Description   : This method is to close preferred network type popup
        Pre-requisite : preferred network type popup should be opened from Mobile network settings
        Input         : NA
        Return        : NA
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        device.tapContentDesc(self.data_model.image_button.configure.content_desc)


