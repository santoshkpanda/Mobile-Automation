"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pradnya Bargalr'
__email__ = 'pradnya.bargal@darkmatter.ae'
__version__ = '1.0'
__Date__ = '04 Oct 2018'


import fmbtandroid
import time
import Constants as Constant

device = fmbtandroid.Device()


class Boot:

    def __init__(self):
        pass

    def hard_boot(self):
        """
        Function Name   : hard_boot
        Description     : This method to restart device with reboot command
        Prerequisites   : The System should be switched on and Device's adb shell should be accessible
        Input           : NA
        Return          : NA
        """
        device.shellSOE("reboot")
        time.sleep(Constant.HARDBOOT_TIME)



