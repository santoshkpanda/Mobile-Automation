"""
 * Copyright (C) 2018, Dark Matter LLC. All rights Reserved
 *
 * This software and/or source code may be used, copied and/or disseminated only
 * with the written permission of Dark Matter LLC, or in accordance with the terms
 * and conditions stipulated in the agreement/contract under which the software
 * and/or source code has been supplied by Dark Matter LLC or its affiliates.
 * Unauthorized use, copying, or dissemination of this file, via any medium, is
 * strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Prajakta Dagade'
__email__ = 'prajakta.dagade@darkmatter.ae'
__version__ = '1.0'
__Date__ = '17 Nov 2018'

import fmbtandroid
import time
import Constants as Constant
import CommonFunctions
from Config import Configuration as config
import Assertion

device = fmbtandroid.Device()
common = CommonFunctions.CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))
assertion = Assertion.Assertion()


class Calendar:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/PixelXL_8_1_0/calendar.json')
        pass

    def calendar_app_launch(self):
        """
        Name          : calendar_app_launch
        Description   : This method is to launch calendar application
        Pre-requisite : App list should be open
        input         : NA
        Return        : True or False
        """
        device.pressHome()
        common.app_list_open()
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.app_name)
        return status

    def calendar_open_left_drawer_option(self):
        """
        Name          : calendar_open_left_drawer_option
        Description   : This method is to open left drawer options from calendar application
        Pre-requisite : calendar application should be opened
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.button.show_drawer.content_desc)
        # time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        return status

    def calendar_add_goal_event_reminder(self):
        """
        Name          : calendar_add_gaol_event_reminder
        Description   : this method is to tap to add goal, event, reminder from the calendar application
        Pre-requisite : calendar application should be opened
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.button.new.content_desc)
        return status

    def calendar_add(self):
        """
        Name          : calendar_add
        Description   : This method is to add goal, event, reminder
        Pre-requisite : Add option of event, reminder option from calendar application should be opened
        input         : NA
        Return        : True or False
        """

        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device_conn.sendType(config.REMINDER)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.button.done.text)
            if flag:
                device.refreshView(uiautomatorDump=True)
                time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
                status = device.tapText(self.data_model.button.save.text)
        return status

    def calendar_tap_goal(self):
        """
        Name          : calendar_tap_goal
        Description   : This method is to tap on goal option from calendar application
        Pre-requisite : add goal,event,reminder option from calendar application should be opened
        input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.button.goal.text)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            common.device_screen_swipe_up()
            common.device_screen_swipe_down()
            flag = device.tapContentDesc(self.data_model.button.close.content_desc)
        return flag

    def calendar_tap_reminder(self):
        """
        Name          : calendar_tap_reminder
        Description   : This method is to  tap on goal option from calendar application
        Pre-requisite : add goal,event,reminder option from calendar application should be opened
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.button.reminder_button.content_desc)
        return status

    def calendar_add_reminder(self):
        """
        Name          : calendar_add_reminder
        Description   : This method is to add new reminder in calendar application
        Pre-requisite : reminder option should be open from add goal,event,reminder option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = self.calendar_add()
        return status

    def calendar_tap_event(self):
        """
        Name          : calendar_event
        Description   : This method is to tap on event option from  calendar application
        Pre-requisite : create new event and more option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.button.event_button.content_desc)
        # print status
        return status

    def calendar_add_event(self):
        """
        Name          : calendar_add_event
        Description   : This method is to add new event in calendar application
        Pre-requisite : event option should be open from add goal,event,reminder option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = self.calendar_add()
        return status

    def calendar_show_schedule(self):
        """
        Name          : calendar_show_schedule
        Description   : This method is to view Schedule in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.schedule.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def calendar_show_full_day_schedule(self):
        """
        Name          : calendar_full_day_schedule
        Description   : This method is to view Schedule of full day time wise in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.day.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def calendar_show_3_days_schedule(self):
        """
        Name          : calendar_3_days_schedule
        Description   : This method is to view Schedule of next 3 days in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.days.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def calendar_show_full_week_schedule(self):
        """
        Name          : calendar_full_week_schedule
        Description   : This method is to view Schedule of full week in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.week.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def calendar_show_full_month_schedule(self):
        """
        Name          : calendar_full_month_schedule
        Description   : This method is to view Schedule of full month in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.month.text)
        time.sleep(config.SLEEP_TIME_LOW)
        return status

    def calendar_show_event(self):
        """
        Name          : calendar_off_show_event
        Description   : This method is to off showing all already set event in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status=device.tapText(self.data_model.text_view.events.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def calendar_show_reminders(self):
        """
        Name          : calendar_off_show_event
        Description   : This method is to off showing all already set reminders in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        status = device.tapText(self.data_model.text_view.reminders.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def calendar_scroll_up(self):
        """
        Name          : calendar_scroll_up
        Description   : This method is to scroll up left drawer options from calendar application
        Pre-requisite : left drawer options in calendar application should be opened
        input         : NA
        Return        : NA
        """
        self.calendar_open_left_drawer_option()
        common.device_screen_swipe_up()
        time.sleep(config.SLEEP_TIME_MEDIUM)

    def calendar_show_birthday(self):
        """
        Name          : calendar_off_show_event
        Description   : This method is to off showing all already set birthdays in calendar application
        Pre-requisite : left drawer option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        self.calendar_scroll_up()
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.birthdays.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def calendar_show_holidays(self):
        """
        Name          : calendar_off_show_event
        Description   : This method is to off showing all already set holidays in calendar application
        Pre-requisite : create new event and more option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        self.calendar_scroll_up()
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.holidays.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def calendar_refresh(self):
        """
        Name          : calendar_refresh
        Description   : This method is to refresh calendar application
        Pre-requisite : calendar application should be opened
        input         : NA
        Return        : True or False
        """
        flag = False
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapContentDesc(self.data_model.button.more_options.content_desc)
        if status:
            device.refreshView(uiautomatorDump=True)
            time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
            flag = device.tapText(self.data_model.text_view.refresh.text)
        return flag

    def calendar_setting(self):
        """
        Name          : calendar_setting
        Description   : This method is to open setting option in calendar application
        Pre-requisite : create new event and more option in calendar application should be opened
        input         : NA
        Return        : True or False
        """
        self.calendar_scroll_up()
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        time.sleep(Constant.UIAUTOMATOR_REFRESH_TIME)
        status = device.tapText(self.data_model.text_view.settings.text)
        time.sleep(config.SLEEP_TIME_LOW)
        device.pressBack()
        return status

    def calendar_close_app(self):
        """
        Name          : calendar_close_app
        Description   : This method is to close calendar application
        Pre-requisite : calendar application should be open
        input         : NA
        Return        : NA
        """
        common.close_application(self.data_model.button.close_app.content_desc)








