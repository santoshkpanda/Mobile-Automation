"""
* Copyright (C) 2018, Dark Matter LLC. All rights Reserved
* This software and/or source code may be used, copied and/or disseminated only
* with the written permission of Dark Matter LLC, or in accordance with the terms
* and conditions stipulated in the agreement/contract under which the software
* and/or source code has been supplied by Dark Matter LLC or its affiliates.
* Unauthorized use, copying, or dissemination of this file, via any medium, is
* strictly prohibited, and will constitute an infringement of copyright.
"""
__Copyright__ = "Copyright 2018, DarkMatter"
__Author__ = "Shravan"
__Version__ = "1.0"
__Date__ = "24 Oct 2018"

import fmbtandroid
import time
from Config import Configuration as config
from CommonFunctions import CommonFunctions

device = fmbtandroid.Device()
common = CommonFunctions()
device_conn = fmbtandroid._AndroidDeviceConnection(common.get_USB_connected_device(0))


class Gallery:

    def __init__(self):
        self.data_model = common.get_UI_metadata('./json_ui_data/Custom_8_1_0/Gallery.json')
        pass

    def gallery_open_gallery_app(self):
        """
        Name            : gallery_open_gallery_app
        Description     : This method is use to launch gallery.
        Pre-requisites  : gallery
        Input           : NA
        Return          : NA
        """
        device.pressHome()
        common.device_screen_swipe_up()
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.gallery.content_desc)
        return is_tap

    def gallery_open_albums(self):
        """
        Name            : gallery_open_albums
        Description     : This method is use to open albums.
        Pre-requisites  : gallery_open_gallery_app
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.album.text)
        return is_tap

    def gallery_select_albums(self):
        """
        Name            : gallery_select_albums
        Description     : This method is use to select album.
        Pre-requisites  : gallery_open_gallery_app
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.album.text)
        return is_tap

    def gallery_open_camera(self):
        """
        Name            : gallery_open_camera
        Description     : This method is use to open camera.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums
        Input           : NA
        Return          : NA
        """
        time.sleep(config.SLEEP_TIME_LOW)
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        st, out, err = device.shellSOE(cmd)
        if st == 0:
            return True
        return False


    def gallery_select_camera(self):
        """
        Name            : gallery_select_camera
        Description     : This method is use to select camera.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.verifyText(self.data_model.text_view.albums.text)
        return is_tap

    def gallery_select_video(self):
        """
        Name            : gallery_select_video
        Description     : This method is use to select video.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_camera
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)

    def gallery_play_video(self):
        """
        Name            : gallery_play_video
        Description     : This method is use to play video.
        Pre-requisites  : gallery_open_gallery_app->gallery_open_camera->gallery_select_video
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)

    def gallery_pause_video(self):
        """
        Name            : gallery_pause_video
        Description     : This method is use to pause the video.
        Pre-requisites  : gallery_open_gallery_app->gallery_open_camera->gallery_select_video
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)

    def gallery_start_video(self):
        """
        Name            : gallery_start_video
        Description     : This method is use to start the video.
        Pre-requisites  : gallery_open_gallery_app->gallery_open_camera->gallery_pause_video
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)
        device.pressBack()
        time.sleep(config.SLEEP_TIME_MEDIUM)
        device.pressBack()

    def gallery_select_camera_filmstrip(self):
        """
        Name            : gallery_camera_filmstrip
        Description     : This method is use to select filmstrip.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.camera.text)
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.filmstrip.text)
        return is_tap

    def gallery_select_photo(self):
        """
        Name            : gallery_select_photo
        Description     : This method is use to select single photo.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_camera
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        size = device.screenSize()
        x1 = size[0] / 2
        y1 = size[1] / 2
        x2 = x1 + 3
        y2 = y1 + 3
        count = 100
        cmd = "input swipe" + " " + str(x1) + " " + str(y1) + " " + str(x2) + " " + str(y2) + " " + str(count)
        device.shellSOE(cmd)
        device.pressBack()

    def gallery_select_slide_show(self):
        """
        Name            : gallery_select_slide_show
        Description     : This method is use to set image slide show.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.slide_show.text)
        device.pressBack()
        return is_tap

    def gallery_open_set_picture_as_wallpaper(self):
        """
        Name            : gallery_open_set_picture_as_wallpaper
        Description     : This method is use to set the wallpaper.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.set_picture.text)
        return is_tap

    def gallery_select_wallpaper(self):
        """
        Name            : gallery_select_wallpaper
        Description     : This method is use to set the wallpaper.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.wallpaper.text)
        return is_tap

    def gallery_select_set_wallpaper(self):
        """
        Name            : gallery_select_set_wallpaper
        Description     : This method is use to set the wallpaper.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.set_wallpaper.text)
        return is_tap

    def gallery_select_rotate_left_photo(self):
        """
        Name            : gallery_select_rotate_left_photo
        Description     : This method is use to rotate image.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.rotate_left.text)
        return is_tap

    def gallery_select_rotate_right_photo(self):
        """
        Name            : gallery_select_rotate_right_photo
        Description     : This method is use to rotate image.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.rotate_right.text)
        return is_tap

    def gallery_select_crop_photo(self):
        """
        Name            : gallery_select_crop_photo
        Description     : This method is use to crop image.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.crop.text)
        return is_tap

    def gallery_select_save(self):
        """
        Name            : gallery_select_save
        Description     : This method is use to crop image.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.save.text)
        return is_tap

    def gallery_select_more_option(self):
        """
        Name            : gallery_select_more_option
        Description     : This method is use to select more option .
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapContentDesc(self.data_model.text_view.more_option.content_desc)
        return is_tap

    def gallery_select_delete_photo(self):
        """
        Name            : gallery_delete_photo
        Description     : This method is use to delete image.
        Pre-requisites  : gallery_open_gallery_app->gallery_select_albums->gallery_select_photo
        Input           : NA
        Return          : NA
        """
        device.refreshView(uiautomatorDump=True)
        is_tap = device.tapText(self.data_model.text_view.delete.text)
        device.refreshView(uiautomatorDump=True)
        device.tapText(self.data_model.text_view.ok.text)
        device.pressBack()
        return is_tap

    def setting_close_app(self):
        """
        Name            : setting_close_app
        Description     : This method is use to close the setting app.
        Input           :
        Note:-          :
        Return          :
        Pre-requisites  :    1. Firstly run setting_display_open

        """
        common.close_application(self.data_model.text_view.dismiss_setting.text)

