"""
  Copyright (C) 2018, Dark Matter LLC. All rights Reserved

  This software and/or source code may be used, copied and/or disseminated only
  with the written permission of Dark Matter LLC, or in accordance with the terms
  and conditions stipulated in the agreement/contract under which the software
  and/or source code has been supplied by Dark Matter LLC or its affiliates.
  Unauthorized use, copying, or dissemination of this file, via any medium, is
  strictly prohibited, and will constitute an infringement of copyright.
 """
__author__ = 'Pallavi Ganorkar'
__email__ = 'pallavi.ganorkar@darkmatter.ae'
__version__ = '1.0'
__Date__ = '20 Sept 2018'


"""Project level/Global constants"""
UIAUTOMATOR_REFRESH_TIME = 4
# enable/disable state for modules like Airplane mode, Mobile data, etc.
STATE_ENABLED = '1'
STATE_DISABLED = '0'
CANCEL = 'CANCEL'
OK = 'OK'


"""Airplane mode constants"""

"""Audio constants"""

"""Battery constants"""

"""Bluetooth constants"""
FORGET_DEVICE_DIALOG_ACTIONS = ["CANCEL", "FORGET DEVICE"]

"""Boot constants"""
HARDBOOT_TIME = 20

"""Calculator constants"""

"""Camera constants"""

"""Clock constants"""
TIME_ZONE =["AM", "PM"]
CHOICE = ["OK", "CANCEL"]
EXCLUDED_DAY = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

"""Common functions constants"""

"""Contacts constants"""
CREATE_CONTACT_MOBILE_PHONE_LIST = ["Mobile", "Home", "Work", "Work Fax", "Home Fax", "Pager", "Other", "Custom",
                                    "Callback", "Car", "Company Main", "ISDN", "Main", "Other Fax", "Radio", "Telex",
                                    "TTY TDD", "Work Mobile", "Work Pager", "Assistant", "MMS"]
CREATE_CONTACT_HOME_EMAIL_LIST = ["Home", "Work", "Other", "Mobile", "Custom"]

"""Device Screen constants"""
SLEEP_TIME_EIGHTEEN = 18

"""Dialer constants"""
SAVE_PHONE_NUMBER_LIST = ["SAVED1", "Saved_via_recent_contacts"]
CONTACT_LIST = ["Android", "Jio"]
MESSAGE = "Hello this is a messsage sent from recent calls in history"
NUMBER_TO_BE_BLOCkED = "1234567890"
FDN_OLD = "12345"
FDN_NEW = "23456"
FDN_LIST = ["Fixed dialling numbers", "Enable FDN", "Change PIN2"]


"""File Download constants"""

"""File Download constants"""
OPEN_IMAGE = 20
TAP_HOLD = "180 2000 181 2001 1000"

"""HardwareSwitch constants"""

"""Launcher constants"""
OVERVIEW_PANEL_LIST = ["HOME SETTINGS", "WIDGETS", "WALLPAPERS"]

"""Location constants"""

"""Messaging App Constants"""
SEND_MESSAGE_TO_CONTACT_LIST = ["Airtel", "Idea", "Android", "Jio", "Aircel"]
LONG_PRESS_CONTACT_LIST = ["Airtel", "Idea", "Android", "Jio", "Aircel"]

"""Mobile Data constants"""
ENABLED_MOBILE_DATA = '2'
PREFERRED_NETWORK_TYPE = ["LTE (recommended)", "3G", "2G"]

"""Telephony configuration"""
PHONE_NUMBER1 = "+91 7276419924"
PHONE_NAME2 = "Idea"
PHONE_NUMBER2 = "+91 84839 18804"


"""Wi-Fi constants"""
ENABLED_WIFI = 'Wi-Fi is enabled'
DISABLED_WIFI = 'Wi-Fi is disabled'

"""Setting Constatns"""
INTONATION_LIST = ["Expressive", "Somewhat expressive", "Flat"]
FONT_LIST = ["Default", "Large", "Largest", "Small"]
TOUCH_AND_HOLD_DELAY = ["Short", "Medium", "Long"]
SHORTCUT_SERVICE = ["TalkBack", "Select to Speak", "Switch Access"]
CORRECTION_MODE = ["Deuteranomaly (red-green)", "Protanomaly (red-green)", "Tritanomaly (blue-yellow)"]

"""Settings -> Display """
SLEEP_TIME_LIST = ["15 seconds", "30 seconds", "1 minute", "2 minutes", "5 minutes", "10 minutes", "30 minutes"]
FONT_SIZE = ("Small", "Default", "Large", "Largest")
DISPLAY_SIZE = ["Small", "Default", "Large", "Larger", "Largest"]
BRIGHTNESS_LEVEL_OPTION=["Increase", "Decrease", "Middle"]

